package com.corbamonitor;

import com.corbamonitor.api.MonitorApiClient;
import com.corbamonitor.bridge.NameserviceBridge;
import com.corbamonitor.config.MonitorConfig;
import com.corbamonitor.nameserver.NameserverScanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

/**
 * CORBA Monitor Agent — Standalone entry point.
 *
 * This agent can run in two modes:
 *
 * 1. STANDALONE MODE (this main class):
 *    Starts its own ORB, connects to the nameserver, and scans it periodically.
 *    Interceptors are registered but only capture traffic if this ORB is used
 *    as a client to invoke CORBA objects.
 *
 *    Usage:
 *      java -jar corba-interceptor.jar
 *
 * 2. EMBEDDED MODE (ORBInitializer):
 *    Add the JAR to an existing CORBA application's classpath and register
 *    the interceptor via JVM property. All traffic through that ORB is captured.
 *
 *    Usage:
 *      java -Dorg.omg.PortableInterceptor.ORBInitializerClass.com.corbamonitor.interceptor.MonitorORBInitializer= \
 *           -cp "your-app.jar:corba-interceptor.jar" \
 *           com.yourapp.Main
 *
 * In both modes, traffic events are sent asynchronously to the Laravel Monitor API.
 */
public class CORBAMonitorAgent {

    private static final Logger log = LoggerFactory.getLogger(CORBAMonitorAgent.class);

    private org.omg.CORBA.ORB orb;
    private NameserverScanner scanner;
    private NameserviceBridge bridge;
    private MonitorApiClient apiClient;

    public static void main(String[] args) {
        CORBAMonitorAgent agent = new CORBAMonitorAgent();
        agent.start(args);
    }

    public void start(String[] args) {
        log.info("╔══════════════════════════════════════════════════╗");
        log.info("║       CORBA Monitor Agent v1.0.0                ║");
        log.info("║       Standalone Mode                           ║");
        log.info("╚══════════════════════════════════════════════════╝");

        MonitorConfig config = MonitorConfig.getInstance();
        log.info("Configuration: {}", config);

        if (!config.isEnabled()) {
            log.warn("Monitor is DISABLED. Set monitor.enabled=true to activate.");
            return;
        }

        // Initialize API client
        apiClient = MonitorApiClient.getInstance();

        // Health check
        if (apiClient.healthCheck()) {
            log.info("✓ Monitor API is reachable at {}", config.getApiBaseUrl());
        } else {
            log.warn("✗ Monitor API is NOT reachable at {} — events will be queued",
                    config.getApiBaseUrl());
        }

        // Initialize ORB with interceptor registration
        initORB(args, config);

        // Start nameserver scanner
        scanner = new NameserverScanner(orb);
        scanner.start();

        // Start Nameservice Bridge (HTTP REST API for the Laravel app)
        if (config.isBridgeEnabled()) {
            startBridge(config);
        }

        // Register shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown, "corba-monitor-shutdown"));

        log.info("Agent running. Press Ctrl+C to stop.");

        // Keep alive — the ORB run loop keeps the agent responsive
        try {
            orb.run();
        } catch (Exception e) {
            log.info("ORB run loop ended: {}", e.getMessage());
        }
    }

    /**
     * Start the Nameservice Bridge HTTP server.
     */
    private void startBridge(MonitorConfig config) {
        try {
            bridge = new NameserviceBridge(orb, config.getBridgePort());
            bridge.start();
            log.info("✓ Nameservice Bridge started on port {}", config.getBridgePort());
        } catch (Exception e) {
            log.error("✗ Failed to start Nameservice Bridge: {}", e.getMessage());
        }
    }

    /**
     * Initialize the ORB with JacORB properties and interceptor registration.
     */
    private void initORB(String[] args, MonitorConfig config) {
        Properties orbProps = new Properties();

        // JacORB configuration
        orbProps.setProperty("org.omg.CORBA.ORBClass", "org.jacorb.orb.ORB");
        orbProps.setProperty("org.omg.CORBA.ORBSingletonClass", "org.jacorb.orb.ORBSingleton");

        // Register our interceptor initializer
        orbProps.setProperty(
                "org.omg.PortableInterceptor.ORBInitializerClass.com.corbamonitor.interceptor.MonitorORBInitializer",
                ""
        );

        // Nameserver connection
        String corbaloc = String.format("corbaloc:iiop:%s:%d/NameService",
                config.getNameserverHost(), config.getNameserverPort());
        orbProps.setProperty("ORBInitRef.NameService", corbaloc);

        // JacORB-specific tuning
        orbProps.setProperty("jacorb.connection.client.connect_timeout", "5000");
        orbProps.setProperty("jacorb.retries", "3");
        orbProps.setProperty("jacorb.retry_interval", "500");
        orbProps.setProperty("jacorb.log.default.verbosity", "1");

        log.info("Initializing ORB (nameserver={}:{})", config.getNameserverHost(), config.getNameserverPort());

        orb = org.omg.CORBA.ORB.init(args, orbProps);

        log.info("✓ ORB initialized");
    }

    /**
     * Graceful shutdown.
     */
    private void shutdown() {
        log.info("Shutting down CORBA Monitor Agent...");

        if (scanner != null) {
            scanner.stop();
        }

        if (apiClient != null) {
            apiClient.shutdown();
        }

        if (orb != null) {
            try {
                orb.shutdown(false);
            } catch (Exception ignored) {}
        }

        log.info("Agent stopped. Stats: sent={}, failed={}, dropped={}",
                apiClient != null ? apiClient.getSentCount() : 0,
                apiClient != null ? apiClient.getFailedCount() : 0,
                apiClient != null ? apiClient.getDroppedCount() : 0);
    }
}
