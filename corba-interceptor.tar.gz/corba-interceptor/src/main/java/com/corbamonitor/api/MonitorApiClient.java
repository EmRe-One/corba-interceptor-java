package com.corbamonitor.api;

import com.corbamonitor.config.MonitorConfig;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import javax.net.ssl.*;
import java.security.cert.X509Certificate;

/**
 * Async HTTP client that batches TrafficEvents and sends them to the Monitor API.
 *
 * Features:
 * - Non-blocking: interceptors submit events to a queue
 * - Batching: events are grouped and sent in bulk
 * - Auto-flush: periodic flush based on configurable interval
 * - Retry: failed batches are retried once
 * - Metrics: tracks sent/failed/queued counts
 */
public class MonitorApiClient {

    private static final Logger log = LoggerFactory.getLogger(MonitorApiClient.class);
    private static MonitorApiClient instance;

    private final MonitorConfig config;
    private final Gson gson;
    private final BlockingQueue<TrafficEvent> eventQueue;
    private final ExecutorService httpPool;
    private final ScheduledExecutorService scheduler;
    private final AtomicLong sentCount = new AtomicLong(0);
    private final AtomicLong failedCount = new AtomicLong(0);
    private final AtomicLong droppedCount = new AtomicLong(0);
    private volatile boolean running = true;

    private static final int MAX_QUEUE_SIZE = 10_000;

    private MonitorApiClient() {
        this.config = MonitorConfig.getInstance();
        this.gson = new GsonBuilder()
                .disableHtmlEscaping()
                .serializeNulls()
                .create();
        this.eventQueue = new LinkedBlockingQueue<>(MAX_QUEUE_SIZE);
        this.httpPool = Executors.newFixedThreadPool(config.getHttpPoolSize(), r -> {
            Thread t = new Thread(r, "corba-monitor-http");
            t.setDaemon(true);
            return t;
        });
        this.scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "corba-monitor-flush");
            t.setDaemon(true);
            return t;
        });

        // Disable SSL verification in dev mode
        if (config.isSslTrustAll()) {
            disableSslVerification();
            log.warn("SSL verification DISABLED — do NOT use in production");
        }

        // Schedule periodic flush
        scheduler.scheduleAtFixedRate(
                this::flush,
                config.getFlushIntervalMs(),
                config.getFlushIntervalMs(),
                TimeUnit.MILLISECONDS
        );

        log.info("MonitorApiClient started: {}", config);
    }

    public static synchronized MonitorApiClient getInstance() {
        if (instance == null) {
            instance = new MonitorApiClient();
        }
        return instance;
    }

    /**
     * Submit a traffic event (non-blocking).
     * If the queue is full, the event is dropped and counted.
     */
    public void submit(TrafficEvent event) {
        if (!config.isEnabled() || !running) return;

        boolean added = eventQueue.offer(event);
        if (!added) {
            droppedCount.incrementAndGet();
            if (droppedCount.get() % 100 == 0) {
                log.warn("Event queue full — dropped {} events so far", droppedCount.get());
            }
        }
    }

    /**
     * Drain the queue and send events in batches.
     */
    public void flush() {
        if (eventQueue.isEmpty()) return;

        List<TrafficEvent> batch = new ArrayList<>(config.getBatchSize());
        eventQueue.drainTo(batch, config.getBatchSize());

        if (!batch.isEmpty()) {
            httpPool.submit(() -> sendBatch(batch));
        }

        // If there are more, schedule additional flushes
        while (!eventQueue.isEmpty()) {
            List<TrafficEvent> nextBatch = new ArrayList<>(config.getBatchSize());
            eventQueue.drainTo(nextBatch, config.getBatchSize());
            if (!nextBatch.isEmpty()) {
                httpPool.submit(() -> sendBatch(nextBatch));
            }
        }
    }

    /**
     * Send a batch of events to the API.
     */
    private void sendBatch(List<TrafficEvent> batch) {
        if (batch.size() == 1) {
            sendSingle(batch.get(0));
            return;
        }

        try {
            Map<String, Object> payload = new HashMap<>();
            payload.put("events", batch);
            String json = gson.toJson(payload);

            int status = post(config.getBatchEndpoint(), json);

            if (status >= 200 && status < 300) {
                sentCount.addAndGet(batch.size());
                log.debug("Sent batch of {} events (total: {})", batch.size(), sentCount.get());
            } else {
                failedCount.addAndGet(batch.size());
                log.warn("Batch send failed with HTTP {}: {} events lost", status, batch.size());
            }
        } catch (Exception e) {
            failedCount.addAndGet(batch.size());
            log.error("Batch send error: {}", e.getMessage());
        }
    }

    /**
     * Send a single event.
     */
    private void sendSingle(TrafficEvent event) {
        try {
            String json = gson.toJson(event);
            int status = post(config.getTrafficEndpoint(), json);

            if (status >= 200 && status < 300) {
                sentCount.incrementAndGet();
                log.debug("Sent event: {} (total: {})", event.getOperation(), sentCount.get());
            } else {
                failedCount.incrementAndGet();
                log.warn("Event send failed with HTTP {}: {}", status, event.getOperation());
            }
        } catch (Exception e) {
            failedCount.incrementAndGet();
            log.error("Event send error: {}", e.getMessage());
        }
    }

    /**
     * HTTP POST with JSON body.
     */
    private int post(String endpoint, String json) throws IOException {
        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        // Apply SSL trust-all to individual HTTPS connections
        if (conn instanceof HttpsURLConnection && config.isSslTrustAll()) {
            applyTrustAll((HttpsURLConnection) conn);
        }

        try {
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(config.getHttpTimeoutMs());
            conn.setReadTimeout(config.getHttpTimeoutMs());
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Accept", "application/json");

            String token = config.getApiToken();
            if (token != null && !token.isEmpty()) {
                conn.setRequestProperty("Authorization", "Bearer " + token);
            }

            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(bytes);
                os.flush();
            }

            return conn.getResponseCode();
        } finally {
            conn.disconnect();
        }
    }

    /**
     * Check if the Monitor API is reachable.
     */
    public boolean healthCheck() {
        try {
            URL url = new URL(config.getHealthEndpoint());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if (conn instanceof HttpsURLConnection && config.isSslTrustAll()) {
                applyTrustAll((HttpsURLConnection) conn);
            }
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            int status = conn.getResponseCode();
            conn.disconnect();
            return status == 200;
        } catch (Exception e) {
            return false;
        }
    }

    // ─── SSL Trust-All (Development Only) ─────────────────────────────

    private static SSLSocketFactory trustAllSocketFactory;
    private static HostnameVerifier trustAllHostnameVerifier;

    /**
     * Disable SSL certificate verification globally.
     * WARNING: Only for local development!
     */
    private void disableSslVerification() {
        try {
            TrustManager[] trustAll = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                    public void checkServerTrusted(X509Certificate[] certs, String authType) {}
                }
            };

            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAll, new java.security.SecureRandom());
            trustAllSocketFactory = sc.getSocketFactory();
            trustAllHostnameVerifier = (hostname, session) -> true;

            // Also set as default for any other HTTPS connections
            HttpsURLConnection.setDefaultSSLSocketFactory(trustAllSocketFactory);
            HttpsURLConnection.setDefaultHostnameVerifier(trustAllHostnameVerifier);

        } catch (Exception e) {
            log.error("Failed to disable SSL verification: {}", e.getMessage());
        }
    }

    /**
     * Apply trust-all settings to a specific HTTPS connection.
     */
    private void applyTrustAll(HttpsURLConnection conn) {
        if (trustAllSocketFactory != null) {
            conn.setSSLSocketFactory(trustAllSocketFactory);
        }
        if (trustAllHostnameVerifier != null) {
            conn.setHostnameVerifier(trustAllHostnameVerifier);
        }
    }

    /**
     * Graceful shutdown: flush remaining events and stop threads.
     */
    public void shutdown() {
        log.info("Shutting down MonitorApiClient...");
        running = false;
        flush();
        scheduler.shutdown();
        httpPool.shutdown();
        try {
            httpPool.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        log.info("MonitorApiClient shutdown complete. Sent: {}, Failed: {}, Dropped: {}",
                sentCount.get(), failedCount.get(), droppedCount.get());
    }

    // Metrics

    public long getSentCount() { return sentCount.get(); }
    public long getFailedCount() { return failedCount.get(); }
    public long getDroppedCount() { return droppedCount.get(); }
    public int getQueueSize() { return eventQueue.size(); }
}
