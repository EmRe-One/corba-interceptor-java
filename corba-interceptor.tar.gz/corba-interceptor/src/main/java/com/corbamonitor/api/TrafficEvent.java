package com.corbamonitor.api;

import com.google.gson.annotations.SerializedName;
import java.time.Instant;
import java.util.Map;

/**
 * Data Transfer Object for a single CORBA traffic event.
 * Maps to POST /api/traffic on the Laravel backend.
 */
public class TrafficEvent {

    @SerializedName("request_id")
    private String requestId;

    @SerializedName("operation")
    private String operation;

    @SerializedName("interface_name")
    private String interfaceName;

    @SerializedName("repository_id")
    private String repositoryId;

    @SerializedName("direction")
    private String direction; // "request" or "reply"

    @SerializedName("status")
    private String status; // "success", "error", "timeout", "exception"

    @SerializedName("source_host")
    private String sourceHost;

    @SerializedName("source_port")
    private Integer sourcePort;

    @SerializedName("target_host")
    private String targetHost;

    @SerializedName("target_port")
    private Integer targetPort;

    @SerializedName("source_service_name")
    private String sourceServiceName;

    @SerializedName("target_service_name")
    private String targetServiceName;

    @SerializedName("request_data")
    private Object requestData;

    @SerializedName("response_data")
    private Object responseData;

    @SerializedName("error_message")
    private String errorMessage;

    @SerializedName("exception_type")
    private String exceptionType;

    @SerializedName("latency_ms")
    private Double latencyMs;

    @SerializedName("giop_version")
    private String giopVersion;

    @SerializedName("message_type")
    private String messageType;

    @SerializedName("request_size_bytes")
    private Integer requestSizeBytes;

    @SerializedName("response_size_bytes")
    private Integer responseSizeBytes;

    @SerializedName("interceptor_point")
    private String interceptorPoint;

    @SerializedName("context_data")
    private Map<String, Object> contextData;

    @SerializedName("timestamp")
    private String timestamp;

    public TrafficEvent() {
        this.timestamp = Instant.now().toString();
    }

    // Builder-style setters

    public TrafficEvent requestId(String requestId) { this.requestId = requestId; return this; }
    public TrafficEvent operation(String operation) { this.operation = operation; return this; }
    public TrafficEvent interfaceName(String interfaceName) { this.interfaceName = interfaceName; return this; }
    public TrafficEvent repositoryId(String repositoryId) { this.repositoryId = repositoryId; return this; }
    public TrafficEvent direction(String direction) { this.direction = direction; return this; }
    public TrafficEvent status(String status) { this.status = status; return this; }
    public TrafficEvent sourceHost(String sourceHost) { this.sourceHost = sourceHost; return this; }
    public TrafficEvent sourcePort(Integer sourcePort) { this.sourcePort = sourcePort; return this; }
    public TrafficEvent targetHost(String targetHost) { this.targetHost = targetHost; return this; }
    public TrafficEvent targetPort(Integer targetPort) { this.targetPort = targetPort; return this; }
    public TrafficEvent sourceServiceName(String name) { this.sourceServiceName = name; return this; }
    public TrafficEvent targetServiceName(String name) { this.targetServiceName = name; return this; }
    public TrafficEvent requestData(Object data) { this.requestData = data; return this; }
    public TrafficEvent responseData(Object data) { this.responseData = data; return this; }
    public TrafficEvent errorMessage(String msg) { this.errorMessage = msg; return this; }
    public TrafficEvent exceptionType(String type) { this.exceptionType = type; return this; }
    public TrafficEvent latencyMs(Double ms) { this.latencyMs = ms; return this; }
    public TrafficEvent giopVersion(String version) { this.giopVersion = version; return this; }
    public TrafficEvent messageType(String type) { this.messageType = type; return this; }
    public TrafficEvent requestSizeBytes(Integer bytes) { this.requestSizeBytes = bytes; return this; }
    public TrafficEvent responseSizeBytes(Integer bytes) { this.responseSizeBytes = bytes; return this; }
    public TrafficEvent interceptorPoint(String point) { this.interceptorPoint = point; return this; }
    public TrafficEvent contextData(Map<String, Object> data) { this.contextData = data; return this; }
    public TrafficEvent timestamp(String ts) { this.timestamp = ts; return this; }

    // Getters
    public String getRequestId() { return requestId; }
    public String getOperation() { return operation; }
    public String getInterfaceName() { return interfaceName; }
    public String getDirection() { return direction; }
    public String getStatus() { return status; }
    public Double getLatencyMs() { return latencyMs; }
    public String getTimestamp() { return timestamp; }

    @Override
    public String toString() {
        return String.format("TrafficEvent{op=%s, iface=%s, dir=%s, status=%s, latency=%.1fms}",
            operation, interfaceName, direction, status, latencyMs != null ? latencyMs : 0.0);
    }
}
