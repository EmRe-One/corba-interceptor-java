package com.corbamonitor.bridge;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import com.corbamonitor.config.MonitorConfig;
import org.omg.CORBA.ORB;
import org.omg.CORBA.Object;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.Executors;

/**
 * CORBA Nameservice Bridge — HTTP REST API for the Laravel Monitor.
 *
 * Connects to a live CORBA Naming Service via JacORB and exposes
 * its operations as simple HTTP endpoints that PHP can call.
 *
 * ┌────────────────┐      HTTP        ┌──────────────────┐      IIOP       ┌────────────────┐
 * │  Laravel App   │ ───────────────→ │  Nameservice     │ ──────────────→ │  CORBA         │
 * │  (PHP)         │  :9090/api/...   │  Bridge (Java)   │  :2809          │  Naming Service│
 * └────────────────┘                  └──────────────────┘                 └────────────────┘
 *
 * Endpoints:
 *   GET /api/naming/health              → { "status": "ok", "connected": true }
 *   GET /api/naming/list?context=       → { "bindings": [...] }
 *   GET /api/naming/resolve?name=       → { "ior": "IOR:...", "type_id": "..." }
 *   GET /api/naming/ior-info?ior=       → { "host": "...", "port": ..., "type_id": "..." }
 *   GET /api/naming/ping?ior=           → { "alive": true/false }
 *   GET /api/naming/tree                → { "tree": [...] } (full recursive scan)
 */
public class NameserviceBridge {

    private static final Logger log = LoggerFactory.getLogger(NameserviceBridge.class);
    private static final Gson gson = new GsonBuilder().disableHtmlEscaping().serializeNulls().create();

    private final ORB orb;
    private final int httpPort;
    private NamingContextExt rootContext;

    // ─── Constructor ────────────────────────────────────────────

    public NameserviceBridge(ORB orb, int httpPort) {
        this.orb = orb;
        this.httpPort = httpPort;
    }

    // ─── Start HTTP Server ──────────────────────────────────────

    public void start() throws Exception {
        // Connect to Naming Service
        connectToNamingService();

        // Start HTTP server
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", httpPort), 0);
        server.setExecutor(Executors.newFixedThreadPool(4));

        server.createContext("/api/naming/health",  this::handleHealth);
        server.createContext("/api/naming/list",    this::handleList);
        server.createContext("/api/naming/resolve", this::handleResolve);
        server.createContext("/api/naming/ior-info",this::handleIorInfo);
        server.createContext("/api/naming/ping",    this::handlePing);
        server.createContext("/api/naming/tree",    this::handleTree);

        server.start();

        log.info("╔══════════════════════════════════════════════════╗");
        log.info("║   Nameservice Bridge — HTTP REST API             ║");
        log.info("║   Port: {}                                      ║", httpPort);
        log.info("╚══════════════════════════════════════════════════╝");
        log.info("Endpoints:");
        log.info("  GET /api/naming/health");
        log.info("  GET /api/naming/list?context=<path>");
        log.info("  GET /api/naming/resolve?name=<path>");
        log.info("  GET /api/naming/ior-info?ior=<ior>");
        log.info("  GET /api/naming/ping?ior=<ior>");
        log.info("  GET /api/naming/tree");
    }

    // ─── Connect to CORBA Naming Service ────────────────────────

    private void connectToNamingService() {
        try {
            org.omg.CORBA.Object nsObj = orb.resolve_initial_references("NameService");
            rootContext = NamingContextExtHelper.narrow(nsObj);
            log.info("✓ Connected to CORBA Naming Service");
        } catch (Exception e) {
            log.warn("Could not connect to Naming Service: {}. Will retry on requests.", e.getMessage());
            rootContext = null;
        }
    }

    /**
     * Ensure we have a valid naming context, reconnect if needed.
     */
    private NamingContextExt getNamingContext() {
        if (rootContext != null) {
            // Quick check: try a simple operation
            try {
                rootContext._non_existent();
                return rootContext;
            } catch (Exception e) {
                log.info("Naming Service connection lost, reconnecting...");
                rootContext = null;
            }
        }

        // Reconnect
        try {
            org.omg.CORBA.Object nsObj = orb.resolve_initial_references("NameService");
            rootContext = NamingContextExtHelper.narrow(nsObj);
            log.info("✓ Reconnected to Naming Service");
            return rootContext;
        } catch (Exception e) {
            log.error("Cannot connect to Naming Service: {}", e.getMessage());
            return null;
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  HTTP Handlers
    // ═══════════════════════════════════════════════════════════

    // ─── GET /api/naming/health ─────────────────────────────────

    private void handleHealth(HttpExchange exchange) throws IOException {
        if (!checkMethod(exchange, "GET")) return;

        Map<String, java.lang.Object> result = new LinkedHashMap<>();
        result.put("status", "ok");
        result.put("bridge_port", httpPort);

        NamingContextExt ctx = getNamingContext();
        result.put("connected", ctx != null);

        if (ctx != null) {
            try {
                // Try listing root to verify full connectivity
                BindingListHolder blh = new BindingListHolder();
                BindingIteratorHolder bih = new BindingIteratorHolder();
                ctx.list(1, blh, bih);
                result.put("naming_service", "reachable");

                // Cleanup iterator
                if (bih.value != null) {
                    try { bih.value.destroy(); } catch (Exception ignored) {}
                }
            } catch (Exception e) {
                result.put("naming_service", "error: " + e.getMessage());
            }
        } else {
            result.put("naming_service", "disconnected");
        }

        sendJson(exchange, 200, result);
    }

    // ─── GET /api/naming/list?context=<path> ────────────────────

    private void handleList(HttpExchange exchange) throws IOException {
        if (!checkMethod(exchange, "GET")) return;

        NamingContextExt ctx = getNamingContext();
        if (ctx == null) {
            sendError(exchange, 503, "Naming Service not available");
            return;
        }

        Map<String, String> params = parseQuery(exchange.getRequestURI());
        String contextPath = params.getOrDefault("context", "");

        try {
            // Get the target context
            NamingContext targetCtx;
            if (contextPath.isEmpty()) {
                targetCtx = ctx;
            } else {
                NameComponent[] name = ctx.to_name(contextPath);
                org.omg.CORBA.Object obj = ctx.resolve(name);
                targetCtx = NamingContextHelper.narrow(obj);
            }

            // List all bindings
            BindingListHolder blh = new BindingListHolder();
            BindingIteratorHolder bih = new BindingIteratorHolder();
            targetCtx.list(1000, blh, bih); // Get up to 1000 bindings

            List<Map<String, java.lang.Object>> bindings = new ArrayList<>();

            for (Binding b : blh.value) {
                Map<String, java.lang.Object> binding = new LinkedHashMap<>();
                binding.put("name", b.binding_name[0].id);
                binding.put("kind", b.binding_name[0].kind.isEmpty()
                    ? (b.binding_type.value() == BindingType._ncontext ? "ncontext" : "nobject")
                    : b.binding_name[0].kind);
                binding.put("type", b.binding_type.value() == BindingType._ncontext ? "context" : "object");

                String fullPath = contextPath.isEmpty()
                    ? b.binding_name[0].id
                    : contextPath + "/" + b.binding_name[0].id;
                binding.put("path", fullPath);

                bindings.add(binding);
            }

            // Handle remaining bindings from iterator
            if (bih.value != null) {
                BindingHolder bHolder = new BindingHolder();
                while (bih.value.next_one(bHolder)) {
                    Binding b = bHolder.value;
                    Map<String, java.lang.Object> binding = new LinkedHashMap<>();
                    binding.put("name", b.binding_name[0].id);
                    binding.put("kind", b.binding_name[0].kind);
                    binding.put("type", b.binding_type.value() == BindingType._ncontext ? "context" : "object");
                    bindings.add(binding);
                }
                try { bih.value.destroy(); } catch (Exception ignored) {}
            }

            Map<String, java.lang.Object> result = new LinkedHashMap<>();
            result.put("context", contextPath.isEmpty() ? "/" : contextPath);
            result.put("count", bindings.size());
            result.put("bindings", bindings);

            log.debug("LIST {} → {} bindings", contextPath.isEmpty() ? "/" : contextPath, bindings.size());
            sendJson(exchange, 200, result);

        } catch (NotFound e) {
            sendError(exchange, 404, "Context not found: " + contextPath);
        } catch (Exception e) {
            log.error("List error for '{}': {}", contextPath, e.getMessage());
            sendError(exchange, 500, e.getMessage());
        }
    }

    // ─── GET /api/naming/resolve?name=<path> ────────────────────

    private void handleResolve(HttpExchange exchange) throws IOException {
        if (!checkMethod(exchange, "GET")) return;

        NamingContextExt ctx = getNamingContext();
        if (ctx == null) {
            sendError(exchange, 503, "Naming Service not available");
            return;
        }

        Map<String, String> params = parseQuery(exchange.getRequestURI());
        String namePath = params.get("name");
        if (namePath == null || namePath.isEmpty()) {
            sendError(exchange, 400, "Missing 'name' parameter");
            return;
        }

        try {
            org.omg.CORBA.Object obj = ctx.resolve_str(namePath);
            String ior = orb.object_to_string(obj);

            Map<String, java.lang.Object> result = new LinkedHashMap<>();
            result.put("name", namePath);
            result.put("ior", ior);

            // Extract type_id from the object if possible
            try {
                String repoId = obj._get_interface_def() != null
                    ? obj._get_interface_def().toString()
                    : null;
                result.put("repository_id", repoId);
            } catch (Exception e) {
                // Many objects don't support _get_interface_def
                result.put("repository_id", null);
            }

            // Parse IOR for host/port
            Map<String, java.lang.Object> iorInfo = parseIor(ior);
            result.putAll(iorInfo);

            log.debug("RESOLVE {} → {}:{}", namePath, iorInfo.get("host"), iorInfo.get("port"));
            sendJson(exchange, 200, result);

        } catch (NotFound e) {
            sendError(exchange, 404, "Name not found: " + namePath);
        } catch (CannotProceed e) {
            sendError(exchange, 500, "Cannot proceed resolving: " + namePath);
        } catch (InvalidName e) {
            sendError(exchange, 400, "Invalid name: " + namePath);
        } catch (Exception e) {
            log.error("Resolve error for '{}': {}", namePath, e.getMessage());
            sendError(exchange, 500, e.getMessage());
        }
    }

    // ─── GET /api/naming/ior-info?ior=<ior> ─────────────────────

    private void handleIorInfo(HttpExchange exchange) throws IOException {
        if (!checkMethod(exchange, "GET")) return;

        Map<String, String> params = parseQuery(exchange.getRequestURI());
        String ior = params.get("ior");
        if (ior == null || ior.isEmpty()) {
            sendError(exchange, 400, "Missing 'ior' parameter");
            return;
        }

        try {
            Map<String, java.lang.Object> result = parseIor(ior);
            sendJson(exchange, 200, result);
        } catch (Exception e) {
            sendError(exchange, 400, "Invalid IOR: " + e.getMessage());
        }
    }

    // ─── GET /api/naming/ping?ior=<ior> ─────────────────────────

    private void handlePing(HttpExchange exchange) throws IOException {
        if (!checkMethod(exchange, "GET")) return;

        Map<String, String> params = parseQuery(exchange.getRequestURI());
        String ior = params.get("ior");

        // Also accept 'name' parameter to resolve first
        String name = params.get("name");

        if ((ior == null || ior.isEmpty()) && (name == null || name.isEmpty())) {
            sendError(exchange, 400, "Missing 'ior' or 'name' parameter");
            return;
        }

        Map<String, java.lang.Object> result = new LinkedHashMap<>();

        try {
            org.omg.CORBA.Object obj;
            if (name != null && !name.isEmpty()) {
                NamingContextExt ctx = getNamingContext();
                if (ctx == null) {
                    sendError(exchange, 503, "Naming Service not available");
                    return;
                }
                obj = ctx.resolve_str(name);
                result.put("name", name);
            } else {
                obj = orb.string_to_object(ior);
            }

            // _non_existent() returns true if object does NOT exist
            boolean alive = !obj._non_existent();

            result.put("alive", alive);
            result.put("ior", orb.object_to_string(obj));

            log.debug("PING {} → {}", name != null ? name : "IOR", alive ? "ALIVE" : "DEAD");

        } catch (Exception e) {
            result.put("alive", false);
            result.put("error", e.getClass().getSimpleName() + ": " + e.getMessage());
            log.debug("PING {} → UNREACHABLE: {}", name != null ? name : "IOR", e.getMessage());
        }

        sendJson(exchange, 200, result);
    }

    // ─── GET /api/naming/tree ───────────────────────────────────

    private void handleTree(HttpExchange exchange) throws IOException {
        if (!checkMethod(exchange, "GET")) return;

        NamingContextExt ctx = getNamingContext();
        if (ctx == null) {
            sendError(exchange, 503, "Naming Service not available");
            return;
        }

        try {
            List<Map<String, java.lang.Object>> tree = new ArrayList<>();
            scanContextRecursive(ctx, "", tree);

            Map<String, java.lang.Object> result = new LinkedHashMap<>();
            result.put("count", tree.size());
            result.put("tree", tree);

            log.info("TREE → {} entries", tree.size());
            sendJson(exchange, 200, result);

        } catch (Exception e) {
            log.error("Tree scan error: {}", e.getMessage());
            sendError(exchange, 500, e.getMessage());
        }
    }

    /**
     * Recursively scan the naming tree.
     */
    private void scanContextRecursive(NamingContext ctx, String prefix,
                                       List<Map<String, java.lang.Object>> entries) {
        try {
            BindingListHolder blh = new BindingListHolder();
            BindingIteratorHolder bih = new BindingIteratorHolder();
            ctx.list(1000, blh, bih);

            for (Binding b : blh.value) {
                String name = b.binding_name[0].id;
                String kind = b.binding_name[0].kind;
                String fullPath = prefix.isEmpty() ? name : prefix + "/" + name;
                boolean isContext = b.binding_type.value() == BindingType._ncontext;

                Map<String, java.lang.Object> entry = new LinkedHashMap<>();
                entry.put("path", fullPath);
                entry.put("name", name);
                entry.put("kind", kind.isEmpty() ? (isContext ? "ncontext" : "nobject") : kind);
                entry.put("type", isContext ? "context" : "object");

                if (!isContext) {
                    // Resolve to get IOR and host/port
                    try {
                        NamingContextExt extCtx = NamingContextExtHelper.narrow(
                            prefix.isEmpty() ? ctx : rootContext
                        );
                        org.omg.CORBA.Object obj = extCtx.resolve_str(fullPath);
                        String ior = orb.object_to_string(obj);
                        entry.put("ior", ior);

                        Map<String, java.lang.Object> iorInfo = parseIor(ior);
                        entry.put("host", iorInfo.get("host"));
                        entry.put("port", iorInfo.get("port"));
                        entry.put("type_id", iorInfo.get("type_id"));

                        // Ping
                        try {
                            boolean alive = !obj._non_existent();
                            entry.put("is_alive", alive);
                        } catch (Exception e) {
                            entry.put("is_alive", false);
                        }
                    } catch (Exception e) {
                        entry.put("ior", null);
                        entry.put("is_alive", false);
                        entry.put("error", e.getMessage());
                    }
                }

                entries.add(entry);

                // Recurse into sub-contexts
                if (isContext) {
                    try {
                        NamingContextExt extCtx = NamingContextExtHelper.narrow(
                            prefix.isEmpty() ? ctx : rootContext
                        );
                        NameComponent[] ncName = extCtx.to_name(fullPath);
                        org.omg.CORBA.Object subObj = rootContext.resolve(ncName);
                        NamingContext subCtx = NamingContextHelper.narrow(subObj);
                        scanContextRecursive(subCtx, fullPath, entries);
                    } catch (Exception e) {
                        log.warn("Cannot recurse into {}: {}", fullPath, e.getMessage());
                    }
                }
            }

            // Handle remaining bindings from iterator
            if (bih.value != null) {
                try { bih.value.destroy(); } catch (Exception ignored) {}
            }

        } catch (Exception e) {
            log.error("Scan error at '{}': {}", prefix, e.getMessage());
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  IOR Parsing
    // ═══════════════════════════════════════════════════════════

    /**
     * Parse an IOR string to extract host, port, type_id.
     *
     * IOR format (hex after "IOR:"):
     *   - byte_order (4 bytes)
     *   - type_id string (length-prefixed)
     *   - tagged profiles (containing IIOP profile with host/port)
     */
    static Map<String, java.lang.Object> parseIor(String ior) {
        Map<String, java.lang.Object> result = new LinkedHashMap<>();

        if (ior == null || !ior.startsWith("IOR:")) {
            result.put("error", "Invalid IOR format");
            return result;
        }

        try {
            String hex = ior.substring(4);
            byte[] data = hexToBytes(hex);

            if (data.length < 12) {
                result.put("error", "IOR too short");
                return result;
            }

            // Byte order: 0 = big-endian, 1 = little-endian
            boolean littleEndian = data[0] != 0;
            int pos = 4; // skip padding/alignment

            // Read type_id (string with length prefix)
            int typeIdLen = readInt(data, pos, littleEndian);
            pos += 4;
            if (typeIdLen > 0 && pos + typeIdLen <= data.length) {
                String typeId = new String(data, pos, typeIdLen - 1, StandardCharsets.US_ASCII); // -1 for null terminator
                result.put("type_id", typeId);
                pos += typeIdLen;
            }

            // Align to 4 bytes
            pos = align(pos, 4);

            // Number of tagged profiles
            if (pos + 4 <= data.length) {
                int profileCount = readInt(data, pos, littleEndian);
                pos += 4;
                result.put("profile_count", profileCount);

                // First profile is usually IIOP (tag = 0)
                if (profileCount > 0 && pos + 8 <= data.length) {
                    int tag = readInt(data, pos, littleEndian);
                    pos += 4;
                    int profileLen = readInt(data, pos, littleEndian);
                    pos += 4;

                    if (tag == 0 && pos + profileLen <= data.length) {
                        // IIOP Profile Body
                        int profileStart = pos;

                        // GIOP version
                        if (pos + 2 <= data.length) {
                            int major = data[pos] & 0xFF;
                            int minor = data[pos + 1] & 0xFF;
                            result.put("giop_version", major + "." + minor);
                            pos += 2;
                        }

                        // In GIOP 1.1+, there might be different byte order for profile
                        // Read host string
                        pos = align(pos, 4);
                        if (pos + 4 <= data.length) {
                            int hostLen = readInt(data, pos, littleEndian);
                            pos += 4;
                            if (hostLen > 0 && pos + hostLen <= data.length) {
                                String host = new String(data, pos, hostLen - 1, StandardCharsets.US_ASCII);
                                result.put("host", host);
                                pos += hostLen;
                            }
                        }

                        // Read port (unsigned short)
                        pos = align(pos, 2);
                        if (pos + 2 <= data.length) {
                            int port = readShort(data, pos, littleEndian);
                            result.put("port", port);
                        }
                    }
                }
            }

            result.put("ior_length", data.length);

        } catch (Exception e) {
            result.put("parse_error", e.getMessage());
        }

        return result;
    }

    private static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }

    private static int readInt(byte[] data, int offset, boolean littleEndian) {
        if (littleEndian) {
            return (data[offset] & 0xFF) | ((data[offset + 1] & 0xFF) << 8)
                    | ((data[offset + 2] & 0xFF) << 16) | ((data[offset + 3] & 0xFF) << 24);
        } else {
            return ((data[offset] & 0xFF) << 24) | ((data[offset + 1] & 0xFF) << 16)
                    | ((data[offset + 2] & 0xFF) << 8) | (data[offset + 3] & 0xFF);
        }
    }

    private static int readShort(byte[] data, int offset, boolean littleEndian) {
        if (littleEndian) {
            return (data[offset] & 0xFF) | ((data[offset + 1] & 0xFF) << 8);
        } else {
            return ((data[offset] & 0xFF) << 8) | (data[offset + 1] & 0xFF);
        }
    }

    private static int align(int pos, int boundary) {
        int mod = pos % boundary;
        return mod == 0 ? pos : pos + (boundary - mod);
    }

    // ═══════════════════════════════════════════════════════════
    //  HTTP Helpers
    // ═══════════════════════════════════════════════════════════

    private boolean checkMethod(HttpExchange exchange, String expected) throws IOException {
        // Handle CORS preflight
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type, Authorization");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            exchange.close();
            return false;
        }

        if (!expected.equalsIgnoreCase(exchange.getRequestMethod())) {
            sendError(exchange, 405, "Method not allowed");
            return false;
        }
        return true;
    }

    private void sendJson(HttpExchange exchange, int code, java.lang.Object data) throws IOException {
        String json = gson.toJson(data);
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);

        exchange.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(code, bytes.length);

        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void sendError(HttpExchange exchange, int code, String message) throws IOException {
        Map<String, java.lang.Object> error = new LinkedHashMap<>();
        error.put("error", true);
        error.put("code", code);
        error.put("message", message);
        sendJson(exchange, code, error);
    }

    private Map<String, String> parseQuery(URI uri) {
        Map<String, String> params = new LinkedHashMap<>();
        String query = uri.getRawQuery();
        if (query == null || query.isEmpty()) return params;

        for (String param : query.split("&")) {
            String[] kv = param.split("=", 2);
            String key = URLDecoder.decode(kv[0], StandardCharsets.UTF_8);
            String value = kv.length > 1 ? URLDecoder.decode(kv[1], StandardCharsets.UTF_8) : "";
            params.put(key, value);
        }
        return params;
    }
}
