package com.corbamonitor.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Configuration for the CORBA Monitor Agent.
 * Reads from monitor.properties, system properties, or environment variables.
 *
 * Priority: System Property > Environment Variable > Properties File > Default
 */
public class MonitorConfig {

    private static final String PROPS_FILE = "monitor.properties";
    private static MonitorConfig instance;

    private final String apiBaseUrl;
    private final String apiToken;
    private final int batchSize;
    private final int flushIntervalMs;
    private final int httpTimeoutMs;
    private final int httpPoolSize;
    private final boolean enabled;
    private final boolean captureRequestData;
    private final boolean captureResponseData;
    private final int maxPayloadBytes;
    private final String nameserverHost;
    private final int nameserverPort;
    private final int scanIntervalSeconds;
    private final boolean scanEnabled;
    private final boolean sslTrustAll;
    private final int bridgePort;
    private final boolean bridgeEnabled;

    private MonitorConfig() {
        Properties props = loadProperties();

        this.apiBaseUrl = resolve(props, "monitor.api.url", "CORBA_MONITOR_API_URL", "http://localhost:8080/api");
        this.apiToken = resolve(props, "monitor.api.token", "CORBA_MONITOR_API_TOKEN", "");
        this.batchSize = Integer.parseInt(resolve(props, "monitor.batch.size", "CORBA_MONITOR_BATCH_SIZE", "50"));
        this.flushIntervalMs = Integer.parseInt(resolve(props, "monitor.flush.interval.ms", "CORBA_MONITOR_FLUSH_MS", "1000"));
        this.httpTimeoutMs = Integer.parseInt(resolve(props, "monitor.http.timeout.ms", "CORBA_MONITOR_HTTP_TIMEOUT", "5000"));
        this.httpPoolSize = Integer.parseInt(resolve(props, "monitor.http.pool.size", "CORBA_MONITOR_HTTP_POOL", "4"));
        this.enabled = Boolean.parseBoolean(resolve(props, "monitor.enabled", "CORBA_MONITOR_ENABLED", "true"));
        this.captureRequestData = Boolean.parseBoolean(resolve(props, "monitor.capture.request", "CORBA_MONITOR_CAPTURE_REQ", "true"));
        this.captureResponseData = Boolean.parseBoolean(resolve(props, "monitor.capture.response", "CORBA_MONITOR_CAPTURE_RES", "true"));
        this.maxPayloadBytes = Integer.parseInt(resolve(props, "monitor.max.payload.bytes", "CORBA_MONITOR_MAX_PAYLOAD", "65536"));
        this.nameserverHost = resolve(props, "monitor.nameserver.host", "CORBA_NAMESERVER_HOST", "localhost");
        this.nameserverPort = Integer.parseInt(resolve(props, "monitor.nameserver.port", "CORBA_NAMESERVER_PORT", "2809"));
        this.scanIntervalSeconds = Integer.parseInt(resolve(props, "monitor.scan.interval.seconds", "CORBA_MONITOR_SCAN_INTERVAL", "30"));
        this.scanEnabled = Boolean.parseBoolean(resolve(props, "monitor.scan.enabled", "CORBA_MONITOR_SCAN_ENABLED", "true"));
        this.sslTrustAll = Boolean.parseBoolean(resolve(props, "monitor.ssl.trust-all", "CORBA_MONITOR_SSL_TRUST_ALL", "false"));
        this.bridgePort = Integer.parseInt(resolve(props, "monitor.bridge.port", "CORBA_MONITOR_BRIDGE_PORT", "9090"));
        this.bridgeEnabled = Boolean.parseBoolean(resolve(props, "monitor.bridge.enabled", "CORBA_MONITOR_BRIDGE_ENABLED", "true"));
    }

    public static synchronized MonitorConfig getInstance() {
        if (instance == null) {
            instance = new MonitorConfig();
        }
        return instance;
    }

    private Properties loadProperties() {
        Properties props = new Properties();
        try (InputStream is = getClass().getClassLoader().getResourceAsStream(PROPS_FILE)) {
            if (is != null) {
                props.load(is);
            }
        } catch (IOException e) {
            // Ignore — use defaults
        }
        return props;
    }

    /**
     * Resolve a config value: System Property > Env Var > Properties > Default
     */
    private String resolve(Properties props, String propKey, String envKey, String defaultValue) {
        String value = System.getProperty(propKey);
        if (value != null && !value.isEmpty()) return value;

        value = System.getenv(envKey);
        if (value != null && !value.isEmpty()) return value;

        value = props.getProperty(propKey);
        if (value != null && !value.isEmpty()) return value;

        return defaultValue;
    }

    // Getters

    public String getApiBaseUrl() { return apiBaseUrl; }
    public String getApiToken() { return apiToken; }
    public int getBatchSize() { return batchSize; }
    public int getFlushIntervalMs() { return flushIntervalMs; }
    public int getHttpTimeoutMs() { return httpTimeoutMs; }
    public int getHttpPoolSize() { return httpPoolSize; }
    public boolean isEnabled() { return enabled; }
    public boolean isCaptureRequestData() { return captureRequestData; }
    public boolean isCaptureResponseData() { return captureResponseData; }
    public int getMaxPayloadBytes() { return maxPayloadBytes; }
    public String getNameserverHost() { return nameserverHost; }
    public int getNameserverPort() { return nameserverPort; }
    public int getScanIntervalSeconds() { return scanIntervalSeconds; }
    public boolean isScanEnabled() { return scanEnabled; }
    public boolean isSslTrustAll() { return sslTrustAll; }
    public int getBridgePort() { return bridgePort; }
    public boolean isBridgeEnabled() { return bridgeEnabled; }

    public String getTrafficEndpoint() { return apiBaseUrl + "/traffic"; }
    public String getBatchEndpoint() { return apiBaseUrl + "/traffic/batch"; }
    public String getNameserverReportEndpoint() { return apiBaseUrl + "/nameserver/report"; }
    public String getHealthEndpoint() { return apiBaseUrl + "/health"; }

    @Override
    public String toString() {
        return String.format(
            "MonitorConfig{api=%s, batch=%d, flush=%dms, capture_req=%b, capture_res=%b, ns=%s:%d, scan=%b/%ds, ssl_trust_all=%b, bridge=%b/%d}",
            apiBaseUrl, batchSize, flushIntervalMs, captureRequestData, captureResponseData,
            nameserverHost, nameserverPort, scanEnabled, scanIntervalSeconds, sslTrustAll, bridgeEnabled, bridgePort
        );
    }
}
