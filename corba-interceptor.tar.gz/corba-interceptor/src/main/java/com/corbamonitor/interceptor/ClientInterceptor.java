package com.corbamonitor.interceptor;

import com.corbamonitor.api.MonitorApiClient;
import com.corbamonitor.api.TrafficEvent;
import com.corbamonitor.config.MonitorConfig;
import org.omg.CORBA.Any;
import org.omg.CORBA.BAD_PARAM;
import org.omg.CORBA.TCKind;
import org.omg.IOP.ServiceContext;
import org.omg.PortableInterceptor.ClientRequestInfo;
import org.omg.PortableInterceptor.ClientRequestInterceptor;
import org.omg.PortableInterceptor.ForwardRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.util.*;

/**
 * Client-side Portable Interceptor.
 *
 * Intercepts all outgoing CORBA requests and their replies/exceptions
 * on the consumer side. Captures:
 * - Operation name, interface, repository ID
 * - Target IOR host/port
 * - Request/reply timing (latency)
 * - Arguments and return values (when configured)
 * - CORBA system/user exceptions
 */
public class ClientInterceptor extends org.omg.CORBA.LocalObject
        implements ClientRequestInterceptor {

    private static final Logger log = LoggerFactory.getLogger(ClientInterceptor.class);
    private static final int TIMESTAMP_SLOT_ID = 0;

    private final MonitorConfig config;
    private final MonitorApiClient apiClient;
    private final String localHost;
    private final int slotId;

    public ClientInterceptor(int slotId) {
        this.config = MonitorConfig.getInstance();
        this.apiClient = MonitorApiClient.getInstance();
        this.slotId = slotId;

        String host;
        try {
            host = InetAddress.getLocalHost().getHostAddress();
        } catch (Exception e) {
            host = "unknown";
        }
        this.localHost = host;

        log.info("ClientInterceptor initialized (slot={})", slotId);
    }

    @Override
    public String name() {
        return "CORBAMonitorClientInterceptor";
    }

    /**
     * Called before a request is sent to the server.
     * We record the start time and capture request parameters.
     */
    @Override
    public void send_request(ClientRequestInfo ri) throws ForwardRequest {
        try {
            // Store start time for latency calculation
            long startNanos = System.nanoTime();
            RequestTimingStore.setStartTime(ri.request_id(), startNanos);

            // Build and send event
            TrafficEvent event = buildBaseEvent(ri, "send_request")
                    .direction("request")
                    .status("success")
                    .messageType("Request");

            // Capture request arguments
            if (config.isCaptureRequestData()) {
                event.requestData(extractArguments(ri));
            }

            apiClient.submit(event);

        } catch (Exception e) {
            // Never let monitoring break the actual CORBA call
            log.debug("Error in send_request interceptor: {}", e.getMessage());
        }
    }

    /**
     * Called when a reply is received from the server.
     */
    @Override
    public void receive_reply(ClientRequestInfo ri) {
        try {
            Double latency = calculateLatency(ri.request_id());

            TrafficEvent event = buildBaseEvent(ri, "receive_reply")
                    .direction("reply")
                    .status("success")
                    .latencyMs(latency)
                    .messageType("Reply");

            // Capture response
            if (config.isCaptureResponseData()) {
                event.responseData(extractResult(ri));
            }

            apiClient.submit(event);

        } catch (Exception e) {
            log.debug("Error in receive_reply interceptor: {}", e.getMessage());
        }
    }

    /**
     * Called when a system exception is received.
     */
    @Override
    public void receive_exception(ClientRequestInfo ri) throws ForwardRequest {
        try {
            Double latency = calculateLatency(ri.request_id());

            String exceptionId = "UNKNOWN";
            try {
                exceptionId = ri.received_exception_id();
            } catch (Exception ignored) {}

            // Parse exception type from repository ID
            // e.g., "IDL:omg.org/CORBA/TRANSIENT:1.0" → "CORBA::TRANSIENT"
            String exceptionType = parseExceptionType(exceptionId);
            String errorMessage = "CORBA::" + exceptionType;

            TrafficEvent event = buildBaseEvent(ri, "receive_exception")
                    .direction("reply")
                    .status(exceptionType.contains("TRANSIENT") || exceptionType.contains("TIMEOUT")
                            ? "timeout" : "exception")
                    .latencyMs(latency)
                    .errorMessage(errorMessage)
                    .exceptionType(exceptionId.contains("USER_EXCEPTION")
                            ? "USER_EXCEPTION" : "SYSTEM_EXCEPTION")
                    .messageType("Reply");

            apiClient.submit(event);

        } catch (Exception e) {
            log.debug("Error in receive_exception interceptor: {}", e.getMessage());
        }
    }

    /**
     * Called when the request results in a location forward (redirect).
     */
    @Override
    public void receive_other(ClientRequestInfo ri) throws ForwardRequest {
        try {
            TrafficEvent event = buildBaseEvent(ri, "receive_other")
                    .direction("reply")
                    .status("success")
                    .messageType("LocateReply");

            apiClient.submit(event);
        } catch (Exception e) {
            log.debug("Error in receive_other interceptor: {}", e.getMessage());
        }
    }

    @Override
    public void send_poll(ClientRequestInfo ri) {
        // Not commonly used
    }

    @Override
    public void destroy() {
        log.info("ClientInterceptor destroyed");
    }

    // ─── Helper Methods ───────────────────────────────────────────────

    /**
     * Build a base TrafficEvent with common fields from the RequestInfo.
     */
    private TrafficEvent buildBaseEvent(ClientRequestInfo ri, String interceptorPoint) {
        TrafficEvent event = new TrafficEvent()
                .requestId(formatRequestId(ri.request_id()))
                .operation(ri.operation())
                .interceptorPoint(interceptorPoint)
                .sourceHost(localHost)
                .giopVersion("1.2");

        // Extract interface/repository info
        try {
            org.omg.CORBA.Object target = ri.target();
            if (target != null) {
                try {
                    String[] ids = ((org.omg.CORBA.portable.ObjectImpl) target)
                            ._ids();
                    if (ids != null && ids.length > 0) {
                        event.repositoryId(ids[0]);
                        event.interfaceName(parseInterfaceName(ids[0]));
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}

        // Extract target host/port from effective_target IOR
        try {
            org.omg.CORBA.Object effectiveTarget = ri.effective_target();
            if (effectiveTarget != null) {
                String ior = effectiveTarget.toString();
                parseIORAddress(ior, event);
            }
        } catch (Exception ignored) {}

        // Service contexts
        try {
            Map<String, Object> ctxData = extractServiceContexts(ri);
            if (!ctxData.isEmpty()) {
                event.contextData(ctxData);
            }
        } catch (Exception ignored) {}

        return event;
    }

    /**
     * Extract arguments from the request (if available).
     */
    private Map<String, Object> extractArguments(ClientRequestInfo ri) {
        Map<String, Object> args = new LinkedHashMap<>();
        try {
            org.omg.Dynamic.Parameter[] params = ri.arguments();
            if (params != null) {
                args.put("_idl_type", ri.operation());
                Map<String, Object> paramMap = new LinkedHashMap<>();
                for (int i = 0; i < params.length; i++) {
                    String key = "arg" + i;
                    try {
                        paramMap.put(key, anyToObject(params[i].argument));
                    } catch (Exception e) {
                        paramMap.put(key, "<unavailable>");
                    }
                }
                args.put("params", paramMap);
            }
        } catch (BAD_PARAM bp) {
            // Arguments not available at this interception point
            args.put("_note", "Arguments not available (BAD_PARAM)");
        } catch (Exception e) {
            args.put("_note", "Could not extract arguments: " + e.getMessage());
        }
        return args;
    }

    /**
     * Extract the return value from the reply.
     */
    private Map<String, Object> extractResult(ClientRequestInfo ri) {
        Map<String, Object> result = new LinkedHashMap<>();
        try {
            Any returnValue = ri.result();
            if (returnValue != null && returnValue.type().kind() != TCKind.tk_void
                    && returnValue.type().kind() != TCKind.tk_null) {
                result.put("_idl_type", ri.operation() + "::_return");
                result.put("return_value", anyToObject(returnValue));
            }
        } catch (BAD_PARAM bp) {
            // Result not available
        } catch (Exception e) {
            result.put("_note", "Could not extract result: " + e.getMessage());
        }
        return result;
    }

    /**
     * Convert a CORBA Any to a Java Object for JSON serialization.
     */
    private Object anyToObject(Any any) {
        if (any == null) return null;

        try {
            TCKind kind = any.type().kind();
            switch (kind.value()) {
                case TCKind._tk_boolean: return any.extract_boolean();
                case TCKind._tk_char: return String.valueOf(any.extract_char());
                case TCKind._tk_wchar: return String.valueOf(any.extract_wchar());
                case TCKind._tk_octet: return (int) any.extract_octet();
                case TCKind._tk_short: return any.extract_short();
                case TCKind._tk_ushort: return any.extract_ushort();
                case TCKind._tk_long: return any.extract_long();
                case TCKind._tk_ulong: return any.extract_ulong();
                case TCKind._tk_longlong: return any.extract_longlong();
                case TCKind._tk_ulonglong: return any.extract_ulonglong();
                case TCKind._tk_float: return any.extract_float();
                case TCKind._tk_double: return any.extract_double();
                case TCKind._tk_string: return any.extract_string();
                case TCKind._tk_wstring: return any.extract_wstring();
                case TCKind._tk_enum: return any.type().member_name(any.create_input_stream().read_long());
                case TCKind._tk_void:
                case TCKind._tk_null:
                    return null;
                default:
                    // For complex types, return type info
                    Map<String, Object> complex = new LinkedHashMap<>();
                    complex.put("_type", any.type().name());
                    complex.put("_kind", kind.value());
                    complex.put("_id", any.type().id());
                    return complex;
            }
        } catch (Exception e) {
            return "<" + e.getClass().getSimpleName() + ">";
        }
    }

    /**
     * Extract service contexts from the request.
     */
    private Map<String, Object> extractServiceContexts(ClientRequestInfo ri) {
        Map<String, Object> contexts = new LinkedHashMap<>();
        // Try common service context IDs
        int[] contextIds = {0, 1, 6, 15, 0x4F545300}; // CodeSets, BI_DIR_IIOP, SendingContextRunTime, TAO
        for (int id : contextIds) {
            try {
                ServiceContext sc = ri.get_request_service_context(id);
                if (sc != null && sc.context_data != null) {
                    contexts.put("ctx_" + id, Map.of(
                            "context_id", id,
                            "data_length", sc.context_data.length
                    ));
                }
            } catch (BAD_PARAM ignored) {
                // Context not present
            }
        }
        return contexts;
    }

    /**
     * Parse interface name from repository ID.
     * "IDL:FleetManagement/VehicleTracker:1.0" → "VehicleTracker"
     */
    private String parseInterfaceName(String repositoryId) {
        if (repositoryId == null) return null;
        try {
            String body = repositoryId;
            if (body.startsWith("IDL:")) body = body.substring(4);
            int colonIdx = body.lastIndexOf(':');
            if (colonIdx > 0) body = body.substring(0, colonIdx);
            int slashIdx = body.lastIndexOf('/');
            return slashIdx >= 0 ? body.substring(slashIdx + 1) : body;
        } catch (Exception e) {
            return repositoryId;
        }
    }

    /**
     * Parse exception type from exception ID.
     */
    private String parseExceptionType(String exceptionId) {
        if (exceptionId == null) return "UNKNOWN";
        // "IDL:omg.org/CORBA/TRANSIENT:1.0" → "TRANSIENT"
        try {
            String body = exceptionId;
            int lastColon = body.lastIndexOf(':');
            if (lastColon > 0) body = body.substring(0, lastColon);
            int lastSlash = body.lastIndexOf('/');
            return lastSlash >= 0 ? body.substring(lastSlash + 1) : body;
        } catch (Exception e) {
            return exceptionId;
        }
    }

    /**
     * Parse host and port from an IOR string.
     * This is a best-effort attempt for common IOR formats.
     */
    private void parseIORAddress(String ior, TrafficEvent event) {
        if (ior == null) return;
        // JacORB's toString() may give "IOR:..." or the corbaloc form
        // We try to extract from the object reference implementation
        try {
            if (ior.contains("://")) {
                // corbaloc format: corbaloc::host:port/...
                String[] parts = ior.split("://");
                if (parts.length > 1) {
                    String hostPort = parts[1].split("/")[0];
                    String[] hp = hostPort.split(":");
                    if (hp.length >= 1) event.targetHost(hp[0]);
                    if (hp.length >= 2) event.targetPort(Integer.parseInt(hp[1]));
                }
            }
        } catch (Exception ignored) {}
    }

    /**
     * Format request ID bytes as a short hex string.
     */
    private String formatRequestId(byte[] requestId) {
        if (requestId == null || requestId.length == 0) return UUID.randomUUID().toString();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(requestId.length, 16); i++) {
            sb.append(String.format("%02x", requestId[i] & 0xFF));
        }
        return sb.toString();
    }

    /**
     * Calculate latency from stored start time.
     */
    private Double calculateLatency(byte[] requestId) {
        String id = formatRequestId(requestId);
        Long startNanos = RequestTimingStore.getAndRemoveStartTime(id);
        if (startNanos != null) {
            return (System.nanoTime() - startNanos) / 1_000_000.0;
        }
        return null;
    }
}
