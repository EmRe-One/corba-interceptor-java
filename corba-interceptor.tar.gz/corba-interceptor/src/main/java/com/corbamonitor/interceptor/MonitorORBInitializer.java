package com.corbamonitor.interceptor;

import org.omg.IOP.CodecFactoryHelper;
import org.omg.PortableInterceptor.ORBInitInfo;
import org.omg.PortableInterceptor.ORBInitializer;
import org.omg.PortableInterceptor.ORBInitInfoPackage.DuplicateName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ORB Initializer that registers the Client and Server interceptors.
 *
 * This is registered via:
 *   -Dorg.omg.PortableInterceptor.ORBInitializerClass.com.corbamonitor.interceptor.MonitorORBInitializer
 *
 * Or in orb.properties:
 *   org.omg.PortableInterceptor.ORBInitializerClass.com.corbamonitor.interceptor.MonitorORBInitializer=
 */
public class MonitorORBInitializer extends org.omg.CORBA.LocalObject
        implements ORBInitializer {

    private static final Logger log = LoggerFactory.getLogger(MonitorORBInitializer.class);

    @Override
    public void pre_init(ORBInitInfo info) {
        log.info("╔══════════════════════════════════════════════════╗");
        log.info("║       CORBA Monitor Interceptor Agent           ║");
        log.info("╚══════════════════════════════════════════════════╝");

        try {
            // Allocate a slot for timing data
            int slotId = info.allocate_slot_id();

            // Register client-side interceptor
            ClientInterceptor clientInterceptor = new ClientInterceptor(slotId);
            info.add_client_request_interceptor(clientInterceptor);
            log.info("✓ ClientRequestInterceptor registered");

            // Register server-side interceptor
            ServerInterceptor serverInterceptor = new ServerInterceptor();
            info.add_server_request_interceptor(serverInterceptor);
            log.info("✓ ServerRequestInterceptor registered");

        } catch (DuplicateName e) {
            log.error("Duplicate interceptor name: {}", e.name);
        } catch (Exception e) {
            log.error("Failed to register interceptors: {}", e.getMessage(), e);
        }
    }

    @Override
    public void post_init(ORBInitInfo info) {
        log.info("CORBA Monitor interceptors active — forwarding traffic to API");
    }
}
