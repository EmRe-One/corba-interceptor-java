package com.corbamonitor.interceptor;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Thread-safe store for request start times.
 * Used to calculate round-trip latency between send_request and receive_reply.
 *
 * Entries are automatically removed after retrieval to prevent memory leaks.
 * A background cleanup is not needed since entries are short-lived.
 */
public class RequestTimingStore {

    private static final ConcurrentHashMap<String, Long> timings = new ConcurrentHashMap<>();

    public static void setStartTime(byte[] requestId, long nanoTime) {
        String key = formatKey(requestId);
        timings.put(key, nanoTime);
    }

    public static Long getAndRemoveStartTime(String key) {
        return timings.remove(key);
    }

    public static Long getAndRemoveStartTime(byte[] requestId) {
        return timings.remove(formatKey(requestId));
    }

    private static String formatKey(byte[] requestId) {
        if (requestId == null || requestId.length == 0) return "unknown";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(requestId.length, 16); i++) {
            sb.append(String.format("%02x", requestId[i] & 0xFF));
        }
        return sb.toString();
    }

    public static int size() {
        return timings.size();
    }

    public static void clear() {
        timings.clear();
    }
}
