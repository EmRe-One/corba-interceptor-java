package com.corbamonitor.interceptor;

import com.corbamonitor.api.MonitorApiClient;
import com.corbamonitor.api.TrafficEvent;
import com.corbamonitor.config.MonitorConfig;
import org.omg.CORBA.BAD_PARAM;
import org.omg.PortableInterceptor.ForwardRequest;
import org.omg.PortableInterceptor.ServerRequestInfo;
import org.omg.PortableInterceptor.ServerRequestInterceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.util.*;

/**
 * Server-side Portable Interceptor.
 *
 * Intercepts all incoming CORBA requests on the supplier side.
 * Captures the server's view of the interaction.
 */
public class ServerInterceptor extends org.omg.CORBA.LocalObject
        implements ServerRequestInterceptor {

    private static final Logger log = LoggerFactory.getLogger(ServerInterceptor.class);

    private final MonitorConfig config;
    private final MonitorApiClient apiClient;
    private final String localHost;

    public ServerInterceptor() {
        this.config = MonitorConfig.getInstance();
        this.apiClient = MonitorApiClient.getInstance();

        String host;
        try {
            host = InetAddress.getLocalHost().getHostAddress();
        } catch (Exception e) {
            host = "unknown";
        }
        this.localHost = host;

        log.info("ServerInterceptor initialized");
    }

    @Override
    public String name() {
        return "CORBAMonitorServerInterceptor";
    }

    /**
     * Called when a request arrives at the server, before dispatch.
     */
    @Override
    public void receive_request_service_contexts(ServerRequestInfo ri) {
        try {
            RequestTimingStore.setStartTime(ri.request_id(), System.nanoTime());
        } catch (Exception e) {
            log.debug("Error storing start time: {}", e.getMessage());
        }
    }

    /**
     * Called after service contexts are processed, with full request info.
     */
    @Override
    public void receive_request(ServerRequestInfo ri) throws ForwardRequest {
        try {
            TrafficEvent event = buildBaseEvent(ri, "receive_request")
                    .direction("request")
                    .status("success")
                    .targetHost(localHost)
                    .messageType("Request");

            // Capture arguments
            if (config.isCaptureRequestData()) {
                event.requestData(extractArguments(ri));
            }

            apiClient.submit(event);

        } catch (Exception e) {
            log.debug("Error in receive_request interceptor: {}", e.getMessage());
        }
    }

    /**
     * Called after the servant has processed the request, before sending reply.
     */
    @Override
    public void send_reply(ServerRequestInfo ri) {
        try {
            Double latency = calculateLatency(ri.request_id());

            TrafficEvent event = buildBaseEvent(ri, "send_reply")
                    .direction("reply")
                    .status("success")
                    .latencyMs(latency)
                    .targetHost(localHost)
                    .messageType("Reply");

            if (config.isCaptureResponseData()) {
                event.responseData(extractResult(ri));
            }

            apiClient.submit(event);

        } catch (Exception e) {
            log.debug("Error in send_reply interceptor: {}", e.getMessage());
        }
    }

    /**
     * Called when the servant throws an exception.
     */
    @Override
    public void send_exception(ServerRequestInfo ri) throws ForwardRequest {
        try {
            Double latency = calculateLatency(ri.request_id());

            String exceptionId = "UNKNOWN";
            try {
                exceptionId = ri.sending_exception().type().id();
            } catch (Exception ignored) {}

            TrafficEvent event = buildBaseEvent(ri, "send_exception")
                    .direction("reply")
                    .status("exception")
                    .latencyMs(latency)
                    .errorMessage(exceptionId)
                    .exceptionType("SYSTEM_EXCEPTION")
                    .targetHost(localHost)
                    .messageType("Reply");

            apiClient.submit(event);

        } catch (Exception e) {
            log.debug("Error in send_exception interceptor: {}", e.getMessage());
        }
    }

    @Override
    public void send_other(ServerRequestInfo ri) throws ForwardRequest {
        // Location forward or similar
    }

    @Override
    public void destroy() {
        log.info("ServerInterceptor destroyed");
    }

    // ─── Helpers ──────────────────────────────────────────────────────

    private TrafficEvent buildBaseEvent(ServerRequestInfo ri, String interceptorPoint) {
        TrafficEvent event = new TrafficEvent()
                .requestId(formatRequestId(ri.request_id()))
                .operation(ri.operation())
                .interceptorPoint(interceptorPoint)
                .giopVersion("1.2");

        // Try to get adapter/object info
        try {
            byte[] adapterId = ri.adapter_id();
            byte[] objectId = ri.object_id();
            if (objectId != null && objectId.length > 0) {
                event.targetServiceName(new String(objectId).trim());
            }
        } catch (Exception ignored) {}

        // Repository ID from target's most-derived interface
        try {
            String[] ids = ri.target_most_derived_interface().split("/");
            if (ids.length > 0) {
                event.repositoryId(ri.target_most_derived_interface());
                String name = ids[ids.length - 1];
                int colon = name.indexOf(':');
                event.interfaceName(colon > 0 ? name.substring(0, colon) : name);
            }
        } catch (Exception ignored) {}

        return event;
    }

    private Map<String, Object> extractArguments(ServerRequestInfo ri) {
        Map<String, Object> args = new LinkedHashMap<>();
        try {
            org.omg.Dynamic.Parameter[] params = ri.arguments();
            if (params != null) {
                args.put("_idl_type", ri.operation());
                Map<String, Object> paramMap = new LinkedHashMap<>();
                for (int i = 0; i < params.length; i++) {
                    paramMap.put("arg" + i, "<captured>");
                }
                args.put("params", paramMap);
            }
        } catch (BAD_PARAM ignored) {
        } catch (Exception e) {
            args.put("_note", e.getMessage());
        }
        return args;
    }

    private Map<String, Object> extractResult(ServerRequestInfo ri) {
        Map<String, Object> result = new LinkedHashMap<>();
        try {
            result.put("_note", "Server-side result captured");
        } catch (Exception ignored) {}
        return result;
    }

    private String formatRequestId(byte[] requestId) {
        if (requestId == null || requestId.length == 0) return UUID.randomUUID().toString();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(requestId.length, 16); i++) {
            sb.append(String.format("%02x", requestId[i] & 0xFF));
        }
        return sb.toString();
    }

    private Double calculateLatency(byte[] requestId) {
        String id = formatRequestId(requestId);
        Long startNanos = RequestTimingStore.getAndRemoveStartTime(id);
        if (startNanos != null) {
            return (System.nanoTime() - startNanos) / 1_000_000.0;
        }
        return null;
    }
}
