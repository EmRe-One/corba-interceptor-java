package com.corbamonitor.nameserver;

import com.corbamonitor.api.MonitorApiClient;
import com.corbamonitor.config.MonitorConfig;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import javax.net.ssl.*;
import java.security.cert.X509Certificate;

/**
 * Scans the CORBA Naming Service tree and reports discovered services
 * to the Monitor API. This serves as the "bridge" that the Laravel
 * CorbaNameserverService expects on port 9090.
 *
 * It also provides a minimal REST API for the Laravel app to query:
 *   GET  /list?path=...         → list entries at path
 *   GET  /resolve?path=...      → resolve a name to IOR
 *   GET  /health                → health check
 */
public class NameserverScanner {

    private static final Logger log = LoggerFactory.getLogger(NameserverScanner.class);

    private final ORB orb;
    private final MonitorConfig config;
    private final Gson gson;
    private NamingContextExt rootContext;
    private ScheduledExecutorService scheduler;

    public NameserverScanner(ORB orb) {
        this.orb = orb;
        this.config = MonitorConfig.getInstance();
        this.gson = new GsonBuilder().disableHtmlEscaping().create();
    }

    /**
     * Connect to the naming service and start periodic scanning.
     */
    public void start() {
        if (!config.isScanEnabled()) {
            log.info("Nameserver scanning disabled");
            return;
        }

        try {
            connectToNameserver();

            scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "corba-monitor-ns-scan");
                t.setDaemon(true);
                return t;
            });

            scheduler.scheduleAtFixedRate(
                    this::scan,
                    0,
                    config.getScanIntervalSeconds(),
                    TimeUnit.SECONDS
            );

            log.info("Nameserver scanner started (interval={}s, host={}:{})",
                    config.getScanIntervalSeconds(),
                    config.getNameserverHost(),
                    config.getNameserverPort());

        } catch (Exception e) {
            log.error("Failed to start nameserver scanner: {}", e.getMessage());
        }
    }

    /**
     * Connect to the CORBA Naming Service.
     */
    private void connectToNameserver() throws Exception {
        try {
            // Try resolve_initial_references first (standard)
            org.omg.CORBA.Object nsObj = orb.resolve_initial_references("NameService");
            rootContext = NamingContextExtHelper.narrow(nsObj);
            log.info("Connected to NameService via resolve_initial_references");
        } catch (Exception e) {
            // Fallback: try corbaloc
            String corbaloc = String.format("corbaloc:iiop:%s:%d/NameService",
                    config.getNameserverHost(), config.getNameserverPort());
            log.info("Trying corbaloc: {}", corbaloc);
            org.omg.CORBA.Object nsObj = orb.string_to_object(corbaloc);
            rootContext = NamingContextExtHelper.narrow(nsObj);
            log.info("Connected to NameService via corbaloc");
        }
    }

    /**
     * Scan the entire naming tree and report findings to the API.
     */
    public void scan() {
        if (rootContext == null) {
            try {
                connectToNameserver();
            } catch (Exception e) {
                log.warn("Cannot connect to nameserver: {}", e.getMessage());
                return;
            }
        }

        try {
            List<Map<String, Object>> entries = new ArrayList<>();
            walkTree(rootContext, "", entries);

            log.info("Nameserver scan found {} entries", entries.size());

            // Send to API
            reportEntries(entries);

        } catch (Exception e) {
            log.error("Nameserver scan failed: {}", e.getMessage());
            rootContext = null; // Force reconnect on next scan
        }
    }

    /**
     * Recursively walk the naming tree.
     */
    private void walkTree(NamingContext context, String parentPath, List<Map<String, Object>> entries) {
        try {
            BindingListHolder blh = new BindingListHolder();
            BindingIteratorHolder bih = new BindingIteratorHolder();

            context.list(1000, blh, bih);

            for (Binding binding : blh.value) {
                NameComponent nc = binding.binding_name[0];
                String name = nc.id;
                if (nc.kind != null && !nc.kind.isEmpty()) {
                    name += "." + nc.kind;
                }
                String fullPath = parentPath.isEmpty() ? name : parentPath + "/" + name;

                if (binding.binding_type == BindingType.ncontext) {
                    // It's a naming context (directory) — recurse
                    Map<String, Object> entry = new LinkedHashMap<>();
                    entry.put("path", fullPath);
                    entry.put("name", nc.id);
                    entry.put("kind", nc.kind);
                    entry.put("type", "context");
                    entries.add(entry);

                    try {
                        NameComponent[] subName = {nc};
                        org.omg.CORBA.Object subObj = context.resolve(subName);
                        NamingContext subCtx = NamingContextHelper.narrow(subObj);
                        walkTree(subCtx, fullPath, entries);
                    } catch (Exception e) {
                        log.debug("Cannot descend into {}: {}", fullPath, e.getMessage());
                    }

                } else {
                    // It's an object binding
                    Map<String, Object> entry = new LinkedHashMap<>();
                    entry.put("path", fullPath);
                    entry.put("name", nc.id);
                    entry.put("kind", nc.kind);
                    entry.put("type", "object");

                    // Resolve to get IOR
                    try {
                        NameComponent[] objName = {nc};
                        org.omg.CORBA.Object obj = context.resolve(objName);
                        if (obj != null) {
                            String ior = orb.object_to_string(obj);
                            entry.put("ior", ior);

                            // Try to ping
                            boolean alive = false;
                            try {
                                alive = !obj._non_existent();
                            } catch (Exception ignored) {}
                            entry.put("is_alive", alive);

                            // Parse IOR for host/port
                            parseIOR(ior, entry);
                        }
                    } catch (Exception e) {
                        entry.put("error", e.getMessage());
                        entry.put("is_alive", false);
                    }

                    entries.add(entry);
                }
            }

            // Handle binding iterator if present
            if (bih.value != null) {
                try {
                    BindingHolder bh = new BindingHolder();
                    while (bih.value.next_one(bh)) {
                        // Process remaining bindings (unlikely for most nameservers)
                        NameComponent nc = bh.value.binding_name[0];
                        String name = nc.id;
                        String fullPath = parentPath.isEmpty() ? name : parentPath + "/" + name;

                        Map<String, Object> entry = new LinkedHashMap<>();
                        entry.put("path", fullPath);
                        entry.put("name", nc.id);
                        entry.put("kind", nc.kind);
                        entry.put("type", bh.value.binding_type == BindingType.ncontext ? "context" : "object");
                        entries.add(entry);
                    }
                    bih.value.destroy();
                } catch (Exception ignored) {}
            }

        } catch (Exception e) {
            log.error("Error walking tree at '{}': {}", parentPath, e.getMessage());
        }
    }

    /**
     * Best-effort IOR parsing to extract host and port.
     */
    private void parseIOR(String ior, Map<String, Object> entry) {
        if (ior == null || !ior.startsWith("IOR:")) return;
        try {
            // JacORB can parse IOR internally
            org.omg.CORBA.Object obj = orb.string_to_object(ior);
            if (obj instanceof org.omg.CORBA.portable.ObjectImpl) {
                org.omg.CORBA.portable.Delegate delegate =
                        ((org.omg.CORBA.portable.ObjectImpl) obj)._get_delegate();
                // The delegate often has host/port info but the exact API varies
                // We'll extract from the IOR hex string as fallback
            }
        } catch (Exception ignored) {}

        // Hex-based extraction (fallback)
        try {
            String hex = ior.substring(4);
            // IOR structure: byte_order + type_id_length + type_id + profiles...
            // This is simplified — full IOR parsing would need CDR decoding
            entry.put("ior_length", hex.length() / 2);
        } catch (Exception ignored) {}
    }

    /**
     * Send discovered entries to the Monitor API.
     */
    private void reportEntries(List<Map<String, Object>> entries) {
        try {
            Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("source", "java-agent");
            payload.put("entries", entries);
            payload.put("timestamp", java.time.Instant.now().toString());

            String json = gson.toJson(payload);
            String endpoint = config.getApiBaseUrl() + "/nameserver/report";

            URL url = new URL(endpoint);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // Trust all certs in dev mode
            if (conn instanceof HttpsURLConnection && config.isSslTrustAll()) {
                applySslTrustAll((HttpsURLConnection) conn);
            }

            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setRequestProperty("Content-Type", "application/json");

            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            conn.setFixedLengthStreamingMode(bytes.length);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(bytes);
            }

            int status = conn.getResponseCode();
            conn.disconnect();

            if (status >= 200 && status < 300) {
                log.info("Reported {} nameserver entries to API", entries.size());
            } else {
                log.warn("Nameserver report failed with HTTP {}", status);
            }
        } catch (IOException e) {
            log.error("Failed to report nameserver entries: {}", e.getMessage());
        }
    }

    public void stop() {
        if (scheduler != null) {
            scheduler.shutdown();
        }
    }

    /**
     * Disable SSL verification on a specific HTTPS connection (dev only).
     */
    private void applySslTrustAll(HttpsURLConnection conn) {
        try {
            TrustManager[] trustAll = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                    public void checkClientTrusted(X509Certificate[] c, String a) {}
                    public void checkServerTrusted(X509Certificate[] c, String a) {}
                }
            };
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAll, new java.security.SecureRandom());
            conn.setSSLSocketFactory(sc.getSocketFactory());
            conn.setHostnameVerifier((h, s) -> true);
        } catch (Exception e) {
            log.warn("Failed to apply SSL trust-all: {}", e.getMessage());
        }
    }
}
