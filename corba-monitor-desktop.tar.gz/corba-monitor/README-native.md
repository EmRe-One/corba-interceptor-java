# CORBA Monitor — Desktop Edition

Native desktop application for real-time CORBA traffic monitoring, built with Laravel, Livewire, Flux UI Pro, and NativePHP.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    NativePHP (Electron)                   │
│                                                           │
│  ┌─────────────────────────────────────────────────────┐ │
│  │              Laravel Application                     │ │
│  │                                                       │ │
│  │  Dashboard │ Traffic Search │ Topology │ Inspector   │ │
│  │  (Livewire + Flux UI Pro + D3.js)                    │ │
│  └──────────────────────┬──────────────────────────────┘ │
│                          │                                 │
│  ┌──────────┐  ┌────────┴───────┐  ┌──────────────────┐ │
│  │Meilisearch│  │ Laravel Reverb │  │  CORBA Agent     │ │
│  │ (Binary)  │  │  (WebSocket)   │  │  (Java JAR)      │ │
│  │  :7700    │  │    :8080       │  │  → Nameserver    │ │
│  └──────────┘  └────────────────┘  └──────────────────┘ │
│       ↑              ↑                     ↑              │
│       └──────────────┴─────────────────────┘              │
│              ChildProcess (auto-managed)                   │
└─────────────────────────────────────────────────────────┘
         │                              │
         ▼                              ▼
   ┌──────────┐                  ┌────────────┐
   │  SQLite   │                  │   CORBA     │
   │ (local)   │                  │ Nameserver  │
   └──────────┘                  └────────────┘
```

## What's Different from Server Edition

| Feature | Server (Docker) | Desktop (NativePHP) |
|---|---|---|
| Database | MySQL container | SQLite (embedded) |
| Cache | Redis container | File cache |
| Search | Meilisearch container | Meilisearch binary (bundled) |
| WebSocket | Reverb in container | Reverb as ChildProcess |
| CORBA Agent | Separate Java app | Bundled JAR (optional) |
| Installation | `docker compose up` | `php artisan native:serve` |
| Distribution | — | `.dmg` / `.exe` / `.AppImage` |

## Quick Start

### Prerequisites

- PHP 8.2+ and Node.js 18+ (easiest via [Laravel Herd](https://herd.laravel.com))
- Composer
- Java 11+ (optional, for CORBA Agent)

### Setup

```bash
git clone https://github.com/your-org/corba-monitor.git
cd corba-monitor

# Automated setup (downloads Meilisearch, configures env, builds assets)
chmod +x setup-native.sh
./setup-native.sh

# Start the desktop app
php artisan native:serve
```

### Manual Setup

```bash
composer install
npm install

cp .env.native .env
php artisan key:generate

touch database/database.sqlite
php artisan migrate

npm run build

php artisan native:serve
```

## Project Structure

```
corba-monitor/
├── app/
│   ├── Providers/
│   │   ├── NativeAppServiceProvider.php  ← NativePHP boot (window, menu, services)
│   │   ├── AppServiceProvider.php         ← Auto-migration for SQLite
│   │   └── EventServiceProvider.php       ← ChildProcess event handling
│   ├── Listeners/
│   │   └── ChildProcessEventListener.php  ← Auto-restart on crash
│   ├── Livewire/
│   │   ├── Dashboard/Overview.php
│   │   ├── Traffic/Search.php
│   │   ├── Traffic/Inspector.php
│   │   ├── Services/Topology.php
│   │   └── Settings/ServiceManager.php    ← Service health UI
│   ├── Services/
│   │   ├── MeilisearchService.php
│   │   ├── TrafficIngestionService.php
│   │   └── CorbaNameserverService.php
│   └── Http/Controllers/
│       └── TrafficApiController.php       ← REST API for Java agent
├── config/
│   ├── nativephp.php                      ← NativePHP config
│   └── services.php                       ← Meilisearch & CORBA config
├── extras/                                ← Bundled with the app
│   ├── meilisearch/                       ← Platform binaries
│   └── java/                              ← CORBA agent JAR
├── .env.native                            ← Desktop environment config
└── setup-native.sh                        ← One-click setup script
```

## NativePHP Integration Details

### NativeAppServiceProvider

Called when the Electron window opens. Handles:

1. **Window**: 1440×900, remembers position, hidden titlebar
2. **Menu**: Native menu bar with keyboard shortcuts
3. **Meilisearch**: Started as ChildProcess with platform-detected binary
4. **Reverb**: WebSocket server as ChildProcess
5. **CORBA Agent**: Java JAR as ChildProcess (if available)

### Service Manager UI

Accessible via `Cmd+,` or the Settings menu. Shows:
- Health status of all background services (green/red/yellow)
- Start/Stop/Restart controls
- System info (PHP version, OS, Java availability)
- Quick actions: Run migrations, Generate demo data

### ChildProcess Lifecycle

- Services are started as **persistent** child processes
- On crash: auto-restart with progressive backoff (max 3 attempts)
- All stdout/stderr is captured and logged
- Services shut down when the app window closes

### Data Storage

| Data | Location | Persists? |
|---|---|---|
| SQLite database | `database/database.sqlite` | Yes |
| Meilisearch index | `~/Library/Application Support/CORBA Monitor/meilisearch/` | Yes |
| Log files | `storage/logs/` | Yes |
| Cache | `storage/framework/cache/` | Cleared on restart |

## Building for Distribution

```bash
# Build for current platform
php artisan native:build

# Output locations:
#   macOS: build/CORBA Monitor.dmg
#   Windows: build/CORBA Monitor Setup.exe
#   Linux: build/CORBA Monitor.AppImage
```

### Bundling Meilisearch

For multi-platform builds, place all platform binaries in `extras/meilisearch/`:

```
extras/meilisearch/
├── meilisearch-macos-arm64
├── meilisearch-macos-amd64
├── meilisearch-linux-amd64
└── meilisearch-windows-amd64.exe
```

NativePHP bundles everything in `extras/` into the distributable.

### Bundling the CORBA Agent

```bash
cd ../corba-interceptor
mvn clean package
cp target/corba-interceptor-1.0.0.jar ../corba-monitor/extras/java/corba-interceptor.jar
```

## REST API

The Java agent sends data to these endpoints:

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/traffic` | Single traffic event |
| `POST` | `/api/traffic/batch` | Batch of events |
| `POST` | `/api/nameserver/report` | Nameserver scan results |
| `GET` | `/api/health` | Health check |
| `GET` | `/api/search?q=...` | Full-text search |

## Development

```bash
# Browser mode (for development)
php artisan serve          # Laravel on :8000
npm run dev                # Vite HMR

# Desktop mode
php artisan native:serve   # Opens Electron window

# Generate demo data
php artisan corba:demo-traffic --count=100
```

## Environment Variables

See `.env.native` for all available options. Key settings:

```env
DB_CONNECTION=sqlite                    # No MySQL needed
CACHE_STORE=file                        # No Redis needed
MEILISEARCH_HOST=http://127.0.0.1:7700  # Local binary
CORBA_NAMESERVER_HOST=localhost          # Your CORBA NS
CORBA_NAMESERVER_PORT=2809              # Standard port
```
