# CORBA Monitor

A modern, real-time CORBA traffic monitoring and visualization platform built with **Laravel 11**, **Livewire 3**, **Flux UI Pro**, **Meilisearch**, and **WebSockets**.

> Think of it as "Postman DevTools" for your CORBA ecosystem — see every request, explore your naming service, and visualize service topology in real-time.

---

## Features

| Feature | Description |
|---------|-------------|
| **Live Dashboard** | Real-time traffic feed with auto-refreshing stats, latency metrics, and error rates |
| **Service Topology** | Interactive D3.js force-directed graph showing all consumers, suppliers, and their connections |
| **Traffic Search** | Full-text search over all CORBA traffic powered by Meilisearch with filters and highlighting |
| **Nameserver Explorer** | Browse and scan the CORBA Naming Service tree, inspect IORs, check service health |
| **Real-time Updates** | WebSocket-based live streaming via Laravel Reverb — see traffic as it happens |
| **REST API** | Ingest traffic from Portable Interceptors, search logs, trigger nameserver scans |
| **Docker-Ready** | Single `docker compose up` to start everything |

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                        Browser (Dashboard)                       │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────────────┐  │
│  │ Dashboard │  │ Services │  │ Traffic  │  │   Nameserver   │  │
│  │  (Live)   │  │ Topology │  │ Search   │  │   Explorer     │  │
│  └─────┬─────┘  └─────┬────┘  └─────┬────┘  └───────┬────────┘  │
│        │ WebSocket     │ Livewire    │ ES Query       │ HTTP     │
└────────┼───────────────┼─────────────┼────────────────┼──────────┘
         │               │             │                │
┌────────▼───────────────▼─────────────▼────────────────▼──────────┐
│                     Laravel Application                          │
│  ┌─────────────┐  ┌───────────────┐  ┌────────────────────────┐ │
│  │ Traffic API  │  │ Livewire      │  │ Nameserver Scanner     │ │
│  │ (Ingestion)  │  │ Components    │  │ (Bridge Client)        │ │
│  └──────┬───────┘  └───────────────┘  └───────────┬────────────┘ │
│         │                                          │             │
│  ┌──────▼───────┐  ┌───────────────┐  ┌───────────▼────────┐   │
│  │ MySQL        │  │ Meilisearch    │  │ Redis              │   │
│  │ (persistent) │  │ (search)      │  │ (cache/queue/ws)   │   │
│  └──────────────┘  └───────────────┘  └────────────────────┘   │
└──────────────────────────────────────────────────────────────────┘
         ▲                                           ▲
         │ HTTP POST /api/traffic                    │
┌────────┴──────────┐                    ┌───────────┴──────────┐
│ Java/C++ App      │                    │ CORBA Nameserver     │
│ (with Portable    │                    │ (via Bridge Service) │
│  Interceptors)    │                    │                      │
└───────────────────┘                    └──────────────────────┘
```

---

## Quick Start

### 1. Clone & Setup

```bash
git clone <your-repo>
cd corba-monitor
bash setup.sh
```

### 2. Open Dashboard

Navigate to **http://localhost:8080**

### 3. Generate Demo Data (optional)

```bash
# Generate 200 sample entries
docker compose exec app php artisan corba:demo-traffic --count=200

# Or run in live mode for continuous demo data
docker compose exec app php artisan corba:demo-traffic --live --interval=300
```

---

## API Reference

### Ingest Traffic (from Interceptors)

```http
POST /api/traffic
Content-Type: application/json

{
  "operation": "getPosition",
  "interface_name": "VehicleTracker",
  "repository_id": "IDL:FleetManagement/VehicleTracker:1.0",
  "direction": "request",
  "status": "success",
  "source_host": "10.0.1.10",
  "source_port": 9001,
  "source_service_name": "fleet-tracker-01",
  "target_host": "10.0.2.10",
  "target_port": 9002,
  "target_service_name": "route-engine",
  "latency_ms": 12.5,
  "giop_version": "1.2",
  "request_data": {"vehicle_id": 42},
  "response_data": {"lat": 39.92, "lon": 32.85},
  "timestamp": "2025-03-15T14:30:00Z"
}
```

### Batch Ingest

```http
POST /api/traffic/batch
Content-Type: application/json

{
  "events": [
    {"operation": "getPosition", ...},
    {"operation": "updateLocation", ...}
  ]
}
```

### Full-Text Search

```http
GET /api/search?q=getPosition&status=error&interface_name=VehicleTracker&page=1&per_page=50
```

### Traffic Statistics

```http
GET /api/stats?interval=1m&minutes=30
```

### Health Check

```http
GET /api/health
```

### Trigger Nameserver Scan

```http
POST /api/nameserver/scan
```

---

## Integrating with Your CORBA Application

### Java Portable Interceptor Example

```java
public class MonitorClientInterceptor extends LocalObject
    implements ClientRequestInterceptor {

    private static final String MONITOR_URL = "http://corba-monitor:8080/api/traffic";

    @Override
    public void send_request(ClientRequestInfo ri) {
        // Capture outgoing request
        sendToMonitor(Map.of(
            "operation", ri.operation(),
            "direction", "request",
            "interceptor_point", "send_request",
            "target_host", extractHost(ri.effective_target()),
            "timestamp", Instant.now().toString()
        ));
    }

    @Override
    public void receive_reply(ClientRequestInfo ri) {
        sendToMonitor(Map.of(
            "operation", ri.operation(),
            "direction", "reply",
            "status", "success",
            "interceptor_point", "receive_reply"
        ));
    }

    @Override
    public void receive_exception(ClientRequestInfo ri) {
        sendToMonitor(Map.of(
            "operation", ri.operation(),
            "status", "exception",
            "exception_type", ri.received_exception_id()
        ));
    }

    private void sendToMonitor(Map<String, String> data) {
        // HTTP POST to CORBA Monitor API
        HttpClient.newHttpClient().sendAsync(
            HttpRequest.newBuilder()
                .uri(URI.create(MONITOR_URL))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(
                    new Gson().toJson(data)))
                .build(),
            HttpResponse.BodyHandlers.discarding()
        );
    }
}
```

---

## Docker Services

| Service | Port | Description |
|---------|------|-------------|
| `nginx` | 8080 | Web server (Dashboard) |
| `app` | 9000 | PHP-FPM (Laravel) |
| `reverb` | 8085 | WebSocket server |
| `mysql` | 3306 | Database |
| `redis` | 6379 | Cache, Queue, WebSocket |
| `meilisearch` | 7700 | Full-text search |
| `queue` | — | Background job worker |
| `scheduler` | — | Cron-like scheduler |

---

## Artisan Commands

```bash
# Setup Meilisearch indices
php artisan corba:setup-meilisearch

# Scan CORBA Naming Service
php artisan corba:scan-nameserver
php artisan corba:scan-nameserver --continuous

# Generate demo traffic
php artisan corba:demo-traffic --count=500
php artisan corba:demo-traffic --live --interval=200
```

---

## Configuration

All configuration via `.env`:

```bash
# CORBA Nameserver Bridge
CORBA_NAMESERVER_HOST=localhost
CORBA_BRIDGE_PORT=9090
CORBA_POLL_INTERVAL=5

# Meilisearch
MEILISEARCH_HOST=http://meilisearch:7700
MEILISEARCH_KEY=corba-monitor-master-key

# WebSocket (Reverb)
REVERB_HOST=reverb
REVERB_PORT=8085
```

---

## Tech Stack

- **Backend**: Laravel 11, PHP 8.3
- **Frontend**: Livewire 3, Flux UI Pro, Tailwind CSS 4, D3.js
- **Real-time**: Laravel Reverb (WebSockets)
- **Search**: Meilisearch 8.12
- **Database**: MySQL 8.0
- **Cache/Queue**: Redis 7
- **Infrastructure**: Docker Compose

---

## License

MIT
