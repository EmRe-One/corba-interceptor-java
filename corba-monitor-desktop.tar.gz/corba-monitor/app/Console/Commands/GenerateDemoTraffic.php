<?php

namespace App\Console\Commands;

use App\Services\TrafficIngestionService;
use Illuminate\Console\Command;
use Illuminate\Support\Str;

class GenerateDemoTraffic extends Command
{
    protected $signature = 'corba:demo-traffic
        {--count=100 : Number of traffic entries to generate}
        {--live : Generate continuously in real-time}
        {--interval=500 : Interval in ms for live mode}';

    protected $description = 'Generate demo CORBA traffic data for testing the dashboard';

    private array $interfaces = [
        'IDL:FleetManagement/VehicleTracker:1.0',
        'IDL:FleetManagement/RouteService:1.0',
        'IDL:FleetManagement/DriverService:1.0',
        'IDL:Notification/EventChannel:1.0',
        'IDL:Auth/SessionManager:1.0',
        'IDL:Inventory/StockService:1.0',
        'IDL:Billing/PaymentGateway:1.0',
    ];

    private array $operations = [
        'VehicleTracker' => ['getPosition', 'updateLocation', 'getRoute', 'setDestination', 'getStatus'],
        'RouteService' => ['calculateRoute', 'optimizeRoute', 'getETA', 'getTrafficInfo'],
        'DriverService' => ['authenticate', 'getSchedule', 'updateStatus', 'logTrip'],
        'EventChannel' => ['push', 'subscribe', 'unsubscribe', 'getEvents'],
        'SessionManager' => ['login', 'logout', 'validate', 'refresh'],
        'StockService' => ['checkAvailability', 'reserve', 'release', 'getInventory'],
        'PaymentGateway' => ['authorize', 'capture', 'refund', 'getStatus'],
    ];

    private array $services = [
        ['name' => 'fleet-tracker-01', 'host' => '10.0.1.10', 'port' => 9001, 'type' => 'consumer'],
        ['name' => 'fleet-tracker-02', 'host' => '10.0.1.11', 'port' => 9001, 'type' => 'consumer'],
        ['name' => 'route-engine', 'host' => '10.0.2.10', 'port' => 9002, 'type' => 'supplier'],
        ['name' => 'driver-svc', 'host' => '10.0.2.20', 'port' => 9003, 'type' => 'both'],
        ['name' => 'event-broker', 'host' => '10.0.3.10', 'port' => 9004, 'type' => 'supplier'],
        ['name' => 'auth-service', 'host' => '10.0.3.20', 'port' => 9005, 'type' => 'supplier'],
        ['name' => 'inventory-svc', 'host' => '10.0.4.10', 'port' => 9006, 'type' => 'supplier'],
        ['name' => 'billing-gateway', 'host' => '10.0.4.20', 'port' => 9007, 'type' => 'supplier'],
        ['name' => 'mobile-app-gw', 'host' => '10.0.5.10', 'port' => 9008, 'type' => 'consumer'],
        ['name' => 'admin-console', 'host' => '10.0.5.20', 'port' => 9009, 'type' => 'consumer'],
    ];

    public function handle(TrafficIngestionService $ingestion): int
    {
        $count = (int) $this->option('count');
        $live = $this->option('live');
        $interval = (int) $this->option('interval');

        $this->info($live ? "Generating live demo traffic..." : "Generating {$count} demo traffic entries...");

        $bar = $live ? null : $this->output->createProgressBar($count);

        $generated = 0;
        do {
            $data = $this->generateEvent();
            $ingestion->ingest($data);
            $generated++;

            if ($bar) $bar->advance();

            if ($live) {
                usleep($interval * 1000);
                if ($generated % 10 === 0) {
                    $this->info("Generated {$generated} events...");
                }
            }
        } while ($live || $generated < $count);

        if ($bar) $bar->finish();
        $this->newLine();
        $this->info("Done! Generated {$generated} traffic entries.");

        return self::SUCCESS;
    }

    private function generateEvent(): array
    {
        $interface = $this->interfaces[array_rand($this->interfaces)];
        $shortName = explode('/', explode(':', $interface)[1])[1] ?? 'Unknown';
        $ops = $this->operations[$shortName] ?? ['unknown'];
        $operation = $ops[array_rand($ops)];

        $source = $this->services[array_rand($this->services)];
        $target = $this->services[array_rand($this->services)];

        while ($target['name'] === $source['name']) {
            $target = $this->services[array_rand($this->services)];
        }

        $isError = random_int(1, 100) <= 5;
        $status = $isError
            ? ['error', 'timeout', 'exception'][array_rand(['error', 'timeout', 'exception'])]
            : 'success';

        $requestData = $this->generateIdlRequest($shortName, $operation);
        $responseData = $isError ? null : $this->generateIdlResponse($shortName, $operation);

        return [
            'request_id' => Str::uuid()->toString(),
            'operation' => $operation,
            'interface_name' => $shortName,
            'repository_id' => $interface,
            'direction' => random_int(0, 1) ? 'request' : 'reply',
            'status' => $status,
            'source_host' => $source['host'],
            'source_port' => $source['port'],
            'source_service_name' => $source['name'],
            'target_host' => $target['host'],
            'target_port' => $target['port'],
            'target_service_name' => $target['name'],
            'latency_ms' => round(random_int(1, 500) + (random_int(0, 100) / 100), 2),
            'giop_version' => '1.2',
            'message_type' => 'Request',
            'request_size_bytes' => random_int(64, 8192),
            'response_size_bytes' => random_int(64, 32768),
            'interceptor_point' => ['send_request', 'receive_reply', 'receive_request', 'send_reply'][array_rand([0, 1, 2, 3])],
            'request_data' => $requestData,
            'response_data' => $responseData,
            'error_message' => $isError ? 'CORBA::' . ['TRANSIENT', 'COMM_FAILURE', 'OBJECT_NOT_EXIST', 'NO_PERMISSION', 'BAD_PARAM', 'MARSHAL', 'INV_OBJREF'][array_rand([0, 1, 2, 3, 4, 5, 6])] : null,
            'exception_type' => $isError ? ['SYSTEM_EXCEPTION', 'USER_EXCEPTION'][array_rand([0, 1])] : null,
            'context_data' => [
                'service_context' => [
                    'context_id' => random_int(100000, 999999),
                    'encoding' => 'CDR',
                ],
                'propagation' => [
                    'transaction_id' => Str::uuid()->toString(),
                    'priority' => random_int(0, 10),
                ],
            ],
            'timestamp' => now()->subSeconds(random_int(0, 1800)),
        ];
    }

    /**
     * Generate realistic IDL-style request parameters
     */
    private function generateIdlRequest(string $interface, string $operation): array
    {
        $data = match ($interface) {
            'VehicleTracker' => match ($operation) {
                'getPosition' => [
                    '_idl_type' => 'FleetManagement::VehicleTracker::getPosition',
                    'params' => [
                        'vehicle_id' => [
                            '_type' => 'FleetManagement::VehicleId',
                            'value' => 'VH-' . str_pad(random_int(1, 9999), 4, '0', STR_PAD_LEFT),
                        ],
                        'include_history' => ['_type' => 'boolean', 'value' => (bool) random_int(0, 1)],
                    ],
                ],
                'updateLocation' => [
                    '_idl_type' => 'FleetManagement::VehicleTracker::updateLocation',
                    'params' => [
                        'vehicle_id' => ['_type' => 'FleetManagement::VehicleId', 'value' => 'VH-' . str_pad(random_int(1, 9999), 4, '0', STR_PAD_LEFT)],
                        'position' => [
                            '_type' => 'FleetManagement::GeoPosition',
                            'value' => [
                                'latitude' => ['_type' => 'double', 'value' => round(39.9 + (random_int(-100, 100) / 1000), 6)],
                                'longitude' => ['_type' => 'double', 'value' => round(32.8 + (random_int(-100, 100) / 1000), 6)],
                                'altitude' => ['_type' => 'float', 'value' => round(random_int(800, 1200) + random_int(0, 99) / 100, 2)],
                                'heading' => ['_type' => 'unsigned short', 'value' => random_int(0, 359)],
                                'speed_kmh' => ['_type' => 'float', 'value' => round(random_int(0, 120) + random_int(0, 9) / 10, 1)],
                            ],
                        ],
                        'timestamp' => ['_type' => 'TimeBase::UtcT', 'value' => now()->subSeconds(random_int(0, 60))->toIso8601String()],
                    ],
                ],
                'getRoute' => [
                    '_idl_type' => 'FleetManagement::VehicleTracker::getRoute',
                    'params' => [
                        'vehicle_id' => ['_type' => 'FleetManagement::VehicleId', 'value' => 'VH-' . str_pad(random_int(1, 9999), 4, '0', STR_PAD_LEFT)],
                        'route_filter' => [
                            '_type' => 'FleetManagement::RouteFilter',
                            'value' => [
                                'status' => ['_type' => 'FleetManagement::RouteStatus', 'value' => ['ACTIVE', 'PLANNED', 'COMPLETED'][array_rand([0, 1, 2])]],
                                'max_results' => ['_type' => 'unsigned long', 'value' => random_int(1, 50)],
                            ],
                        ],
                    ],
                ],
                default => $this->genericIdlRequest($interface, $operation),
            },
            'RouteService' => match ($operation) {
                'calculateRoute' => [
                    '_idl_type' => 'FleetManagement::RouteService::calculateRoute',
                    'params' => [
                        'origin' => [
                            '_type' => 'FleetManagement::GeoPosition',
                            'value' => [
                                'latitude' => ['_type' => 'double', 'value' => round(39.9 + (random_int(-500, 500) / 1000), 6)],
                                'longitude' => ['_type' => 'double', 'value' => round(32.8 + (random_int(-500, 500) / 1000), 6)],
                            ],
                        ],
                        'destination' => [
                            '_type' => 'FleetManagement::GeoPosition',
                            'value' => [
                                'latitude' => ['_type' => 'double', 'value' => round(39.9 + (random_int(-500, 500) / 1000), 6)],
                                'longitude' => ['_type' => 'double', 'value' => round(32.8 + (random_int(-500, 500) / 1000), 6)],
                            ],
                        ],
                        'options' => [
                            '_type' => 'FleetManagement::RouteOptions',
                            'value' => [
                                'avoid_tolls' => ['_type' => 'boolean', 'value' => (bool) random_int(0, 1)],
                                'avoid_highways' => ['_type' => 'boolean', 'value' => (bool) random_int(0, 1)],
                                'vehicle_type' => ['_type' => 'FleetManagement::VehicleType', 'value' => ['TRUCK', 'VAN', 'CAR', 'BUS'][array_rand([0, 1, 2, 3])]],
                                'max_weight_kg' => ['_type' => 'unsigned long', 'value' => random_int(1000, 40000)],
                            ],
                        ],
                        'waypoints' => [
                            '_type' => 'sequence<FleetManagement::GeoPosition>',
                            'value' => array_map(fn () => [
                                'latitude' => round(39.9 + (random_int(-500, 500) / 1000), 6),
                                'longitude' => round(32.8 + (random_int(-500, 500) / 1000), 6),
                            ], range(1, random_int(0, 3))),
                        ],
                    ],
                ],
                'getETA' => [
                    '_idl_type' => 'FleetManagement::RouteService::getETA',
                    'params' => [
                        'route_id' => ['_type' => 'FleetManagement::RouteId', 'value' => 'RT-' . random_int(10000, 99999)],
                        'from_waypoint' => ['_type' => 'unsigned short', 'value' => random_int(0, 5)],
                    ],
                ],
                default => $this->genericIdlRequest($interface, $operation),
            },
            'PaymentGateway' => match ($operation) {
                'authorize' => [
                    '_idl_type' => 'Billing::PaymentGateway::authorize',
                    'params' => [
                        'payment_request' => [
                            '_type' => 'Billing::PaymentRequest',
                            'value' => [
                                'merchant_id' => ['_type' => 'string', 'value' => 'MCH-' . random_int(100, 999)],
                                'amount' => [
                                    '_type' => 'Billing::Money',
                                    'value' => [
                                        'currency' => ['_type' => 'string', 'value' => ['TRY', 'EUR', 'USD'][array_rand([0, 1, 2])]],
                                        'amount_minor' => ['_type' => 'long long', 'value' => random_int(100, 999999)],
                                    ],
                                ],
                                'reference' => ['_type' => 'string', 'value' => 'INV-' . date('Ymd') . '-' . random_int(1000, 9999)],
                                'idempotency_key' => ['_type' => 'string', 'value' => Str::uuid()->toString()],
                            ],
                        ],
                    ],
                ],
                default => $this->genericIdlRequest($interface, $operation),
            },
            default => $this->genericIdlRequest($interface, $operation),
        };

        return $data;
    }

    /**
     * Generate realistic IDL-style response data
     */
    private function generateIdlResponse(string $interface, string $operation): array
    {
        return match ($interface) {
            'VehicleTracker' => match ($operation) {
                'getPosition' => [
                    '_idl_type' => 'FleetManagement::VehicleTracker::getPosition::_return',
                    'return_value' => [
                        '_type' => 'FleetManagement::VehiclePosition',
                        'value' => [
                            'vehicle_id' => ['_type' => 'string', 'value' => 'VH-' . str_pad(random_int(1, 9999), 4, '0', STR_PAD_LEFT)],
                            'position' => [
                                '_type' => 'FleetManagement::GeoPosition',
                                'value' => [
                                    'latitude' => ['_type' => 'double', 'value' => round(39.9 + (random_int(-100, 100) / 1000), 6)],
                                    'longitude' => ['_type' => 'double', 'value' => round(32.8 + (random_int(-100, 100) / 1000), 6)],
                                    'altitude' => ['_type' => 'float', 'value' => round(random_int(800, 1200) + random_int(0, 99) / 100, 2)],
                                    'heading' => ['_type' => 'unsigned short', 'value' => random_int(0, 359)],
                                    'speed_kmh' => ['_type' => 'float', 'value' => round(random_int(0, 120) + random_int(0, 9) / 10, 1)],
                                ],
                            ],
                            'status' => ['_type' => 'FleetManagement::VehicleStatus', 'value' => ['MOVING', 'IDLE', 'PARKED', 'MAINTENANCE'][array_rand([0, 1, 2, 3])]],
                            'fuel_level_pct' => ['_type' => 'float', 'value' => round(random_int(5, 100) + random_int(0, 9) / 10, 1)],
                            'odometer_km' => ['_type' => 'unsigned long', 'value' => random_int(10000, 500000)],
                            'last_updated' => ['_type' => 'TimeBase::UtcT', 'value' => now()->subSeconds(random_int(0, 120))->toIso8601String()],
                        ],
                    ],
                ],
                'updateLocation' => [
                    '_idl_type' => 'FleetManagement::VehicleTracker::updateLocation::_return',
                    'return_value' => ['_type' => 'boolean', 'value' => true],
                    'out_params' => [
                        'geofence_alerts' => [
                            '_type' => 'sequence<FleetManagement::GeofenceAlert>',
                            'value' => random_int(0, 1) ? [[
                                'zone_id' => 'GF-' . random_int(100, 999),
                                'zone_name' => ['Ankara City Center', 'Depot Zone A', 'Highway Corridor', 'Rest Area'][array_rand([0, 1, 2, 3])],
                                'event' => ['ENTERED', 'EXITED'][array_rand([0, 1])],
                            ]] : [],
                        ],
                    ],
                ],
                default => $this->genericIdlResponse($interface, $operation),
            },
            'RouteService' => match ($operation) {
                'calculateRoute' => [
                    '_idl_type' => 'FleetManagement::RouteService::calculateRoute::_return',
                    'return_value' => [
                        '_type' => 'FleetManagement::Route',
                        'value' => [
                            'route_id' => ['_type' => 'FleetManagement::RouteId', 'value' => 'RT-' . random_int(10000, 99999)],
                            'distance_km' => ['_type' => 'double', 'value' => round(random_int(5, 500) + random_int(0, 99) / 100, 2)],
                            'duration_minutes' => ['_type' => 'unsigned long', 'value' => random_int(10, 600)],
                            'toll_cost' => [
                                '_type' => 'Billing::Money',
                                'value' => [
                                    'currency' => ['_type' => 'string', 'value' => 'TRY'],
                                    'amount_minor' => ['_type' => 'long long', 'value' => random_int(0, 50000)],
                                ],
                            ],
                            'segments' => [
                                '_type' => 'sequence<FleetManagement::RouteSegment>',
                                'value' => array_map(fn ($i) => [
                                    'segment_id' => $i,
                                    'road_name' => ['O-4 Otoyolu', 'E-80', 'D-750', 'Ankara Blvd', 'Atatürk Cad.'][array_rand([0, 1, 2, 3, 4])],
                                    'distance_km' => round(random_int(1, 50) + random_int(0, 9) / 10, 1),
                                    'speed_limit_kmh' => [50, 80, 90, 110, 120][array_rand([0, 1, 2, 3, 4])],
                                ], range(1, random_int(2, 5))),
                            ],
                        ],
                    ],
                ],
                'getETA' => [
                    '_idl_type' => 'FleetManagement::RouteService::getETA::_return',
                    'return_value' => [
                        '_type' => 'FleetManagement::ETAResult',
                        'value' => [
                            'estimated_arrival' => ['_type' => 'TimeBase::UtcT', 'value' => now()->addMinutes(random_int(10, 300))->toIso8601String()],
                            'remaining_km' => ['_type' => 'double', 'value' => round(random_int(1, 200) + random_int(0, 99) / 100, 2)],
                            'confidence' => ['_type' => 'float', 'value' => round(random_int(70, 99) + random_int(0, 9) / 10, 1)],
                            'traffic_delay_minutes' => ['_type' => 'unsigned short', 'value' => random_int(0, 45)],
                        ],
                    ],
                ],
                default => $this->genericIdlResponse($interface, $operation),
            },
            default => $this->genericIdlResponse($interface, $operation),
        };
    }

    private function genericIdlRequest(string $interface, string $operation): array
    {
        return [
            '_idl_type' => "{$interface}::{$operation}",
            'params' => [
                'id' => ['_type' => 'string', 'value' => strtoupper(substr($interface, 0, 2)) . '-' . random_int(1000, 9999)],
                'options' => [
                    '_type' => "{$interface}::RequestOptions",
                    'value' => [
                        'timeout_ms' => ['_type' => 'unsigned long', 'value' => random_int(1000, 30000)],
                        'priority' => ['_type' => "{$interface}::Priority", 'value' => ['LOW', 'NORMAL', 'HIGH', 'CRITICAL'][array_rand([0, 1, 2, 3])]],
                        'trace_enabled' => ['_type' => 'boolean', 'value' => (bool) random_int(0, 1)],
                    ],
                ],
            ],
        ];
    }

    private function genericIdlResponse(string $interface, string $operation): array
    {
        return [
            '_idl_type' => "{$interface}::{$operation}::_return",
            'return_value' => [
                '_type' => "{$interface}::Result",
                'value' => [
                    'status_code' => ['_type' => 'unsigned short', 'value' => 0],
                    'message' => ['_type' => 'string', 'value' => 'OK'],
                    'processing_time_ms' => ['_type' => 'unsigned long', 'value' => random_int(1, 200)],
                ],
            ],
        ];
    }
}
