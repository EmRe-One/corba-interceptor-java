<?php

namespace App\Console\Commands;

use App\Services\CorbaNameserverService;
use Illuminate\Console\Command;

class ScanNameserver extends Command
{
    protected $signature = 'corba:scan-nameserver {--continuous : Run continuously with interval}';
    protected $description = 'Scan the CORBA Naming Service and discover registered services';

    public function handle(CorbaNameserverService $nameserver): int
    {
        if (!$nameserver->isBridgeAvailable()) {
            $this->error("Nameserver bridge not available at {$nameserver->getBridgeUrl()}");
            $this->info("Start the CORBA Agent: java -jar corba-interceptor.jar");
            $this->info("The bridge runs on port " . config('services.corba.bridge_port', 9090));
            return self::FAILURE;
        }

        if (!$nameserver->isBridgeConnected()) {
            $this->warn("Bridge is running but NOT connected to Naming Service.");
            $this->info("Check that the CORBA Naming Service is running on " .
                config('services.corba.nameserver_host') . ':' . config('services.corba.nameserver_port'));
            return self::FAILURE;
        }

        $continuous = $this->option('continuous');
        $interval = (int) config('services.corba.poll_interval', 5);

        do {
            $this->info("Scanning nameserver via bridge /tree endpoint...");
            $entries = $nameserver->scanViaTree();
            $this->info("Discovered " . count($entries) . " entries.");

            foreach ($entries as $entry) {
                $status = $entry->is_alive ? '<fg=green>ALIVE</>' : '<fg=red>DOWN</>';
                $host = $entry->host ?? '?';
                $port = $entry->port ?? '?';
                $path = trim(($entry->context_path ?? '') . '/' . $entry->binding_name, '/');
                $this->line("  [{$status}] {$path} → {$host}:{$port}");
            }

            if ($continuous) {
                $this->info("Waiting {$interval}s before next scan...");
                sleep($interval);
            }
        } while ($continuous);

        return self::SUCCESS;
    }
}
