<?php

namespace App\Console\Commands;

use App\Services\MeilisearchService;
use Illuminate\Console\Command;

class SetupMeilisearch extends Command
{
    protected $signature = 'corba:setup-meilisearch';
    protected $description = 'Create Meilisearch indexes with proper settings';

    public function handle(MeilisearchService $meili): int
    {
        if (!$meili->isHealthy()) {
            $this->error("Meilisearch is not available. Check your connection settings.");
            return self::FAILURE;
        }

        $this->info("Setting up Meilisearch indexes...");
        $meili->setupIndices();
        $this->info("Meilisearch indexes created successfully.");
        $this->info("Note: Index settings are applied asynchronously — they'll be ready in a moment.");

        return self::SUCCESS;
    }
}
