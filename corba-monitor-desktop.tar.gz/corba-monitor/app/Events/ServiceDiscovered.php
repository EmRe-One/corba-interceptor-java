<?php

namespace App\Events;

use App\Models\CorbaService;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ServiceDiscovered implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public CorbaService $service
    ) {}

    public function broadcastOn(): array
    {
        return [
            new Channel('corba-services'),
        ];
    }

    public function broadcastAs(): string
    {
        return 'service.discovered';
    }

    public function broadcastWith(): array
    {
        return [
            'id' => $this->service->id,
            'name' => $this->service->name,
            'type' => $this->service->type,
            'host' => $this->service->host,
            'port' => $this->service->port,
            'interface_name' => $this->service->interface_name,
            'status' => $this->service->status,
            'nameserver_path' => $this->service->nameserver_path,
        ];
    }
}
