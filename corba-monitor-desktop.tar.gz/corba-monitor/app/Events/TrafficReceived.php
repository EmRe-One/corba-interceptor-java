<?php

namespace App\Events;

use App\Models\TrafficLog;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class TrafficReceived implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(
        public TrafficLog $trafficLog
    ) {}

    public function broadcastOn(): array
    {
        return [
            new Channel('corba-traffic'),
        ];
    }

    public function broadcastAs(): string
    {
        return 'traffic.received';
    }

    public function broadcastWith(): array
    {
        return [
            'id' => $this->trafficLog->id,
            'request_id' => $this->trafficLog->request_id,
            'operation' => $this->trafficLog->operation,
            'interface_name' => $this->trafficLog->interface_name,
            'status' => $this->trafficLog->status,
            'direction' => $this->trafficLog->direction,
            'latency_ms' => $this->trafficLog->latency_ms,
            'source' => $this->trafficLog->sourceService?->name ?? $this->trafficLog->source_host,
            'target' => $this->trafficLog->targetService?->name ?? $this->trafficLog->target_host,
            'error_message' => $this->trafficLog->error_message,
            'timestamp' => $this->trafficLog->timestamp->toIso8601String(),
        ];
    }
}
