<?php

namespace App\Http\Controllers;

use App\Services\TrafficIngestionService;
use App\Services\MeilisearchService;
use App\Services\CorbaNameserverService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TrafficApiController extends Controller
{
    public function __construct(
        private TrafficIngestionService $ingestion,
        private MeilisearchService $meilisearch,
        private CorbaNameserverService $nameserver,
    ) {}

    /**
     * POST /api/traffic - Ingest a single traffic event
     */
    public function ingest(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'request_id' => 'nullable|string',
            'operation' => 'required|string',
            'interface_name' => 'nullable|string',
            'repository_id' => 'nullable|string',
            'direction' => 'in:request,reply',
            'status' => 'in:success,error,timeout,exception',
            'source_host' => 'nullable|string',
            'source_port' => 'nullable|integer',
            'target_host' => 'nullable|string',
            'target_port' => 'nullable|integer',
            'source_service_name' => 'nullable|string',
            'target_service_name' => 'nullable|string',
            'request_data' => 'nullable',
            'response_data' => 'nullable',
            'error_message' => 'nullable|string',
            'exception_type' => 'nullable|string',
            'latency_ms' => 'nullable|numeric',
            'giop_version' => 'nullable|string',
            'message_type' => 'nullable|string',
            'request_size_bytes' => 'nullable|integer',
            'response_size_bytes' => 'nullable|integer',
            'interceptor_point' => 'nullable|string',
            'context_data' => 'nullable|array',
            'timestamp' => 'nullable|date',
        ]);

        $log = $this->ingestion->ingest($validated);

        return response()->json([
            'status' => 'ok',
            'id' => $log->id,
            'request_id' => $log->request_id,
        ], 201);
    }

    /**
     * POST /api/traffic/batch - Ingest multiple traffic events
     */
    public function ingestBatch(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'events' => 'required|array|min:1|max:1000',
            'events.*.operation' => 'required|string',
        ]);

        $results = $this->ingestion->ingestBatch($validated['events']);

        return response()->json([
            'status' => 'ok',
            'count' => count($results),
            'ids' => collect($results)->pluck('id'),
        ], 201);
    }

    /**
     * GET /api/search - Full-text search via Meilisearch
     */
    public function search(Request $request): JsonResponse
    {
        $query = $request->input('q', '');
        $filters = $request->only(['status', 'direction', 'interface_name', 'from', 'to', 'min_latency']);
        $page = (int) $request->input('page', 1);
        $perPage = min((int) $request->input('per_page', 50), 200);

        $results = $this->meilisearch->searchTraffic($query, $filters, $page, $perPage);

        return response()->json($results);
    }

    /**
     * GET /api/stats - Traffic statistics
     */
    public function stats(Request $request): JsonResponse
    {
        $interval = $request->input('interval', '1m');
        $minutes = (int) $request->input('minutes', 30);

        $stats = $this->meilisearch->getTrafficStats($interval, $minutes);

        return response()->json($stats);
    }

    /**
     * POST /api/nameserver/scan - Trigger a nameserver scan (pull from bridge)
     */
    public function scanNameserver(): JsonResponse
    {
        $entries = $this->nameserver->scanNameserver();

        return response()->json([
            'status' => 'ok',
            'discovered' => count($entries),
        ]);
    }

    /**
     * POST /api/nameserver/report - Receive scan results pushed from Java agent
     */
    public function receiveScanReport(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'source' => 'nullable|string',
            'entries' => 'required|array',
            'entries.*.path' => 'required|string',
            'entries.*.name' => 'required|string',
            'entries.*.type' => 'required|in:context,object',
        ]);

        $processed = $this->nameserver->processAgentScanResults($validated['entries']);

        return response()->json([
            'status' => 'ok',
            'source' => $validated['source'] ?? 'unknown',
            'received' => count($validated['entries']),
            'processed' => $processed,
        ], 201);
    }

    /**
     * GET /api/health - Health check
     */
    public function health(): JsonResponse
    {
        return response()->json([
            'status' => 'ok',
            'meilisearch' => $this->meilisearch->isHealthy(),
            'nameserver_bridge' => $this->nameserver->isBridgeAvailable(),
            'timestamp' => now()->toIso8601String(),
        ]);
    }
}
