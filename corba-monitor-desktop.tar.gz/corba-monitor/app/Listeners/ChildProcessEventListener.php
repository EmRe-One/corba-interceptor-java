<?php

namespace App\Listeners;

use Native\Desktop\Events\ChildProcess\ProcessSpawned;
use Native\Desktop\Events\ChildProcess\ProcessExited;
use Native\Desktop\Events\ChildProcess\MessageReceived;
use Native\Desktop\Events\ChildProcess\ErrorReceived;
use Native\Desktop\Facades\ChildProcess;
use Illuminate\Support\Facades\Log;

/**
 * Handles NativePHP ChildProcess lifecycle events.
 *
 * - Logs spawns and exits
 * - Auto-restarts critical services (Meilisearch, Reverb) on crash
 * - Captures stdout/stderr for debugging
 */
class ChildProcessEventListener
{
    /**
     * Critical services that should be restarted on unexpected exit.
     */
    private const CRITICAL_SERVICES = ['meilisearch', 'reverb'];

    /**
     * Max restart attempts before giving up.
     */
    private const MAX_RESTARTS = 3;

    /**
     * Track restart counts.
     */
    private static array $restartCounts = [];

    /**
     * Handle process spawned.
     */
    public function handleSpawned(ProcessSpawned $event): void
    {
        Log::info("[NativePHP] Process started: {$event->alias} (PID: {$event->pid})");

        // Reset restart counter on successful spawn
        self::$restartCounts[$event->alias] = 0;
    }

    /**
     * Handle process exit — auto-restart critical services.
     */
    public function handleExited(ProcessExited $event): void
    {
        $alias = $event->alias;
        $code = $event->code;

        if ($code === 0) {
            Log::info("[NativePHP] Process exited cleanly: {$alias}");
            return;
        }

        Log::warning("[NativePHP] Process crashed: {$alias} (exit code: {$code})");

        // Auto-restart critical services
        if (in_array($alias, self::CRITICAL_SERVICES)) {
            $count = (self::$restartCounts[$alias] ?? 0) + 1;
            self::$restartCounts[$alias] = $count;

            if ($count <= self::MAX_RESTARTS) {
                Log::info("[NativePHP] Auto-restarting {$alias} (attempt {$count}/" . self::MAX_RESTARTS . ")");

                // Small delay before restart
                usleep(500_000 * $count); // Progressive backoff

                try {
                    $process = ChildProcess::get($alias);
                    $process?->restart();
                } catch (\Exception $e) {
                    Log::error("[NativePHP] Restart failed for {$alias}: {$e->getMessage()}");
                }
            } else {
                Log::error("[NativePHP] {$alias} exceeded max restarts ({$count}). Manual intervention needed.");
            }
        }
    }

    /**
     * Handle stdout messages from child processes.
     */
    public function handleMessage(MessageReceived $event): void
    {
        // Log important messages, skip routine output
        $data = trim($event->data);
        if (empty($data)) return;

        // Only log non-routine messages to avoid log spam
        if ($this->isImportantMessage($event->alias, $data)) {
            Log::info("[{$event->alias}] {$data}");
        } else {
            Log::debug("[{$event->alias}] {$data}");
        }
    }

    /**
     * Handle stderr from child processes.
     */
    public function handleError(ErrorReceived $event): void
    {
        $data = trim($event->data);
        if (empty($data)) return;

        Log::error("[{$event->alias}] STDERR: {$data}");
    }

    /**
     * Determine if a message is important enough for INFO-level logging.
     */
    private function isImportantMessage(string $alias, string $data): bool
    {
        $important = ['error', 'warn', 'fail', 'exception', 'started', 'listening', 'ready'];

        $lower = strtolower($data);
        foreach ($important as $keyword) {
            if (str_contains($lower, $keyword)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Register event listeners.
     */
    public function subscribe($events): array
    {
        return [
            ProcessSpawned::class => 'handleSpawned',
            ProcessExited::class => 'handleExited',
            MessageReceived::class => 'handleMessage',
            ErrorReceived::class => 'handleError',
        ];
    }
}
