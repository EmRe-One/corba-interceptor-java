<?php

namespace App\Livewire\Dashboard;

use App\Models\CorbaService;
use App\Models\ServiceConnection;
use App\Models\TrafficLog;
use Livewire\Component;

class Overview extends Component
{
    public array $recentTraffic = [];
    public int $totalServices = 0;
    public int $onlineServices = 0;
    public int $totalRequests = 0;
    public int $errorCount = 0;
    public float $avgLatency = 0;
    public int $activeConnections = 0;
    public array $trafficTimeline = [];
    public array $statusBreakdown = [];
    public array $topOperations = [];
    public bool $isPaused = false;

    public function mount(): void
    {
        $this->refreshStats();
        $this->loadRecentTraffic();
    }

    public function refreshStats(): void
    {
        $this->totalServices = CorbaService::count();
        $this->onlineServices = CorbaService::online()->count();
        $this->activeConnections = ServiceConnection::where('status', 'active')->count();

        $fiveMinAgo = now()->subMinutes(5);
        $this->totalRequests = TrafficLog::where('timestamp', '>=', $fiveMinAgo)->count();
        $this->errorCount = TrafficLog::where('timestamp', '>=', $fiveMinAgo)->errors()->count();
        $this->avgLatency = round(
            TrafficLog::where('timestamp', '>=', $fiveMinAgo)->avg('latency_ms') ?? 0,
            2
        );

        // Timeline data for chart (last 30 minutes, per minute)
        $this->trafficTimeline = TrafficLog::where('timestamp', '>=', now()->subMinutes(30))
            ->selectRaw("DATE_FORMAT(timestamp, '%H:%i') as minute, COUNT(*) as count, AVG(latency_ms) as avg_latency, SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as errors")
            ->groupByRaw("DATE_FORMAT(timestamp, '%H:%i')")
            ->orderByRaw("DATE_FORMAT(timestamp, '%H:%i')")
            ->get()
            ->toArray();

        // Status breakdown
        $this->statusBreakdown = TrafficLog::where('timestamp', '>=', $fiveMinAgo)
            ->selectRaw("status, COUNT(*) as count")
            ->groupBy('status')
            ->pluck('count', 'status')
            ->toArray();

        // Top operations
        $this->topOperations = TrafficLog::where('timestamp', '>=', $fiveMinAgo)
            ->selectRaw("operation, interface_name, COUNT(*) as count, AVG(latency_ms) as avg_latency")
            ->groupBy('operation', 'interface_name')
            ->orderByDesc('count')
            ->limit(10)
            ->get()
            ->toArray();
    }

    public function loadRecentTraffic(): void
    {
        $this->recentTraffic = TrafficLog::with(['sourceService', 'targetService'])
            ->orderByDesc('timestamp')
            ->limit(50)
            ->get()
            ->map(fn ($log) => [
                'id' => $log->id,
                'request_id' => substr($log->request_id, 0, 8),
                'operation' => $log->operation,
                'interface' => $log->interface_name,
                'source' => $log->sourceService?->name ?? $log->source_host ?? '—',
                'target' => $log->targetService?->name ?? $log->target_host ?? '—',
                'status' => $log->status,
                'latency' => $log->latency_ms ? round($log->latency_ms, 1) . 'ms' : '—',
                'direction' => $log->direction,
                'timestamp' => $log->timestamp->format('H:i:s.v'),
            ])
            ->toArray();
    }

    public function togglePause(): void
    {
        $this->isPaused = !$this->isPaused;
    }

    #[\Livewire\Attributes\On('echo:corba-traffic,.traffic.received')]
    public function onTrafficReceived(array $data): void
    {
        if ($this->isPaused) return;

        // Prepend to recent traffic
        array_unshift($this->recentTraffic, [
            'id' => $data['id'],
            'request_id' => substr($data['request_id'], 0, 8),
            'operation' => $data['operation'],
            'interface' => $data['interface_name'],
            'source' => $data['source'] ?? '—',
            'target' => $data['target'] ?? '—',
            'status' => $data['status'],
            'latency' => isset($data['latency_ms']) ? round($data['latency_ms'], 1) . 'ms' : '—',
            'direction' => $data['direction'] ?? 'request',
            'timestamp' => now()->format('H:i:s.v'),
        ]);

        // Keep only last 100
        $this->recentTraffic = array_slice($this->recentTraffic, 0, 100);

        // Update counters
        $this->totalRequests++;
        if ($data['status'] === 'error') {
            $this->errorCount++;
        }
    }

    public function render()
    {
        return view('livewire.dashboard.overview');
    }
}
