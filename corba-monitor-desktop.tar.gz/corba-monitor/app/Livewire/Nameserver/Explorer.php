<?php

namespace App\Livewire\Nameserver;

use App\Models\NameserverEntry;
use App\Services\CorbaNameserverService;
use Livewire\Component;

class Explorer extends Component
{
    public array $entries = [];
    public array $tree = [];
    public bool $isScanning = false;
    public bool $bridgeAvailable = false;
    public string $bridgeUrl = '';
    public ?int $selectedEntryId = null;
    public array $selectedEntryDetails = [];
    public string $searchQuery = '';

    public function mount(): void
    {
        $nameserver = app(CorbaNameserverService::class);
        $this->bridgeAvailable = $nameserver->isBridgeAvailable();
        $this->bridgeUrl = $nameserver->getBridgeUrl();
        $this->loadEntries();
    }

    public function loadEntries(): void
    {
        $query = NameserverEntry::with('corbaService');

        if ($this->searchQuery) {
            $query->where(function ($q) {
                $q->where('binding_name', 'like', "%{$this->searchQuery}%")
                    ->orWhere('context_path', 'like', "%{$this->searchQuery}%")
                    ->orWhere('type_id', 'like', "%{$this->searchQuery}%")
                    ->orWhere('host', 'like', "%{$this->searchQuery}%");
            });
        }

        $this->entries = $query->orderBy('context_path')
            ->orderBy('binding_name')
            ->get()
            ->map(fn ($e) => [
                'id' => $e->id,
                'full_path' => $e->full_path,
                'context_path' => $e->context_path ?? '/',
                'binding_name' => $e->binding_name,
                'binding_kind' => $e->binding_kind,
                'type_id' => $e->type_id,
                'host' => $e->host,
                'port' => $e->port,
                'is_alive' => $e->is_alive,
                'last_checked' => $e->last_checked_at?->diffForHumans() ?? 'Never',
                'service_name' => $e->corbaService?->name,
                'service_status' => $e->corbaService?->status,
            ])
            ->toArray();

        $this->buildTree();
    }

    private function buildTree(): void
    {
        $tree = [];
        foreach ($this->entries as $entry) {
            $path = $entry['context_path'] === '/' ? '' : $entry['context_path'];
            $parts = $path ? explode('/', $path) : [];

            $current = &$tree;
            foreach ($parts as $part) {
                if (!isset($current[$part])) {
                    $current[$part] = ['__children' => [], '__entries' => []];
                }
                $current = &$current[$part]['__children'];
            }
            $current['__entries'][] = $entry;
        }
        $this->tree = $tree;
    }

    public function scanNameserver(): void
    {
        $this->isScanning = true;

        try {
            $nameserver = app(CorbaNameserverService::class);

            if (!$nameserver->isBridgeAvailable()) {
                session()->flash('scan-error', 'Bridge not available at ' . $nameserver->getBridgeUrl() . '. Start the CORBA Agent first.');
                $this->isScanning = false;
                return;
            }

            // Use the fast /tree endpoint
            $entries = $nameserver->scanViaTree();
            $this->bridgeAvailable = true;
            $this->loadEntries();
            session()->flash('scan-success', 'Scan complete: ' . count($entries) . ' objects discovered.');
        } catch (\Exception $e) {
            session()->flash('scan-error', 'Scan failed: ' . $e->getMessage());
        }

        $this->isScanning = false;
    }

    public function selectEntry(int $id): void
    {
        $this->selectedEntryId = $id;
        $entry = NameserverEntry::with('corbaService')->find($id);

        if ($entry) {
            $this->selectedEntryDetails = [
                'id' => $entry->id,
                'full_path' => $entry->full_path,
                'binding_name' => $entry->binding_name,
                'binding_kind' => $entry->binding_kind,
                'context_path' => $entry->context_path,
                'type_id' => $entry->type_id,
                'host' => $entry->host,
                'port' => $entry->port,
                'is_alive' => $entry->is_alive,
                'ior' => $entry->ior,
                'raw_ior_data' => $entry->raw_ior_data,
                'last_checked' => $entry->last_checked_at?->toIso8601String(),
                'service' => $entry->corbaService?->toArray(),
            ];
        }
    }

    public function clearSelection(): void
    {
        $this->selectedEntryId = null;
        $this->selectedEntryDetails = [];
    }

    public function updatedSearchQuery(): void
    {
        $this->loadEntries();
    }

    public function render()
    {
        return view('livewire.nameserver.explorer');
    }
}
