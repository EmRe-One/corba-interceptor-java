<?php

namespace App\Livewire\Services;

use App\Models\CorbaService;
use App\Models\ServiceConnection;
use Livewire\Component;

class Topology extends Component
{
    public array $services = [];
    public array $connections = [];
    public ?int $selectedServiceId = null;
    public array $selectedServiceDetails = [];
    public string $filterType = 'all'; // all, consumer, supplier
    public string $filterStatus = 'all'; // all, online, offline

    public function mount(): void
    {
        $this->loadTopology();
    }

    public function loadTopology(): void
    {
        $query = CorbaService::query();

        if ($this->filterType !== 'all') {
            $query->where('type', $this->filterType);
        }
        if ($this->filterStatus !== 'all') {
            $query->where('status', $this->filterStatus);
        }

        $this->services = $query->get()->map(fn ($s) => [
            'id' => $s->id,
            'name' => $s->name,
            'type' => $s->type,
            'host' => $s->host,
            'port' => $s->port,
            'interface_name' => $s->interface_name,
            'repository_id' => $s->repository_id,
            'nameserver_path' => $s->nameserver_path,
            'status' => $s->status,
            'last_seen' => $s->last_seen_at?->diffForHumans() ?? 'Never',
        ])->toArray();

        $this->connections = ServiceConnection::with(['sourceService', 'targetService'])
            ->get()
            ->map(fn ($c) => [
                'id' => $c->id,
                'source_id' => $c->source_service_id,
                'target_id' => $c->target_service_id,
                'source_name' => $c->sourceService->name,
                'target_name' => $c->targetService->name,
                'method' => $c->method_name,
                'interface' => $c->interface_name,
                'requests' => $c->request_count,
                'errors' => $c->error_count,
                'avg_latency' => round($c->avg_latency_ms, 1),
                'status' => $c->status,
                'last_activity' => $c->last_activity_at?->diffForHumans() ?? 'Never',
            ])->toArray();

        // Notify Alpine/D3 to re-render graph
        $this->dispatch('topologyUpdated', [
            'services' => $this->services,
            'connections' => $this->connections,
        ]);
    }

    public function selectService(int $id): void
    {
        $this->selectedServiceId = $id;

        $service = CorbaService::with(['outgoingConnections.targetService', 'incomingConnections.sourceService'])
            ->find($id);

        if ($service) {
            $this->selectedServiceDetails = [
                'service' => $service->toArray(),
                'outgoing' => $service->outgoingConnections->map(fn ($c) => [
                    'target' => $c->targetService->name,
                    'method' => $c->method_name,
                    'requests' => $c->request_count,
                    'errors' => $c->error_count,
                    'latency' => round($c->avg_latency_ms, 1),
                ])->toArray(),
                'incoming' => $service->incomingConnections->map(fn ($c) => [
                    'source' => $c->sourceService->name,
                    'method' => $c->method_name,
                    'requests' => $c->request_count,
                    'errors' => $c->error_count,
                    'latency' => round($c->avg_latency_ms, 1),
                ])->toArray(),
                'recent_traffic' => $service->trafficAsSender()
                    ->orWhere('target_service_id', $service->id)
                    ->orderByDesc('timestamp')
                    ->limit(20)
                    ->get()
                    ->toArray(),
            ];
        }
    }

    public function clearSelection(): void
    {
        $this->selectedServiceId = null;
        $this->selectedServiceDetails = [];
    }

    public function updatedFilterType(): void
    {
        $this->loadTopology();
    }

    public function updatedFilterStatus(): void
    {
        $this->loadTopology();
    }

    #[\Livewire\Attributes\On('echo:corba-services,.service.discovered')]
    public function onServiceDiscovered(): void
    {
        $this->loadTopology();
    }

    public function render()
    {
        return view('livewire.services.topology');
    }
}
