<?php

namespace App\Livewire\Settings;

use Livewire\Component;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Service Manager — Monitor and control background services from the UI.
 *
 * Shows status of: Meilisearch, Reverb, CORBA Agent, Java
 * Allows start/stop/restart of services.
 */
class ServiceManager extends Component
{
    public array $services = [];
    public array $config = [];
    public string $javaPath = '';
    public string $meilisearchStatus = 'unknown';

    // CORBA Agent settings
    public string $nsHost = 'localhost';
    public int $nsPort = 2809;
    public bool $agentEnabled = false;

    public function mount(): void
    {
        $this->loadConfig();
        $this->refreshStatus();
    }

    public function loadConfig(): void
    {
        $this->nsHost = config('services.corba.nameserver_host', 'localhost');
        $this->nsPort = (int) config('services.corba.nameserver_port', 2809);
        $this->javaPath = trim(shell_exec(PHP_OS_FAMILY === 'Windows' ? 'where java 2>nul' : 'which java 2>/dev/null') ?? '');
    }

    /**
     * Check health of all services.
     */
    public function refreshStatus(): void
    {
        $this->services = [
            'meilisearch' => $this->checkMeilisearch(),
            'reverb' => $this->checkReverb(),
            'corba_agent' => $this->checkCorbaAgent(),
            'nameservice_bridge' => $this->checkBridge(),
        ];

        $this->config = [
            'database' => config('database.default'),
            'cache' => config('cache.default'),
            'php_version' => PHP_VERSION,
            'os' => PHP_OS_FAMILY . ' ' . php_uname('m'),
            'java_available' => !empty($this->javaPath),
            'java_path' => $this->javaPath ?: 'Not found',
            'meilisearch_host' => config('services.meilisearch.host', '?'),
        ];
    }

    /**
     * Restart a specific service via NativePHP ChildProcess.
     */
    public function restartService(string $alias): void
    {
        try {
            if (class_exists(\Native\Desktop\Facades\ChildProcess::class)) {
                $process = \Native\Desktop\Facades\ChildProcess::get($alias);
                if ($process) {
                    $process->restart();
                    session()->flash('success', "Service '{$alias}' restarted.");
                } else {
                    session()->flash('error', "Service '{$alias}' not found.");
                }
            } else {
                session()->flash('error', 'NativePHP not available (running in browser?)');
            }
        } catch (\Exception $e) {
            session()->flash('error', $e->getMessage());
        }

        $this->refreshStatus();
    }

    /**
     * Stop a service.
     */
    public function stopService(string $alias): void
    {
        try {
            if (class_exists(\Native\Desktop\Facades\ChildProcess::class)) {
                $process = \Native\Desktop\Facades\ChildProcess::get($alias);
                $process?->stop();
                session()->flash('success', "Service '{$alias}' stopped.");
            }
        } catch (\Exception $e) {
            session()->flash('error', $e->getMessage());
        }

        $this->refreshStatus();
    }

    /**
     * Run database migrations.
     */
    public function runMigrations(): void
    {
        try {
            \Artisan::call('migrate', ['--force' => true]);
            session()->flash('success', 'Migrations completed: ' . \Artisan::output());
        } catch (\Exception $e) {
            session()->flash('error', 'Migration failed: ' . $e->getMessage());
        }
    }

    /**
     * Generate demo traffic data.
     */
    public function generateDemoData(): void
    {
        try {
            \Artisan::call('corba:demo-traffic', ['--count' => 100]);
            session()->flash('success', 'Generated 100 demo traffic entries.');
        } catch (\Exception $e) {
            session()->flash('error', 'Demo data generation failed: ' . $e->getMessage());
        }
    }

    // ─── Health Checks ──────────────────────────────────────

    private function checkMeilisearch(): array
    {
        try {
            $host = config('services.meilisearch.host', 'http://127.0.0.1:7700');
            $response = Http::timeout(2)->get("{$host}/health");
            $healthy = $response->successful() && ($response->json('status') === 'available');

            return [
                'name' => 'Meilisearch',
                'alias' => 'meilisearch',
                'status' => $healthy ? 'running' : 'error',
                'detail' => $healthy ? 'Healthy' : 'Not responding',
                'icon' => 'magnifying-glass',
            ];
        } catch (\Exception $e) {
            return [
                'name' => 'Meilisearch',
                'alias' => 'meilisearch',
                'status' => 'stopped',
                'detail' => 'Not reachable',
                'icon' => 'magnifying-glass',
            ];
        }
    }

    private function checkReverb(): array
    {
        // Reverb runs on a configured port
        $port = config('reverb.servers.reverb.port', 8080);
        $running = @fsockopen('127.0.0.1', $port, $errno, $errstr, 1) !== false;

        return [
            'name' => 'Laravel Reverb',
            'alias' => 'reverb',
            'status' => $running ? 'running' : 'stopped',
            'detail' => $running ? "Port {$port}" : 'Not running',
            'icon' => 'signal',
        ];
    }

    private function checkCorbaAgent(): array
    {
        // Check if the Java agent process is running
        $jarExists = file_exists(base_path('extras/java/corba-interceptor.jar'));

        return [
            'name' => 'CORBA Agent (Java)',
            'alias' => 'corba-agent',
            'status' => $jarExists ? 'available' : 'not_installed',
            'detail' => $jarExists
                ? "JAR found, NS: {$this->nsHost}:{$this->nsPort}"
                : 'JAR not found in extras/java/',
            'icon' => 'cpu-chip',
        ];
    }

    private function checkBridge(): array
    {
        $bridgePort = config('services.corba.bridge_port', 9090);

        try {
            $host = "http://127.0.0.1:{$bridgePort}";
            $response = Http::timeout(2)->get("{$host}/api/naming/health");
            $healthy = $response->successful();
            $connected = $response->json('connected', false);

            return [
                'name' => 'Nameservice Bridge',
                'alias' => 'corba-agent', // Same process as CORBA Agent
                'status' => $healthy ? ($connected ? 'running' : 'error') : 'error',
                'detail' => $healthy
                    ? ($connected ? "Port {$bridgePort}, NS connected" : "Port {$bridgePort}, NS disconnected")
                    : 'Not responding',
                'icon' => 'arrow-path-rounded-square',
            ];
        } catch (\Exception $e) {
            return [
                'name' => 'Nameservice Bridge',
                'alias' => 'corba-agent',
                'status' => 'stopped',
                'detail' => "Port {$bridgePort} — Not reachable",
                'icon' => 'arrow-path-rounded-square',
            ];
        }
    }

    public function render()
    {
        return view('livewire.settings.service-manager');
    }
}
