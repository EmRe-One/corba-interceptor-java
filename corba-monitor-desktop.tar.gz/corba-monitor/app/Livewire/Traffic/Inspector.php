<?php

namespace App\Livewire\Traffic;

use App\Models\TrafficLog;
use Livewire\Component;

class Inspector extends Component
{
    public ?TrafficLog $log = null;
    public string $activeTab = 'overview';
    public array $relatedLogs = [];
    public bool $rawMode = false;

    public function mount(int $id): void
    {
        $this->log = TrafficLog::with(['sourceService', 'targetService'])->findOrFail($id);
        $this->loadRelated();
    }

    public function setTab(string $tab): void
    {
        $this->activeTab = $tab;
    }

    public function toggleRaw(): void
    {
        $this->rawMode = !$this->rawMode;
    }

    /**
     * Find related traffic (same request_id or same operation within time window)
     */
    private function loadRelated(): void
    {
        $this->relatedLogs = TrafficLog::with(['sourceService', 'targetService'])
            ->where('id', '!=', $this->log->id)
            ->where(function ($q) {
                $q->where('request_id', $this->log->request_id)
                  ->orWhere(function ($q2) {
                      $q2->where('operation', $this->log->operation)
                         ->where('interface_name', $this->log->interface_name)
                         ->whereBetween('timestamp', [
                             $this->log->timestamp->subSeconds(5),
                             $this->log->timestamp->addSeconds(5),
                         ]);
                  });
            })
            ->orderBy('timestamp')
            ->limit(20)
            ->get()
            ->map(fn ($l) => [
                'id' => $l->id,
                'operation' => $l->operation,
                'direction' => $l->direction,
                'status' => $l->status,
                'latency_ms' => $l->latency_ms,
                'source' => $l->sourceService?->name ?? $l->source_host,
                'target' => $l->targetService?->name ?? $l->target_host,
                'interceptor_point' => $l->interceptor_point,
                'timestamp' => $l->timestamp->format('H:i:s.v'),
            ])
            ->toArray();
    }

    public function render()
    {
        return view('livewire.traffic.inspector');
    }
}
