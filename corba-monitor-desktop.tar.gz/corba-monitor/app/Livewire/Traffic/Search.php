<?php

namespace App\Livewire\Traffic;

use App\Models\TrafficLog;
use App\Services\MeilisearchService;
use Livewire\Component;
use Livewire\WithPagination;

class Search extends Component
{
    use WithPagination;

    public string $query = '';
    public string $filterStatus = '';
    public string $filterDirection = '';
    public string $filterInterface = '';
    public string $filterFrom = '';
    public string $filterTo = '';
    public string $filterMinLatency = '';
    public int $perPage = 50;
    public bool $useMeilisearch = true;
    public array $searchResults = [];
    public int $searchTotal = 0;
    public int $currentPage = 1;
    public ?int $selectedLogId = null;
    public array $selectedLogDetails = [];
    public array $availableInterfaces = [];
    public bool $showFilters = false;

    public function mount(): void
    {
        $this->availableInterfaces = TrafficLog::distinct()
            ->whereNotNull('interface_name')
            ->pluck('interface_name')
            ->toArray();

        $this->performSearch();
    }

    public function performSearch(): void
    {
        if ($this->useMeilisearch) {
            $this->searchMeilisearch();
        }
    }

    private function searchMeilisearch(): void
    {
        $meili = app(MeilisearchService::class);

        $filters = array_filter([
            'status' => $this->filterStatus,
            'direction' => $this->filterDirection,
            'interface_name' => $this->filterInterface,
            'from' => $this->filterFrom,
            'to' => $this->filterTo,
            'min_latency' => $this->filterMinLatency,
        ]);

        $results = $meili->searchTraffic($this->query, $filters, $this->currentPage, $this->perPage);

        $this->searchTotal = $results['total'];
        $this->searchResults = $results['hits'];
    }

    public function updatedQuery(): void
    {
        $this->currentPage = 1;
        $this->performSearch();
    }

    public function updatedFilterStatus(): void
    {
        $this->currentPage = 1;
        $this->performSearch();
    }

    public function updatedFilterDirection(): void
    {
        $this->currentPage = 1;
        $this->performSearch();
    }

    public function updatedFilterInterface(): void
    {
        $this->currentPage = 1;
        $this->performSearch();
    }

    public function nextPage(): void
    {
        $this->currentPage++;
        $this->performSearch();
    }

    public function prevPage(): void
    {
        $this->currentPage = max(1, $this->currentPage - 1);
        $this->performSearch();
    }

    public function selectLog(int $id): void
    {
        $this->selectedLogId = $id;
        $log = TrafficLog::with(['sourceService', 'targetService'])->find($id);

        if ($log) {
            $this->selectedLogDetails = [
                'id' => $log->id,
                'request_id' => $log->request_id,
                'operation' => $log->operation,
                'interface_name' => $log->interface_name,
                'repository_id' => $log->repository_id,
                'direction' => $log->direction,
                'status' => $log->status,
                'error_message' => $log->error_message,
                'exception_type' => $log->exception_type,
                'latency_ms' => $log->latency_ms,
                'giop_version' => $log->giop_version,
                'message_type' => $log->message_type,
                'request_size_bytes' => $log->request_size_bytes,
                'response_size_bytes' => $log->response_size_bytes,
                'source' => [
                    'service' => $log->sourceService?->name,
                    'host' => $log->source_host,
                    'port' => $log->source_port,
                ],
                'target' => [
                    'service' => $log->targetService?->name,
                    'host' => $log->target_host,
                    'port' => $log->target_port,
                ],
                'request_data' => $log->request_data,
                'response_data' => $log->response_data,
                'context_data' => $log->context_data,
                'interceptor_point' => $log->interceptor_point,
                'timestamp' => $log->timestamp->toIso8601String(),
            ];
        }
    }

    public function clearSelection(): void
    {
        $this->selectedLogId = null;
        $this->selectedLogDetails = [];
    }

    public function clearFilters(): void
    {
        $this->query = '';
        $this->filterStatus = '';
        $this->filterDirection = '';
        $this->filterInterface = '';
        $this->filterFrom = '';
        $this->filterTo = '';
        $this->filterMinLatency = '';
        $this->currentPage = 1;
        $this->performSearch();
    }

    public function toggleFilters(): void
    {
        $this->showFilters = !$this->showFilters;
    }

    public function render()
    {
        return view('livewire.traffic.search');
    }
}
