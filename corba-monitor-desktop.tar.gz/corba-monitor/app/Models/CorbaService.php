<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CorbaService extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'type',           // consumer, supplier, both
        'ior',            // Interoperable Object Reference
        'host',
        'port',
        'interface_name', // IDL interface name
        'repository_id',  // e.g. IDL:MyModule/MyInterface:1.0
        'nameserver_path', // naming context path
        'status',         // online, offline, degraded
        'last_seen_at',
        'metadata',
    ];

    protected $casts = [
        'metadata' => 'array',
        'last_seen_at' => 'datetime',
    ];

    public function outgoingConnections(): HasMany
    {
        return $this->hasMany(ServiceConnection::class, 'source_service_id');
    }

    public function incomingConnections(): HasMany
    {
        return $this->hasMany(ServiceConnection::class, 'target_service_id');
    }

    public function trafficAsSender(): HasMany
    {
        return $this->hasMany(TrafficLog::class, 'source_service_id');
    }

    public function trafficAsReceiver(): HasMany
    {
        return $this->hasMany(TrafficLog::class, 'target_service_id');
    }

    public function scopeConsumers($query)
    {
        return $query->whereIn('type', ['consumer', 'both']);
    }

    public function scopeSuppliers($query)
    {
        return $query->whereIn('type', ['supplier', 'both']);
    }

    public function scopeOnline($query)
    {
        return $query->where('status', 'online');
    }

    public function getIsOnlineAttribute(): bool
    {
        return $this->status === 'online';
    }
}
