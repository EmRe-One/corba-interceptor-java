<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NameserverEntry extends Model
{
    use HasFactory;

    protected $fillable = [
        'corba_service_id',
        'context_path',      // full naming context path
        'binding_name',
        'binding_kind',      // nobject, ncontext
        'ior',
        'type_id',           // repository ID from IOR
        'host',              // extracted from IOR
        'port',              // extracted from IOR
        'is_alive',
        'last_checked_at',
        'raw_ior_data',
    ];

    protected $casts = [
        'is_alive' => 'boolean',
        'last_checked_at' => 'datetime',
        'raw_ior_data' => 'array',
    ];

    public function corbaService(): BelongsTo
    {
        return $this->belongsTo(CorbaService::class);
    }

    public function getFullPathAttribute(): string
    {
        return $this->context_path
            ? "{$this->context_path}/{$this->binding_name}"
            : $this->binding_name;
    }
}
