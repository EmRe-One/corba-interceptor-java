<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ServiceConnection extends Model
{
    use HasFactory;

    protected $fillable = [
        'source_service_id',
        'target_service_id',
        'interface_name',
        'method_name',
        'request_count',
        'error_count',
        'avg_latency_ms',
        'last_activity_at',
        'status',
    ];

    protected $casts = [
        'last_activity_at' => 'datetime',
        'avg_latency_ms' => 'float',
    ];

    public function sourceService(): BelongsTo
    {
        return $this->belongsTo(CorbaService::class, 'source_service_id');
    }

    public function targetService(): BelongsTo
    {
        return $this->belongsTo(CorbaService::class, 'target_service_id');
    }
}
