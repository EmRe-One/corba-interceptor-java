<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TrafficLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'request_id',
        'source_service_id',
        'target_service_id',
        'direction',          // request, reply
        'operation',          // CORBA operation name
        'interface_name',
        'repository_id',
        'request_data',
        'response_data',
        'status',             // success, error, timeout, exception
        'error_message',
        'exception_type',     // CORBA system exception type
        'latency_ms',
        'giop_version',
        'message_type',       // Request, Reply, LocateRequest, etc.
        'request_size_bytes',
        'response_size_bytes',
        'source_host',
        'source_port',
        'target_host',
        'target_port',
        'interceptor_point',  // send_request, receive_reply, etc.
        'context_data',       // service context / propagation data
        'timestamp',
    ];

    protected $casts = [
        'request_data' => 'array',
        'response_data' => 'array',
        'context_data' => 'array',
        'latency_ms' => 'float',
        'timestamp' => 'datetime',
    ];

    public function sourceService(): BelongsTo
    {
        return $this->belongsTo(CorbaService::class, 'source_service_id');
    }

    public function targetService(): BelongsTo
    {
        return $this->belongsTo(CorbaService::class, 'target_service_id');
    }

    public function scopeErrors($query)
    {
        return $query->where('status', 'error');
    }

    public function scopeRecent($query, int $minutes = 5)
    {
        return $query->where('timestamp', '>=', now()->subMinutes($minutes));
    }
}
