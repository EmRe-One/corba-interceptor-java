<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Log;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        $this->ensureDatabaseExists();
    }

    /**
     * When running with SQLite (NativePHP desktop mode),
     * ensure the database file exists and migrations are run.
     */
    private function ensureDatabaseExists(): void
    {
        if (config('database.default') !== 'sqlite') {
            return;
        }

        $dbPath = config('database.connections.sqlite.database');

        // Resolve relative path
        if ($dbPath && !str_starts_with($dbPath, '/')) {
            $dbPath = database_path($dbPath);
        }

        if (!$dbPath) {
            $dbPath = database_path('database.sqlite');
        }

        // Create the SQLite file if it doesn't exist
        if (!file_exists($dbPath)) {
            $dir = dirname($dbPath);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }

            touch($dbPath);
            Log::info("Created SQLite database at: {$dbPath}");

            // Run migrations on first boot
            try {
                \Artisan::call('migrate', ['--force' => true]);
                Log::info('Auto-migration completed: ' . trim(\Artisan::output()));
            } catch (\Exception $e) {
                Log::error('Auto-migration failed: ' . $e->getMessage());
            }
        }
    }
}
