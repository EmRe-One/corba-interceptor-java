<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /**
     * Event subscribers.
     */
    protected $subscribe = [
        \App\Listeners\ChildProcessEventListener::class,
    ];
}
