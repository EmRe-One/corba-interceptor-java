<?php

namespace App\Providers;

use Native\Desktop\Facades\ChildProcess;
use Native\Desktop\Facades\Window;
use Native\Desktop\Facades\Menu;
use Native\Desktop\Facades\Tray;
use Native\Desktop\Facades\Notification;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Artisan;

/**
 * NativePHP Boot Provider.
 *
 * Orchestrates the entire CORBA Monitor desktop application:
 *
 *   ┌──────────────────────────────────────────────────────┐
 *   │                  Electron Window                      │
 *   │  ┌────────────────────────────────────────────────┐  │
 *   │  │           Laravel (Dashboard UI)                │  │
 *   │  └──────────────┬─────────────────────────────────┘  │
 *   │                  │                                    │
 *   │  ┌──────────┐ ┌─┴──────┐ ┌──────┐ ┌────────────┐   │
 *   │  │Meilisearch│ │ Reverb │ │Queue │ │CORBA Agent  │   │
 *   │  │ (binary)  │ │ (WS)   │ │Worker│ │ (Java JAR)  │   │
 *   │  └──────────┘ └────────┘ └──────┘ └────────────┘   │
 *   │       └────────────┴─────────┴──────────┘            │
 *   │              ChildProcess (auto-managed)              │
 *   │                                                        │
 *   │  ┌────────────────┐                                   │
 *   │  │  System Tray    │ ← Health indicators              │
 *   │  └────────────────┘                                   │
 *   └──────────────────────────────────────────────────────┘
 */
class NativeAppServiceProvider
{
    /**
     * Called once when the native application starts.
     */
    public function boot(): void
    {
        $this->createMainWindow();
        $this->configureMenu();
        $this->configureTray();
        $this->startBackgroundServices();

        if ($this->isFirstRun()) {
            $this->handleFirstRun();
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  Window
    // ═══════════════════════════════════════════════════════════

    private function createMainWindow(): void
    {
        Window::open('main')
            ->title('CORBA Monitor')
            ->width(1440)
            ->height(900)
            ->minWidth(1024)
            ->minHeight(700)
            ->titleBarStyle('hidden')
            ->rememberState()
            ->route('dashboard');
    }

    // ═══════════════════════════════════════════════════════════
    //  Native Menu Bar
    // ═══════════════════════════════════════════════════════════

    private function configureMenu(): void
    {
        Menu::create(
            Menu::make()
                ->appMenu()
                ->submenu('File', Menu::make()
                    ->link('http://localhost', 'Dashboard', 'CmdOrCtrl+D')
                    ->separator()
                    ->link('http://localhost/traffic', 'Traffic Logs', 'CmdOrCtrl+T')
                    ->link('http://localhost/services', 'Topology', 'CmdOrCtrl+S')
                    ->link('http://localhost/nameserver', 'Nameserver', 'CmdOrCtrl+N')
                    ->separator()
                    ->link('http://localhost/settings/services', 'Service Manager', 'CmdOrCtrl+,')
                )
                ->submenu('View', Menu::make()
                    ->toggleFullscreen()
                    ->separator()
                    ->devTools()
                )
                ->submenu('Help', Menu::make()
                    ->link('https://github.com/your-org/corba-monitor', 'Documentation')
                    ->separator()
                    ->link('http://localhost/settings/services', 'System Health')
                )
        );
    }

    // ═══════════════════════════════════════════════════════════
    //  System Tray
    // ═══════════════════════════════════════════════════════════

    private function configureTray(): void
    {
        Tray::create()
            ->label('CORBA Monitor')
            ->tooltip('CORBA Monitor — Running')
            ->menu(function () {
                $msStatus = $this->isMeilisearchHealthy() ? '🟢 Running' : '🔴 Stopped';
                $rbStatus = $this->isPortOpen(config('reverb.servers.reverb.port', 8080))
                    ? '🟢 Running' : '🔴 Stopped';
                $agentStatus = $this->hasJavaAgent()
                    ? ($this->isJavaAvailable() ? '🟡 Available' : '🔴 No Java')
                    : '⚪ Not installed';

                return Menu::make()
                    ->label('CORBA Monitor v' . config('nativephp.version', '1.0.0'))
                    ->separator()
                    ->label("Meilisearch: {$msStatus}")
                    ->label("WebSocket:   {$rbStatus}")
                    ->label("CORBA Agent: {$agentStatus}")
                    ->separator()
                    ->link('http://localhost', 'Open Dashboard')
                    ->link('http://localhost/traffic', 'Traffic Logs')
                    ->link('http://localhost/settings/services', 'Service Manager')
                    ->separator()
                    ->quit();
            });
    }

    // ═══════════════════════════════════════════════════════════
    //  Background Services
    // ═══════════════════════════════════════════════════════════

    private function startBackgroundServices(): void
    {
        $this->startMeilisearch();
        $this->startReverb();
        $this->startQueueWorker();

        if ($this->hasJavaAgent() && $this->isJavaAvailable()) {
            $this->startJavaAgent();
        }

        Log::info('[NativePHP] All background services initiated');
    }

    /**
     * Start Meilisearch search engine binary.
     */
    private function startMeilisearch(): void
    {
        $binary = $this->getMeilisearchBinary();

        if (!$binary || !file_exists($binary)) {
            Log::warning('[NativePHP] Meilisearch binary not found');
            return;
        }

        $dataDir = $this->appDataPath('meilisearch');
        $port = config('services.meilisearch.port', 7700);
        $masterKey = config('services.meilisearch.key', 'corba-monitor-dev-key');

        $cmd = implode(' ', [
            escapeshellarg($binary),
            '--db-path', escapeshellarg($dataDir . '/data.ms'),
            '--dump-dir', escapeshellarg($dataDir . '/dumps'),
            '--http-addr', "127.0.0.1:{$port}",
            '--master-key', escapeshellarg($masterKey),
            '--no-analytics',
            '--env', 'production',
            '--max-indexing-memory', '256Mb',
        ]);

        ChildProcess::start(cmd: $cmd, alias: 'meilisearch', persistent: true);
        Log::info("[NativePHP] Meilisearch starting on :{$port}");
    }

    /**
     * Start Laravel Reverb WebSocket server.
     */
    private function startReverb(): void
    {
        ChildProcess::start(
            cmd: 'php artisan reverb:start --no-interaction',
            alias: 'reverb',
            persistent: true,
        );
        Log::info('[NativePHP] Reverb starting');
    }

    /**
     * Start queue worker (only if queue is not sync).
     */
    private function startQueueWorker(): void
    {
        if (config('queue.default') === 'sync') return;

        ChildProcess::start(
            cmd: 'php artisan queue:work --sleep=3 --tries=3 --max-time=3600 --no-interaction',
            alias: 'queue-worker',
            persistent: true,
        );
        Log::info('[NativePHP] Queue worker starting');
    }

    /**
     * Start the Java CORBA Interceptor Agent (standalone mode).
     */
    private function startJavaAgent(): void
    {
        $jarPath = $this->getJavaAgentPath();
        if (!$jarPath) return;

        $nsHost = config('services.corba.nameserver_host', 'localhost');
        $nsPort = config('services.corba.nameserver_port', 2809);
        $bridgePort = config('services.corba.bridge_port', 9090);
        $apiPort = config('app.port', 8000);
        $apiUrl = "http://127.0.0.1:{$apiPort}/api";

        // Starts: Scanner + Bridge HTTP API + Interceptors
        $cmd = implode(' ', [
            'java',
            '-Dmonitor.api.url=' . escapeshellarg($apiUrl),
            '-Dmonitor.nameserver.host=' . escapeshellarg($nsHost),
            '-Dmonitor.nameserver.port=' . $nsPort,
            '-Dmonitor.bridge.enabled=true',
            '-Dmonitor.bridge.port=' . $bridgePort,
            '-Dmonitor.ssl.trust-all=true',
            '-Dmonitor.scan.interval.seconds=30',
            '-jar', escapeshellarg($jarPath),
        ]);

        ChildProcess::start(cmd: $cmd, alias: 'corba-agent', persistent: true);
        Log::info("[NativePHP] CORBA Agent starting (ns={$nsHost}:{$nsPort}, bridge=:{$bridgePort})");
    }

    // ═══════════════════════════════════════════════════════════
    //  First Run
    // ═══════════════════════════════════════════════════════════

    private function isFirstRun(): bool
    {
        return !file_exists($this->appDataPath('.initialized'));
    }

    private function handleFirstRun(): void
    {
        Log::info('[NativePHP] First run — initializing...');

        // Ensure migrations
        try {
            Artisan::call('migrate', ['--force' => true]);
            Log::info('[NativePHP] Migrations: ' . trim(Artisan::output()));
        } catch (\Exception $e) {
            Log::error('[NativePHP] Migration failed: ' . $e->getMessage());
        }

        // Wait for Meilisearch, then seed demo data
        for ($i = 0; $i < 10; $i++) {
            if ($this->isMeilisearchHealthy()) {
                try {
                    Artisan::call('corba:demo-traffic', ['--count' => 25]);
                    Log::info('[NativePHP] Generated initial demo data');
                } catch (\Exception $e) {
                    Log::warning('[NativePHP] Demo data skip: ' . $e->getMessage());
                }
                break;
            }
            usleep(1_000_000);
        }

        // Mark initialized
        $initPath = $this->appDataPath('.initialized');
        if (!is_dir(dirname($initPath))) {
            mkdir(dirname($initPath), 0755, true);
        }
        file_put_contents($initPath, now()->toIso8601String());

        Notification::title('CORBA Monitor Ready')
            ->body('Dashboard loaded with demo data. Use ⌘, to manage services.')
            ->show();
    }

    // ═══════════════════════════════════════════════════════════
    //  Helpers
    // ═══════════════════════════════════════════════════════════

    private function getMeilisearchBinary(): ?string
    {
        $platform = PHP_OS_FAMILY;
        $arch = php_uname('m');

        $binaryName = match ($platform) {
            'Darwin'  => 'meilisearch-macos-' . ($arch === 'arm64' ? 'arm64' : 'amd64'),
            'Linux'   => 'meilisearch-linux-' . ($arch === 'aarch64' ? 'arm64' : 'amd64'),
            'Windows' => 'meilisearch-windows-amd64.exe',
            default   => null,
        };

        if (!$binaryName) return null;

        $extrasPath = base_path("extras/meilisearch/{$binaryName}");
        if (file_exists($extrasPath)) {
            chmod($extrasPath, 0755);
            return $extrasPath;
        }

        $systemPath = trim(shell_exec(
            $platform === 'Windows' ? 'where meilisearch 2>nul' : 'which meilisearch 2>/dev/null'
        ) ?? '');

        return !empty($systemPath) ? $systemPath : null;
    }

    private function hasJavaAgent(): bool
    {
        $path = $this->getJavaAgentPath();
        return $path && file_exists($path);
    }

    private function getJavaAgentPath(): ?string
    {
        $jarPath = base_path('extras/java/corba-interceptor.jar');
        return file_exists($jarPath) ? $jarPath : null;
    }

    private function isJavaAvailable(): bool
    {
        $path = trim(shell_exec(
            PHP_OS_FAMILY === 'Windows' ? 'where java 2>nul' : 'which java 2>/dev/null'
        ) ?? '');
        return !empty($path);
    }

    private function isMeilisearchHealthy(): bool
    {
        try {
            $host = config('services.meilisearch.host', 'http://127.0.0.1:7700');
            $resp = Http::timeout(2)->get("{$host}/health");
            return $resp->successful() && ($resp->json('status') === 'available');
        } catch (\Exception $e) {
            return false;
        }
    }

    private function isPortOpen(int $port): bool
    {
        $conn = @fsockopen('127.0.0.1', $port, $errno, $errstr, 1);
        if ($conn) { fclose($conn); return true; }
        return false;
    }

    private function appDataPath(string $subdir = ''): string
    {
        $base = match (PHP_OS_FAMILY) {
            'Darwin'  => getenv('HOME') . '/Library/Application Support/CORBA Monitor',
            'Windows' => getenv('APPDATA') . '/CORBA Monitor',
            default   => getenv('HOME') . '/.config/corba-monitor',
        };

        $path = $subdir ? "{$base}/{$subdir}" : $base;

        $dir = str_contains(basename($path), '.') ? dirname($path) : $path;
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        return $path;
    }
}
