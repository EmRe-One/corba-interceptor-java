<?php

namespace App\Services;

use App\Events\ServiceDiscovered;
use App\Models\CorbaService;
use App\Models\NameserverEntry;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Service to scan and introspect CORBA Naming Services.
 *
 * This service uses a companion Java/Python bridge that exposes the CORBA
 * Naming Service operations via a simple REST API. The bridge can be started
 * alongside this application and connects to the actual CORBA Naming Service.
 *
 * Bridge API expected endpoints:
 *   GET  /api/naming/list?context=<path>   - List bindings in a context
 *   GET  /api/naming/resolve?name=<path>   - Resolve a name to IOR
 *   GET  /api/naming/ior-info?ior=<ior>    - Parse an IOR into components
 *   GET  /api/naming/ping?ior=<ior>        - Ping a service via IOR
 */
class CorbaNameserverService
{
    private string $bridgeUrl;

    public function __construct()
    {
        $host = config('services.corba.nameserver_host', 'localhost');
        $port = config('services.corba.bridge_port', 9090);
        $this->bridgeUrl = "http://{$host}:{$port}";
    }

    /**
     * Scan the entire naming service tree recursively
     */
    public function scanNameserver(): array
    {
        $discovered = [];
        $this->scanContext('', $discovered);
        return $discovered;
    }

    /**
     * Recursively scan a naming context
     */
    private function scanContext(string $contextPath, array &$discovered): void
    {
        try {
            $response = Http::timeout(10)->get("{$this->bridgeUrl}/api/naming/list", [
                'context' => $contextPath,
            ]);

            if (!$response->successful()) {
                Log::warning("Nameserver scan failed for context: {$contextPath}");
                return;
            }

            $bindings = $response->json('bindings', []);

            foreach ($bindings as $binding) {
                $fullPath = $contextPath
                    ? "{$contextPath}/{$binding['name']}"
                    : $binding['name'];

                if ($binding['kind'] === 'ncontext') {
                    // Recurse into sub-contexts
                    $this->scanContext($fullPath, $discovered);
                } else {
                    // It's an object binding
                    $entry = $this->processBinding($fullPath, $binding);
                    if ($entry) {
                        $discovered[] = $entry;
                    }
                }
            }
        } catch (\Exception $e) {
            Log::error("Nameserver scan error: " . $e->getMessage());
        }
    }

    /**
     * Process a single binding from the naming service
     */
    private function processBinding(string $fullPath, array $binding): ?NameserverEntry
    {
        try {
            // Resolve to get IOR
            $resolveResponse = Http::timeout(10)->get("{$this->bridgeUrl}/api/naming/resolve", [
                'name' => $fullPath,
            ]);

            if (!$resolveResponse->successful()) {
                return null;
            }

            $ior = $resolveResponse->json('ior');
            $iorInfo = $this->parseIor($ior);

            // Check if service is alive
            $isAlive = $this->pingService($ior);

            // Create or update nameserver entry
            $entry = NameserverEntry::updateOrCreate(
                [
                    'context_path' => dirname($fullPath) !== '.' ? dirname($fullPath) : null,
                    'binding_name' => basename($fullPath),
                ],
                [
                    'binding_kind' => $binding['kind'] ?? 'nobject',
                    'ior' => $ior,
                    'type_id' => $iorInfo['type_id'] ?? null,
                    'host' => $iorInfo['host'] ?? null,
                    'port' => $iorInfo['port'] ?? null,
                    'is_alive' => $isAlive,
                    'last_checked_at' => now(),
                    'raw_ior_data' => $iorInfo,
                ]
            );

            // Create/update associated CORBA service
            $service = $this->syncToCorbaService($entry, $fullPath);
            if ($service) {
                $entry->update(['corba_service_id' => $service->id]);
                broadcast(new ServiceDiscovered($service))->toOthers();
            }

            return $entry;
        } catch (\Exception $e) {
            Log::error("Failed processing binding {$fullPath}: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Parse an IOR using the bridge
     */
    public function parseIor(string $ior): array
    {
        try {
            $response = Http::timeout(5)->get("{$this->bridgeUrl}/api/naming/ior-info", [
                'ior' => $ior,
            ]);

            return $response->successful() ? $response->json() : [];
        } catch (\Exception $e) {
            // Fallback: basic IOR parsing from the hex string
            return $this->basicIorParse($ior);
        }
    }

    /**
     * Basic IOR parsing without the bridge (limited info)
     */
    private function basicIorParse(string $ior): array
    {
        $result = ['raw' => substr($ior, 0, 100) . '...'];

        // IOR format: IOR: followed by hex
        if (str_starts_with($ior, 'IOR:')) {
            $hex = substr($ior, 4);
            // The type_id is embedded early in the IOR structure
            // This is a simplified extraction
            $result['format'] = 'standard';
            $result['length'] = strlen($hex) / 2;
        }

        return $result;
    }

    /**
     * Ping a service to check if it's alive
     */
    public function pingService(string $ior): bool
    {
        try {
            $response = Http::timeout(5)->get("{$this->bridgeUrl}/api/naming/ping", [
                'ior' => $ior,
            ]);

            return $response->successful() && $response->json('alive', false);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Synchronize a nameserver entry to a CorbaService
     */
    private function syncToCorbaService(NameserverEntry $entry, string $fullPath): ?CorbaService
    {
        if (!$entry->host) {
            return null;
        }

        return CorbaService::updateOrCreate(
            [
                'host' => $entry->host,
                'port' => $entry->port,
                'interface_name' => $entry->type_id,
            ],
            [
                'name' => basename($fullPath),
                'type' => 'supplier', // Nameserver entries are typically suppliers
                'ior' => $entry->ior,
                'repository_id' => $entry->type_id,
                'nameserver_path' => $fullPath,
                'status' => $entry->is_alive ? 'online' : 'offline',
                'last_seen_at' => now(),
            ]
        );
    }

    /**
     * Process scan results pushed from the Java agent.
     * This is the push-based alternative to the pull-based scanNameserver().
     */
    public function processAgentScanResults(array $entries): int
    {
        $processed = 0;

        foreach ($entries as $entry) {
            try {
                if ($entry['type'] === 'context') {
                    // Just a naming context (directory), skip
                    continue;
                }

                $fullPath = $entry['path'];
                $contextPath = dirname($fullPath) !== '.' ? dirname($fullPath) : null;
                $bindingName = basename($fullPath);

                // Create/update nameserver entry
                $nsEntry = NameserverEntry::updateOrCreate(
                    [
                        'context_path' => $contextPath,
                        'binding_name' => $bindingName,
                    ],
                    [
                        'binding_kind' => $entry['kind'] ?? 'nobject',
                        'ior' => $entry['ior'] ?? null,
                        'type_id' => $entry['type_id'] ?? null,
                        'host' => $entry['host'] ?? null,
                        'port' => $entry['port'] ?? null,
                        'is_alive' => $entry['is_alive'] ?? false,
                        'last_checked_at' => now(),
                        'raw_ior_data' => array_diff_key($entry, array_flip(['path', 'name', 'kind', 'type'])),
                    ]
                );

                // Sync to CorbaService if we have host info
                $host = $entry['host'] ?? null;
                $port = $entry['port'] ?? null;

                if ($host) {
                    $service = CorbaService::updateOrCreate(
                        [
                            'host' => $host,
                            'port' => $port,
                            'interface_name' => $entry['type_id'] ?? $bindingName,
                        ],
                        [
                            'name' => $entry['name'],
                            'type' => 'supplier',
                            'ior' => $entry['ior'] ?? null,
                            'repository_id' => $entry['type_id'] ?? null,
                            'nameserver_path' => $fullPath,
                            'status' => ($entry['is_alive'] ?? false) ? 'online' : 'offline',
                            'last_seen_at' => now(),
                        ]
                    );

                    $nsEntry->update(['corba_service_id' => $service->id]);

                    broadcast(new ServiceDiscovered($service))->toOthers();
                }

                $processed++;
            } catch (\Exception $e) {
                Log::error("Failed processing agent entry {$entry['path']}: " . $e->getMessage());
            }
        }

        Log::info("Java agent scan: processed {$processed} of " . count($entries) . " entries");

        return $processed;
    }

    /**
     * Check if the nameserver bridge is reachable
     */
    public function isBridgeAvailable(): bool
    {
        try {
            $response = Http::timeout(3)->get("{$this->bridgeUrl}/api/naming/health");
            return $response->successful();
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Check if the bridge is connected to the CORBA Naming Service.
     */
    public function isBridgeConnected(): bool
    {
        try {
            $response = Http::timeout(3)->get("{$this->bridgeUrl}/api/naming/health");
            return $response->successful() && $response->json('connected', false);
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Scan the full naming tree in one request via the bridge's /tree endpoint.
     * Much faster than recursive list/resolve calls.
     */
    public function scanViaTree(): array
    {
        try {
            $response = Http::timeout(30)->get("{$this->bridgeUrl}/api/naming/tree");

            if (!$response->successful()) {
                Log::warning('Bridge tree scan failed: ' . $response->status());
                return [];
            }

            $tree = $response->json('tree', []);
            $discovered = [];

            foreach ($tree as $entry) {
                if (($entry['type'] ?? '') === 'context') {
                    continue; // Skip naming contexts (directories)
                }

                $fullPath = $entry['path'] ?? '';
                $contextPath = dirname($fullPath) !== '.' ? dirname($fullPath) : null;
                $bindingName = basename($fullPath);

                $nsEntry = NameserverEntry::updateOrCreate(
                    [
                        'context_path' => $contextPath,
                        'binding_name' => $bindingName,
                    ],
                    [
                        'binding_kind' => $entry['kind'] ?? 'nobject',
                        'ior' => $entry['ior'] ?? null,
                        'type_id' => $entry['type_id'] ?? null,
                        'host' => $entry['host'] ?? null,
                        'port' => $entry['port'] ?? null,
                        'is_alive' => $entry['is_alive'] ?? false,
                        'last_checked_at' => now(),
                        'raw_ior_data' => $entry,
                    ]
                );

                // Sync to CorbaService
                $service = $this->syncToCorbaService($nsEntry, $fullPath);
                if ($service) {
                    $nsEntry->update(['corba_service_id' => $service->id]);
                    broadcast(new ServiceDiscovered($service))->toOthers();
                }

                $discovered[] = $nsEntry;
            }

            Log::info("Bridge tree scan: {$response->json('count', 0)} entries, " . count($discovered) . " objects synced");
            return $discovered;

        } catch (\Exception $e) {
            Log::error('Bridge tree scan error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get the bridge URL for diagnostics
     */
    public function getBridgeUrl(): string
    {
        return $this->bridgeUrl;
    }
}
