<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Meilisearch\Client;

class MeilisearchService
{
    private Client $client;
    private string $trafficIndex = 'corba_traffic_logs';
    private string $servicesIndex = 'corba_services';

    public function __construct()
    {
        $host = config('services.meilisearch.host', 'http://meilisearch:7700');
        $key = config('services.meilisearch.key', '');

        $this->client = new Client($host, $key ?: null);
    }

    /**
     * Create indexes with proper settings (filterable, sortable, searchable attributes)
     */
    public function setupIndices(): void
    {
        // Traffic logs index
        $this->client->createIndex($this->trafficIndex, ['primaryKey' => 'id']);

        $trafficIdx = $this->client->index($this->trafficIndex);
        $trafficIdx->updateSettings([
            'searchableAttributes' => [
                'operation',
                'interface_name',
                'source_service_name',
                'target_service_name',
                'error_message',
                'request_data',
                'response_data',
                'request_id',
                'repository_id',
            ],
            'filterableAttributes' => [
                'status',
                'direction',
                'interface_name',
                'source_host',
                'target_host',
                'timestamp_unix',
                'latency_ms',
            ],
            'sortableAttributes' => [
                'timestamp_unix',
                'latency_ms',
            ],
            'rankingRules' => [
                'words',
                'typo',
                'proximity',
                'attribute',
                'sort',
                'exactness',
            ],
        ]);

        // Services index
        $this->client->createIndex($this->servicesIndex, ['primaryKey' => 'id']);

        $servicesIdx = $this->client->index($this->servicesIndex);
        $servicesIdx->updateSettings([
            'searchableAttributes' => [
                'name',
                'interface_name',
                'repository_id',
                'host',
                'nameserver_path',
            ],
            'filterableAttributes' => [
                'type',
                'status',
                'interface_name',
                'host',
            ],
            'sortableAttributes' => [
                'name',
            ],
        ]);
    }

    /**
     * Index a traffic log entry
     */
    public function indexTrafficLog(array $data): void
    {
        try {
            // Meilisearch needs a numeric or string-sortable timestamp for filtering
            if (isset($data['timestamp'])) {
                $data['timestamp_unix'] = strtotime($data['timestamp']);
            }

            $this->client->index($this->trafficIndex)->addDocuments([$data]);
        } catch (\Exception $e) {
            Log::error('Meilisearch indexing failed: ' . $e->getMessage());
        }
    }

    /**
     * Index a service entry
     */
    public function indexService(array $data): void
    {
        try {
            $this->client->index($this->servicesIndex)->addDocuments([$data]);
        } catch (\Exception $e) {
            Log::error('Meilisearch service indexing failed: ' . $e->getMessage());
        }
    }

    /**
     * Full-text search across traffic logs
     */
    public function searchTraffic(string $query, array $filters = [], int $page = 1, int $perPage = 50): array
    {
        $filterParts = [];

        // Status filter
        if (!empty($filters['status'])) {
            $filterParts[] = "status = \"{$filters['status']}\"";
        }

        // Direction filter
        if (!empty($filters['direction'])) {
            $filterParts[] = "direction = \"{$filters['direction']}\"";
        }

        // Interface filter
        if (!empty($filters['interface_name'])) {
            $filterParts[] = "interface_name = \"{$filters['interface_name']}\"";
        }

        // Time range filter (converted to unix timestamps)
        if (!empty($filters['from'])) {
            $fromUnix = strtotime($filters['from']);
            if ($fromUnix) {
                $filterParts[] = "timestamp_unix >= {$fromUnix}";
            }
        }
        if (!empty($filters['to'])) {
            $toUnix = strtotime($filters['to']);
            if ($toUnix) {
                $filterParts[] = "timestamp_unix <= {$toUnix}";
            }
        }

        // Min latency filter
        if (!empty($filters['min_latency'])) {
            $minLat = (float) $filters['min_latency'];
            $filterParts[] = "latency_ms >= {$minLat}";
        }

        $searchParams = [
            'limit' => $perPage,
            'offset' => ($page - 1) * $perPage,
            'sort' => ['timestamp_unix:desc'],
            'attributesToHighlight' => ['operation', 'error_message', 'request_data', 'response_data'],
            'highlightPreTag' => '<em>',
            'highlightPostTag' => '</em>',
        ];

        if (!empty($filterParts)) {
            $searchParams['filter'] = implode(' AND ', $filterParts);
        }

        try {
            $results = $this->client->index($this->trafficIndex)->search($query, $searchParams);

            return [
                'total' => $results->getEstimatedTotalHits(),
                'hits' => array_map(function ($hit) {
                    $formatted = $hit['_formatted'] ?? [];
                    $highlight = [];

                    // Build highlight array from _formatted fields
                    foreach (['operation', 'error_message', 'request_data', 'response_data'] as $field) {
                        if (isset($formatted[$field]) && $formatted[$field] !== ($hit[$field] ?? '')) {
                            $highlight[$field] = [$formatted[$field]];
                        }
                    }

                    $id = $hit['id'] ?? null;
                    // Remove Meilisearch metadata from the source
                    $source = $hit;
                    unset($source['_formatted'], $source['_rankingScore']);

                    return [
                        'id' => $id,
                        'source' => $source,
                        'score' => $hit['_rankingScore'] ?? null,
                        'highlight' => $highlight,
                    ];
                }, $results->getHits()),
            ];
        } catch (\Exception $e) {
            Log::error('Meilisearch search failed: ' . $e->getMessage());
            return ['total' => 0, 'hits' => []];
        }
    }

    /**
     * Get aggregated traffic statistics
     *
     * Note: Meilisearch doesn't support complex aggregations.
     * We use MySQL queries for stats (see Dashboard/Overview component).
     * This method provides basic facet-based breakdowns.
     */
    public function getTrafficStats(string $interval = '1m', int $minutes = 30): array
    {
        try {
            $fromUnix = now()->subMinutes($minutes)->timestamp;

            // Use facets for status and operation breakdowns
            $results = $this->client->index($this->trafficIndex)->search('', [
                'filter' => "timestamp_unix >= {$fromUnix}",
                'facets' => ['status', 'interface_name'],
                'limit' => 0,
            ]);

            $facetDistribution = $results->getFacetDistribution();

            return [
                'by_status' => $facetDistribution['status'] ?? [],
                'by_interface' => $facetDistribution['interface_name'] ?? [],
                'total_hits' => $results->getEstimatedTotalHits(),
            ];
        } catch (\Exception $e) {
            Log::error('Meilisearch stats failed: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Check if Meilisearch is available
     */
    public function isHealthy(): bool
    {
        try {
            $health = $this->client->health();
            return ($health['status'] ?? '') === 'available';
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Delete all documents in an index (useful for testing)
     */
    public function flush(string $index = null): void
    {
        try {
            if ($index) {
                $this->client->index($index)->deleteAllDocuments();
            } else {
                $this->client->index($this->trafficIndex)->deleteAllDocuments();
                $this->client->index($this->servicesIndex)->deleteAllDocuments();
            }
        } catch (\Exception $e) {
            Log::error('Meilisearch flush failed: ' . $e->getMessage());
        }
    }
}
