<?php

namespace App\Services;

use App\Events\TrafficReceived;
use App\Models\CorbaService;
use App\Models\ServiceConnection;
use App\Models\TrafficLog;
use App\Services\MeilisearchService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class TrafficIngestionService
{
    public function __construct(
        private MeilisearchService $meilisearch
    ) {}

    /**
     * Ingest a traffic event from a Portable Interceptor
     */
    public function ingest(array $data): TrafficLog
    {
        return DB::transaction(function () use ($data) {
            // Resolve or create source/target services
            $sourceService = $this->resolveService($data, 'source');
            $targetService = $this->resolveService($data, 'target');

            // Create traffic log entry
            $log = TrafficLog::create([
                'request_id' => $data['request_id'] ?? Str::uuid()->toString(),
                'source_service_id' => $sourceService?->id,
                'target_service_id' => $targetService?->id,
                'direction' => $data['direction'] ?? 'request',
                'operation' => $data['operation'] ?? 'unknown',
                'interface_name' => $data['interface_name'] ?? null,
                'repository_id' => $data['repository_id'] ?? null,
                'request_data' => $data['request_data'] ?? null,
                'response_data' => $data['response_data'] ?? null,
                'status' => $data['status'] ?? 'success',
                'error_message' => $data['error_message'] ?? null,
                'exception_type' => $data['exception_type'] ?? null,
                'latency_ms' => $data['latency_ms'] ?? null,
                'giop_version' => $data['giop_version'] ?? null,
                'message_type' => $data['message_type'] ?? null,
                'request_size_bytes' => $data['request_size_bytes'] ?? null,
                'response_size_bytes' => $data['response_size_bytes'] ?? null,
                'source_host' => $data['source_host'] ?? null,
                'source_port' => $data['source_port'] ?? null,
                'target_host' => $data['target_host'] ?? null,
                'target_port' => $data['target_port'] ?? null,
                'interceptor_point' => $data['interceptor_point'] ?? null,
                'context_data' => $data['context_data'] ?? null,
                'timestamp' => $data['timestamp'] ?? now(),
            ]);

            // Update service connection stats
            if ($sourceService && $targetService) {
                $this->updateConnection($sourceService, $targetService, $log);
            }

            // Index in Meilisearch
            $this->meilisearch->indexTrafficLog([
                'id' => $log->id,
                'request_id' => $log->request_id,
                'operation' => $log->operation,
                'interface_name' => $log->interface_name,
                'repository_id' => $log->repository_id,
                'status' => $log->status,
                'direction' => $log->direction,
                'error_message' => $log->error_message,
                'exception_type' => $log->exception_type,
                'source_host' => $log->source_host,
                'target_host' => $log->target_host,
                'source_service_name' => $sourceService?->name,
                'target_service_name' => $targetService?->name,
                'request_data' => is_array($log->request_data) ? json_encode($log->request_data) : $log->request_data,
                'response_data' => is_array($log->response_data) ? json_encode($log->response_data) : $log->response_data,
                'latency_ms' => $log->latency_ms,
                'timestamp' => $log->timestamp->toIso8601String(),
            ]);

            // Broadcast for live dashboard
            broadcast(new TrafficReceived($log))->toOthers();

            return $log;
        });
    }

    /**
     * Ingest a batch of traffic events
     */
    public function ingestBatch(array $events): array
    {
        $results = [];
        foreach ($events as $event) {
            $results[] = $this->ingest($event);
        }
        return $results;
    }

    /**
     * Resolve or auto-create a CORBA service from traffic data
     */
    private function resolveService(array $data, string $prefix): ?CorbaService
    {
        $host = $data["{$prefix}_host"] ?? null;
        $port = $data["{$prefix}_port"] ?? null;
        $name = $data["{$prefix}_service_name"] ?? null;

        if (!$host && !$name) {
            return null;
        }

        $service = CorbaService::where(function ($q) use ($host, $port, $name) {
            if ($host && $port) {
                $q->where('host', $host)->where('port', $port);
            }
            if ($name) {
                $q->orWhere('name', $name);
            }
        })->first();

        if (!$service) {
            $type = $prefix === 'source' ? 'consumer' : 'supplier';
            $service = CorbaService::create([
                'name' => $name ?? "{$host}:{$port}",
                'type' => $type,
                'host' => $host,
                'port' => $port,
                'interface_name' => $data['interface_name'] ?? null,
                'repository_id' => $data['repository_id'] ?? null,
                'status' => 'online',
                'last_seen_at' => now(),
            ]);

            $this->meilisearch->indexService($service->toArray());
        } else {
            $service->update([
                'status' => 'online',
                'last_seen_at' => now(),
            ]);
        }

        return $service;
    }

    /**
     * Update or create a connection between two services
     */
    private function updateConnection(CorbaService $source, CorbaService $target, TrafficLog $log): void
    {
        $connection = ServiceConnection::firstOrCreate(
            [
                'source_service_id' => $source->id,
                'target_service_id' => $target->id,
                'method_name' => $log->operation,
            ],
            [
                'interface_name' => $log->interface_name,
                'status' => 'active',
            ]
        );

        $isError = in_array($log->status, ['error', 'exception']);

        $connection->increment('request_count');
        if ($isError) {
            $connection->increment('error_count');
        }

        // Running average latency
        if ($log->latency_ms) {
            $newAvg = (($connection->avg_latency_ms * ($connection->request_count - 1)) + $log->latency_ms) / $connection->request_count;
            $connection->avg_latency_ms = round($newAvg, 2);
        }

        $connection->last_activity_at = now();
        $connection->status = $isError ? 'error' : 'active';
        $connection->save();
    }
}
