<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Application Name & Version
    |--------------------------------------------------------------------------
    */
    'version' => env('NATIVEPHP_APP_VERSION', '1.0.0'),
    'app_id' => env('NATIVEPHP_APP_ID', 'com.corbamonitor.desktop'),
    'copyright' => 'CORBA Monitor ' . date('Y'),

    /*
    |--------------------------------------------------------------------------
    | Deeplink Scheme
    |--------------------------------------------------------------------------
    */
    'deeplink_scheme' => 'corba-monitor',

    /*
    |--------------------------------------------------------------------------
    | NativeAppServiceProvider
    |--------------------------------------------------------------------------
    */
    'provider' => \App\Providers\NativeAppServiceProvider::class,

    /*
    |--------------------------------------------------------------------------
    | Cleanup Environment
    |--------------------------------------------------------------------------
    | Remove Docker-only config when running natively.
    */
    'cleanup_env_keys' => [
        'DB_HOST',
        'DB_PORT',
        'REDIS_HOST',
        'REDIS_PORT',
    ],

    /*
    |--------------------------------------------------------------------------
    | Updater
    |--------------------------------------------------------------------------
    */
    'updater' => [
        'enabled' => env('NATIVEPHP_UPDATER_ENABLED', false),
        'default' => env('NATIVEPHP_UPDATER_PROVIDER', 's3'),
        'providers' => [
            's3' => [
                'driver' => 's3',
                'key' => env('NATIVEPHP_UPDATER_KEY'),
                'secret' => env('NATIVEPHP_UPDATER_SECRET'),
                'bucket' => env('NATIVEPHP_UPDATER_BUCKET'),
                'region' => env('NATIVEPHP_UPDATER_REGION', 'eu-central-1'),
                'path' => env('NATIVEPHP_UPDATER_PATH', 'releases'),
            ],
        ],
    ],
];
