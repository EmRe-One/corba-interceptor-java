<?php

return [

    'meilisearch' => [
        'host' => env('MEILISEARCH_HOST', 'http://127.0.0.1:7700'),
        'key' => env('MEILISEARCH_KEY', 'corba-monitor-dev-key'),
        'port' => (int) env('MEILISEARCH_PORT', 7700),
    ],

    'corba' => [
        'nameserver_host' => env('CORBA_NAMESERVER_HOST', 'localhost'),
        'nameserver_port' => (int) env('CORBA_NAMESERVER_PORT', 2809),
        'bridge_port' => (int) env('CORBA_BRIDGE_PORT', 9090),
        'protocol' => env('CORBA_NAMESERVER_PROTOCOL', 'iiop'),
        'poll_interval' => (int) env('CORBA_POLL_INTERVAL', 5),
    ],

];
