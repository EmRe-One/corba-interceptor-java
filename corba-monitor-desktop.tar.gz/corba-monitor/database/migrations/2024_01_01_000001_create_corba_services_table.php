<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('corba_services', function (Blueprint $table) {
            $table->id();
            $table->string('name')->index();
            $table->enum('type', ['consumer', 'supplier', 'both'])->default('supplier');
            $table->text('ior')->nullable();
            $table->string('host')->nullable();
            $table->unsignedInteger('port')->nullable();
            $table->string('interface_name')->nullable()->index();
            $table->string('repository_id')->nullable()->index();
            $table->string('nameserver_path')->nullable();
            $table->enum('status', ['online', 'offline', 'degraded'])->default('offline');
            $table->timestamp('last_seen_at')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->unique(['host', 'port', 'interface_name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('corba_services');
    }
};
