<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('service_connections', function (Blueprint $table) {
            $table->id();
            $table->foreignId('source_service_id')->constrained('corba_services')->cascadeOnDelete();
            $table->foreignId('target_service_id')->constrained('corba_services')->cascadeOnDelete();
            $table->string('interface_name')->nullable();
            $table->string('method_name')->nullable();
            $table->unsignedBigInteger('request_count')->default(0);
            $table->unsignedBigInteger('error_count')->default(0);
            $table->float('avg_latency_ms')->default(0);
            $table->timestamp('last_activity_at')->nullable();
            $table->enum('status', ['active', 'inactive', 'error'])->default('active');
            $table->timestamps();

            $table->unique(['source_service_id', 'target_service_id', 'method_name'], 'conn_unique');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('service_connections');
    }
};
