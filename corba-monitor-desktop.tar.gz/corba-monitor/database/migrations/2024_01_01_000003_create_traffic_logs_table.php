<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('traffic_logs', function (Blueprint $table) {
            $table->id();
            $table->uuid('request_id')->index();
            $table->foreignId('source_service_id')->nullable()->constrained('corba_services')->nullOnDelete();
            $table->foreignId('target_service_id')->nullable()->constrained('corba_services')->nullOnDelete();
            $table->enum('direction', ['request', 'reply'])->default('request');
            $table->string('operation')->index();
            $table->string('interface_name')->nullable()->index();
            $table->string('repository_id')->nullable();
            $table->json('request_data')->nullable();
            $table->json('response_data')->nullable();
            $table->enum('status', ['success', 'error', 'timeout', 'exception'])->default('success');
            $table->text('error_message')->nullable();
            $table->string('exception_type')->nullable();
            $table->float('latency_ms')->nullable();
            $table->string('giop_version', 10)->nullable();
            $table->string('message_type', 30)->nullable();
            $table->unsignedInteger('request_size_bytes')->nullable();
            $table->unsignedInteger('response_size_bytes')->nullable();
            $table->string('source_host')->nullable();
            $table->unsignedInteger('source_port')->nullable();
            $table->string('target_host')->nullable();
            $table->unsignedInteger('target_port')->nullable();
            $table->string('interceptor_point')->nullable();
            $table->json('context_data')->nullable();
            $table->timestamp('timestamp')->index();
            $table->timestamps();

            $table->index(['timestamp', 'status']);
            $table->index(['interface_name', 'operation']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('traffic_logs');
    }
};
