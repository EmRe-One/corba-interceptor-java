<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('nameserver_entries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('corba_service_id')->nullable()->constrained('corba_services')->nullOnDelete();
            $table->string('context_path')->nullable()->index();
            $table->string('binding_name')->index();
            $table->enum('binding_kind', ['nobject', 'ncontext'])->default('nobject');
            $table->text('ior')->nullable();
            $table->string('type_id')->nullable();
            $table->string('host')->nullable();
            $table->unsignedInteger('port')->nullable();
            $table->boolean('is_alive')->default(false);
            $table->timestamp('last_checked_at')->nullable();
            $table->json('raw_ior_data')->nullable();
            $table->timestamps();

            $table->unique(['context_path', 'binding_name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('nameserver_entries');
    }
};
