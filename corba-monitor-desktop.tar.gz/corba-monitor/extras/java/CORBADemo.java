import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║  CORBA Demo — NamingService + Supplier + Consumer           ║
 * ║                                                              ║
 * ║  IDL: FleetManagement::VehicleTracker                        ║
 * ║  Protocol: Java Serialization over TCP (simulates GIOP/IIOP) ║
 * ║                                                              ║
 * ║  Usage: java CORBADemo.java                                  ║
 * ╚══════════════════════════════════════════════════════════════╝
 */
public class CORBADemo {

    // ═══════════════════════════════════════════════════════════
    //  IDL Types (normally generated from VehicleTracker.idl)
    // ═══════════════════════════════════════════════════════════

    // FleetManagement::GeoPosition
    record GeoPosition(double latitude, double longitude, float speed_kmh, short heading)
            implements Serializable {
        @Override public String toString() {
            return String.format("lat=%.4f lon=%.4f speed=%.1f heading=%d°",
                latitude, longitude, speed_kmh, heading);
        }
    }

    // FleetManagement::VehicleStatus
    enum VehicleStatus { MOVING, IDLE, PARKED, MAINTENANCE }

    // FleetManagement::VehicleInfo
    record VehicleInfo(String vehicle_id, String driver_name, GeoPosition position,
                       VehicleStatus status, float fuel_level_pct, int odometer_km)
            implements Serializable {
        @Override public String toString() {
            String st = switch(status) {
                case MOVING -> "MOVING "; case IDLE -> "IDLE   ";
                case PARKED -> "PARKED "; case MAINTENANCE -> "MAINT  ";
            };
            return String.format("[%s] %-14s %s  %s  fuel=%.0f%%  odo=%,dkm",
                vehicle_id, driver_name, st, position, fuel_level_pct, odometer_km);
        }
    }

    // FleetManagement::VehicleNotFound exception
    static class VehicleNotFound extends Exception {
        final String vehicle_id;
        VehicleNotFound(String id, String msg) { super(msg); this.vehicle_id = id; }
    }

    // ═══════════════════════════════════════════════════════════
    //  GIOP Messages (Request / Response)
    // ═══════════════════════════════════════════════════════════

    record CORBARequest(String operation, Object[] args) implements Serializable {}

    record CORBAResponse(boolean success, Object result,
                         String errorType, String errorMessage) implements Serializable {
        static CORBAResponse ok(Object r) { return new CORBAResponse(true, r, null, null); }
        static CORBAResponse error(String type, String msg) { return new CORBAResponse(false, null, type, msg); }
    }

    // ═══════════════════════════════════════════════════════════
    //  Naming Service Messages
    // ═══════════════════════════════════════════════════════════

    record NamingRequest(String command, String name, String host, int port) implements Serializable {
        NamingRequest(String cmd, String name) { this(cmd, name, null, 0); }
    }

    record NamingResponse(boolean success, String host, int port,
                          String error, List<String> entries) implements Serializable {
        static NamingResponse ok(String h, int p) { return new NamingResponse(true, h, p, null, null); }
        static NamingResponse list(List<String> e) { return new NamingResponse(true, null, 0, null, e); }
        static NamingResponse error(String e) { return new NamingResponse(false, null, 0, e, null); }
    }

    // ═══════════════════════════════════════════════════════════
    //  1. NAMING SERVICE
    // ═══════════════════════════════════════════════════════════

    static class NamingService implements Runnable {

        final int port;
        final Map<String, String> hostMap = new ConcurrentHashMap<>();
        final Map<String, Integer> portMap = new ConcurrentHashMap<>();
        volatile boolean ready = false;

        NamingService(int port) { this.port = port; }

        @Override
        public void run() {
            try (var server = new ServerSocket(port)) {
                log("NS", "╔══════════════════════════════════════════════╗");
                log("NS", "║   CORBA Naming Service — Port " + port + "            ║");
                log("NS", "╚══════════════════════════════════════════════╝");
                ready = true;

                while (true) {
                    Socket client = server.accept();
                    Thread.startVirtualThread(() -> handleNS(client));
                }
            } catch (Exception e) {
                log("NS", "ERROR: " + e.getMessage());
            }
        }

        void handleNS(Socket client) {
            try (client;
                 var out = new ObjectOutputStream(client.getOutputStream());
                 var in = new ObjectInputStream(client.getInputStream())) {

                var req = (NamingRequest) in.readObject();
                var resp = switch (req.command()) {
                    case "rebind" -> {
                        hostMap.put(req.name(), req.host());
                        portMap.put(req.name(), req.port());
                        log("NS", "  BIND    " + req.name() + " → " + req.host() + ":" + req.port());
                        yield NamingResponse.ok(req.host(), req.port());
                    }
                    case "resolve" -> {
                        String h = hostMap.get(req.name());
                        Integer p = portMap.get(req.name());
                        if (h == null) {
                            log("NS", "  RESOLVE " + req.name() + " → NOT FOUND");
                            yield NamingResponse.error("NotFound: " + req.name());
                        } else {
                            log("NS", "  RESOLVE " + req.name() + " → " + h + ":" + p);
                            yield NamingResponse.ok(h, p);
                        }
                    }
                    case "list" -> {
                        var entries = new ArrayList<String>();
                        hostMap.forEach((n, h) -> entries.add(n + " → " + h + ":" + portMap.get(n)));
                        log("NS", "  LIST    " + entries.size() + " entries");
                        yield NamingResponse.list(entries);
                    }
                    default -> NamingResponse.error("Unknown: " + req.command());
                };

                out.writeObject(resp);
                out.flush();
            } catch (Exception ignored) {}
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  2. SUPPLIER (VehicleTracker Implementation)
    // ═══════════════════════════════════════════════════════════

    static class SupplierService implements Runnable {

        final String nsHost;
        final int nsPort;
        final Map<String, VehicleInfo> vehicles = new ConcurrentHashMap<>();
        volatile boolean ready = false;
        int myPort;

        SupplierService(String nsHost, int nsPort) {
            this.nsHost = nsHost;
            this.nsPort = nsPort;
            seedData();
        }

        @Override
        public void run() {
            try (var server = new ServerSocket(0)) {
                myPort = server.getLocalPort();
                String myHost = InetAddress.getLoopbackAddress().getHostAddress();

                log("SUP", "╔══════════════════════════════════════════════╗");
                log("SUP", "║   VehicleTracker — Supplier                  ║");
                log("SUP", "║   Port: " + myPort + "                                  ║");
                log("SUP", "╚══════════════════════════════════════════════╝");
                log("SUP", "  " + vehicles.size() + " vehicles loaded");

                // Register with Naming Service
                registerWithNS(myHost, myPort);
                ready = true;

                log("SUP", "  Waiting for incoming CORBA requests...");
                log("SUP", "");

                while (true) {
                    Socket client = server.accept();
                    Thread.startVirtualThread(() -> handleCall(client));
                }
            } catch (Exception e) {
                log("SUP", "ERROR: " + e.getMessage());
            }
        }

        void registerWithNS(String myHost, int myPort) throws Exception {
            try (var ns = new Socket(nsHost, nsPort);
                 var out = new ObjectOutputStream(ns.getOutputStream());
                 var in = new ObjectInputStream(ns.getInputStream())) {

                out.writeObject(new NamingRequest("rebind",
                    "FleetManagement/VehicleTracker", myHost, myPort));
                out.flush();

                var resp = (NamingResponse) in.readObject();
                if (resp.success()) {
                    log("SUP", "  ✓ Registered: FleetManagement/VehicleTracker");
                } else {
                    throw new RuntimeException(resp.error());
                }
            }
        }

        void handleCall(Socket client) {
            try (client;
                 var in = new ObjectInputStream(client.getInputStream());
                 var out = new ObjectOutputStream(client.getOutputStream())) {

                var req = (CORBARequest) in.readObject();
                long t0 = System.nanoTime();

                CORBAResponse resp = dispatch(req);

                double ms = (System.nanoTime() - t0) / 1_000_000.0;
                String detail = resp.success()
                    ? summarize(resp.result())
                    : resp.errorType() + ": " + resp.errorMessage();
                log("SUP", String.format("  %-20s → %s  (%.2fms)",
                    req.operation() + "()", detail, ms));

                out.writeObject(resp);
                out.flush();
            } catch (Exception ignored) {}
        }

        CORBAResponse dispatch(CORBARequest req) {
            try {
                return switch (req.operation()) {
                    case "ping" ->
                        CORBAResponse.ok("pong @ " + System.currentTimeMillis());
                    case "getVehicleCount" ->
                        CORBAResponse.ok(vehicles.size());
                    case "listVehicles" ->
                        CORBAResponse.ok(vehicles.values().toArray(new VehicleInfo[0]));
                    case "getVehicle" -> {
                        String id = (String) req.args()[0];
                        var v = vehicles.get(id);
                        if (v == null) throw new VehicleNotFound(id, "'" + id + "' not found");
                        yield CORBAResponse.ok(v);
                    }
                    case "updatePosition" -> {
                        String id = (String) req.args()[0];
                        GeoPosition pos = (GeoPosition) req.args()[1];
                        var old = vehicles.get(id);
                        if (old == null) throw new VehicleNotFound(id, "'" + id + "' not found");
                        vehicles.put(id, new VehicleInfo(id, old.driver_name(), pos,
                            pos.speed_kmh() > 0 ? VehicleStatus.MOVING : VehicleStatus.IDLE,
                            old.fuel_level_pct(), old.odometer_km()));
                        yield CORBAResponse.ok("OK");
                    }
                    default -> CORBAResponse.error("BAD_OPERATION", req.operation());
                };
            } catch (VehicleNotFound e) {
                return CORBAResponse.error("VehicleNotFound", e.getMessage());
            }
        }

        void seedData() {
            v("VH-0001", "Ahmet Yilmaz",  39.9208, 32.8541, 62.5f, (short)90,  VehicleStatus.MOVING, 78.5f, 125430);
            v("VH-0002", "Mehmet Demir",   39.9334, 32.8597,  0.0f, (short)0,   VehicleStatus.PARKED, 45.2f,  89200);
            v("VH-0003", "Ayse Kaya",      39.9120, 32.8390, 45.0f, (short)180, VehicleStatus.MOVING, 92.1f,  67890);
            v("VH-0004", "Fatma Ozturk",   39.9456, 32.8700,  0.0f, (short)0,   VehicleStatus.IDLE,   60.0f, 210340);
            v("VH-0005", "Ali Celik",      39.9050, 32.8200,  0.0f, (short)0,   VehicleStatus.MAINTENANCE, 15.3f, 340500);
        }

        void v(String id, String d, double lat, double lon, float spd, short h, VehicleStatus s, float f, int o) {
            vehicles.put(id, new VehicleInfo(id, d, new GeoPosition(lat, lon, spd, h), s, f, o));
        }

        String summarize(Object r) {
            if (r instanceof VehicleInfo v) return v.vehicle_id() + " " + v.driver_name();
            if (r instanceof VehicleInfo[] a) return a.length + " vehicles";
            return String.valueOf(r);
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  3. CONSUMER (Client)
    // ═══════════════════════════════════════════════════════════

    static class ConsumerClient {

        String supplierHost;
        int supplierPort;

        void start(String nsHost, int nsPort) throws Exception {
            log("CON", "╔══════════════════════════════════════════════╗");
            log("CON", "║   VehicleTracker — Consumer                  ║");
            log("CON", "╚══════════════════════════════════════════════╝");

            // ── Resolve from Naming Service ──
            resolve(nsHost, nsPort);

            log("CON", "");
            log("CON", "  ═══ Calling Supplier Operations ═══════════");
            log("CON", "");

            // ── ping() ──
            call("ping");

            // ── getVehicleCount() ──
            call("getVehicleCount");

            // ── listVehicles() ──
            var listResp = call("listVehicles");

            // ── getVehicle("VH-0001") ──
            call("getVehicle", "VH-0001");

            // ── getVehicle("VH-0003") ──
            call("getVehicle", "VH-0003");

            // ── updatePosition("VH-0002", ...) ──
            call("updatePosition", "VH-0002",
                new GeoPosition(39.94, 32.87, 55.0f, (short)45));

            // ── getVehicle("VH-0002") — verify update ──
            call("getVehicle", "VH-0002");

            // ── getVehicle("VH-9999") — expect VehicleNotFound ──
            call("getVehicle", "VH-9999");

            // ── Rapid-fire test ──
            log("CON", "");
            log("CON", "  ═══ Rapid-Fire Test (30 calls) ════════════");
            rapidFire(30);

            log("CON", "");
            log("CON", "  ════════════════════════════════════════════");
            log("CON", "  All operations completed successfully!");
            log("CON", "  ════════════════════════════════════════════");
        }

        void resolve(String nsHost, int nsPort) throws Exception {
            String name = "FleetManagement/VehicleTracker";
            log("CON", "  Resolving: " + name + " from " + nsHost + ":" + nsPort);

            try (var ns = new Socket(nsHost, nsPort);
                 var out = new ObjectOutputStream(ns.getOutputStream());
                 var in = new ObjectInputStream(ns.getInputStream())) {

                out.writeObject(new NamingRequest("resolve", name));
                out.flush();

                var resp = (NamingResponse) in.readObject();
                if (!resp.success()) throw new RuntimeException(resp.error());

                supplierHost = resp.host();
                supplierPort = resp.port();
                log("CON", "  ✓ Resolved: " + supplierHost + ":" + supplierPort);
            }
        }

        CORBAResponse invoke(String op, Object... args) {
            try (var sock = new Socket(supplierHost, supplierPort);
                 var out = new ObjectOutputStream(sock.getOutputStream());
                 var in = new ObjectInputStream(sock.getInputStream())) {

                out.writeObject(new CORBARequest(op, args));
                out.flush();
                return (CORBAResponse) in.readObject();
            } catch (Exception e) {
                return CORBAResponse.error("COMM_FAILURE", e.getMessage());
            }
        }

        CORBAResponse call(String op, Object... args) {
            // Build args string for display
            String argStr = "";
            if (args.length > 0) {
                var parts = new ArrayList<String>();
                for (var a : args) {
                    if (a instanceof String s) parts.add("\"" + s + "\"");
                    else if (a instanceof GeoPosition g)
                        parts.add(String.format("GeoPosition{%.2f, %.2f, %.1f}", g.latitude(), g.longitude(), g.speed_kmh()));
                    else parts.add(String.valueOf(a));
                }
                argStr = String.join(", ", parts);
            }

            log("CON", "  → " + op + "(" + argStr + ")");

            long t0 = System.nanoTime();
            var resp = invoke(op, args);
            double ms = (System.nanoTime() - t0) / 1_000_000.0;

            if (resp.success()) {
                formatResult(resp.result(), ms);
            } else {
                log("CON", String.format("    ✗ %s: %s  (%.1fms)",
                    resp.errorType(), resp.errorMessage(), ms));
            }
            return resp;
        }

        void formatResult(Object result, double ms) {
            if (result instanceof VehicleInfo v) {
                log("CON", String.format("    ← %s  (%.1fms)", v, ms));
            } else if (result instanceof VehicleInfo[] arr) {
                log("CON", String.format("    ← %d vehicles:  (%.1fms)", arr.length, ms));
                for (var v : arr) {
                    log("CON", "      " + v);
                }
            } else {
                log("CON", String.format("    ← %s  (%.1fms)", result, ms));
            }
        }

        void rapidFire(int count) {
            String[] ids = {"VH-0001", "VH-0002", "VH-0003", "VH-0004", "VH-0005"};
            long t0 = System.nanoTime();
            int ok = 0;

            for (int i = 0; i < count; i++) {
                var r = switch (i % 4) {
                    case 0 -> invoke("ping");
                    case 1 -> invoke("getVehicle", ids[i % ids.length]);
                    case 2 -> invoke("getVehicleCount");
                    case 3 -> invoke("listVehicles");
                    default -> null;
                };
                if (r != null && r.success()) ok++;
            }

            double elapsed = (System.nanoTime() - t0) / 1_000_000.0;
            log("CON", String.format("  %d/%d calls OK in %.0fms (%.0f calls/sec)",
                ok, count, elapsed, count / (elapsed / 1000.0)));
        }
    }

    // ═══════════════════════════════════════════════════════════
    //  MAIN — Start all three components
    // ═══════════════════════════════════════════════════════════

    static final String RESET = "\u001b[0m";
    static final Map<String, String> COLORS = Map.of(
        "NS",  "\u001b[36m",   // Cyan
        "SUP", "\u001b[32m",   // Green
        "CON", "\u001b[33m"    // Yellow
    );

    static synchronized void log(String component, String msg) {
        String color = COLORS.getOrDefault(component, RESET);
        System.out.printf("%s[%-3s]%s %s%n", color, component, RESET, msg);
    }

    public static void main(String[] args) throws Exception {
        int nsPort = 2809;
        String nsHost = "127.0.0.1";

        System.out.println();
        System.out.println("\u001b[1m  CORBA Demo — VehicleTracker\u001b[0m");
        System.out.println("  IDL: FleetManagement::VehicleTracker");
        System.out.println("  Architecture: NamingService + Supplier + Consumer");
        System.out.println();

        // ── 1. Start Naming Service ──
        var ns = new NamingService(nsPort);
        Thread.startVirtualThread(ns);
        while (!ns.ready) Thread.sleep(50);
        System.out.println();

        // ── 2. Start Supplier ──
        var supplier = new SupplierService(nsHost, nsPort);
        Thread.startVirtualThread(supplier);
        while (!supplier.ready) Thread.sleep(50);
        System.out.println();

        // Small delay for clean output
        Thread.sleep(200);

        // ── 3. Run Consumer ──
        var consumer = new ConsumerClient();
        consumer.start(nsHost, nsPort);

        System.out.println();
        System.exit(0);
    }
}
