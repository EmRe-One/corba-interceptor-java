# CORBA Interceptor Agent

Place the Java agent JAR here. NativePHP will start it automatically
if Java is available on the system.

## Expected filename:

    corba-interceptor.jar

## Build from source:

```bash
cd corba-interceptor/
mvn clean package
cp target/corba-interceptor-1.0.0.jar /path/to/corba-monitor/extras/java/corba-interceptor.jar
```

## Requirements:

- Java 11+ must be installed on the user's system
- The agent connects to the CORBA Naming Service configured in .env

## What it does:

- Scans the CORBA Naming Service tree periodically
- Reports discovered services to the Monitor API
- When embedded in CORBA applications, captures all traffic via Portable Interceptors
