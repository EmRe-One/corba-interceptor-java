# Meilisearch Binaries

Place the platform-specific Meilisearch binary here.
NativePHP will bundle it with the desktop app and start it automatically.

## Download

Get the latest binary from: https://github.com/meilisearch/meilisearch/releases

### Expected filenames:

| Platform           | Filename                        |
|--------------------|---------------------------------|
| macOS Apple Silicon | `meilisearch-macos-arm64`      |
| macOS Intel         | `meilisearch-macos-amd64`      |
| Linux x64           | `meilisearch-linux-amd64`      |
| Linux ARM64         | `meilisearch-linux-arm64`      |
| Windows x64         | `meilisearch-windows-amd64.exe`|

### Quick download (macOS Apple Silicon):

```bash
curl -L https://github.com/meilisearch/meilisearch/releases/latest/download/meilisearch-macos-arm64 \
  -o extras/meilisearch/meilisearch-macos-arm64
chmod +x extras/meilisearch/meilisearch-macos-arm64
```

### Quick download (Linux x64):

```bash
curl -L https://github.com/meilisearch/meilisearch/releases/latest/download/meilisearch-linux-amd64 \
  -o extras/meilisearch/meilisearch-linux-amd64
chmod +x extras/meilisearch/meilisearch-linux-amd64
```

The NativeAppServiceProvider will auto-detect the platform and choose the right binary.
