<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? 'CORBA Monitor' }}</title>

    {{-- Fonts --}}
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=jetbrains-mono:400,500,600,700|dm-sans:400,500,600,700&display=swap" rel="stylesheet" />

    {{-- Flux UI Pro --}}
    @fluxAppearance
    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        :root {
            --font-sans: 'DM Sans', system-ui, sans-serif;
            --font-mono: 'JetBrains Mono', ui-monospace, monospace;
        }
        body { font-family: var(--font-sans); }
        .font-mono { font-family: var(--font-mono); }

        /* Custom scrollbar */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
        ::-webkit-scrollbar-thumb:hover { background: #475569; }

        /* Glow effects for status indicators */
        .glow-green { box-shadow: 0 0 8px rgba(34, 197, 94, 0.4); }
        .glow-red { box-shadow: 0 0 8px rgba(239, 68, 68, 0.4); }
        .glow-yellow { box-shadow: 0 0 8px rgba(234, 179, 8, 0.4); }

        /* Subtle grid background */
        .bg-grid {
            background-image:
                linear-gradient(rgba(51, 65, 85, 0.12) 1px, transparent 1px),
                linear-gradient(90deg, rgba(51, 65, 85, 0.12) 1px, transparent 1px);
            background-size: 32px 32px;
        }

        /* Traffic log row animation */
        .traffic-row-enter {
            animation: slideIn 0.3s ease-out;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-8px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Pulse for live indicator */
        .pulse-live {
            animation: pulseLive 2s ease-in-out infinite;
        }
        @keyframes pulseLive {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.4; }
        }
    </style>
</head>
<body class="min-h-screen bg-zinc-950 text-zinc-100 antialiased bg-grid">

    {{-- Top Navigation --}}
    <flux:header container class="border-b border-zinc-800/60 bg-zinc-950/80 backdrop-blur-xl sticky top-0 z-50">
        <flux:sidebar.toggle class="lg:hidden" icon="bars-2" inset="left" />

        <a href="{{ route('dashboard') }}" class="flex items-center gap-3 group">
            <div class="size-8 rounded-lg bg-gradient-to-br from-emerald-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <svg class="size-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.288 15.038a5.25 5.25 0 0 1 7.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.53 18.22l-.53.53-.53-.53a.75.75 0 0 1 1.06 0Z" />
                </svg>
            </div>
            <div>
                <span class="font-bold text-zinc-100 text-base tracking-tight group-hover:text-emerald-400 transition-colors">CORBA Monitor</span>
                <span class="hidden sm:inline text-zinc-500 text-xs ml-2 font-mono">v1.0</span>
            </div>
        </a>

        <flux:navbar class="ml-8 max-lg:hidden">
            <flux:navbar.item icon="chart-bar-square" :href="route('dashboard')" :current="request()->routeIs('dashboard')">
                Dashboard
            </flux:navbar.item>
            <flux:navbar.item icon="server-stack" :href="route('services')" :current="request()->routeIs('services')">
                Services
            </flux:navbar.item>
            <flux:navbar.item icon="signal" :href="route('traffic')" :current="request()->routeIs('traffic')">
                Traffic
            </flux:navbar.item>
            <flux:navbar.item icon="folder-open" :href="route('nameserver')" :current="request()->routeIs('nameserver')">
                Nameserver
            </flux:navbar.item>
        </flux:navbar>

        <flux:spacer />

        {{-- Live indicator --}}
        <div class="flex items-center gap-2 text-xs text-zinc-400 font-mono">
            <span class="size-2 rounded-full bg-emerald-500 pulse-live"></span>
            LIVE
        </div>

        <flux:separator vertical class="mx-3 my-2" />

        <flux:dropdown position="bottom" align="end">
            <flux:button icon="ellipsis-horizontal" variant="ghost" size="sm" />
            <flux:menu>
                <flux:menu.item icon="cog-6-tooth" :href="route('settings.services')">Service Manager</flux:menu.item>
                <flux:menu.item icon="document-text" href="/api/health" target="_blank">API Health</flux:menu.item>
                <flux:menu.separator />
                <flux:menu.item icon="information-circle">About</flux:menu.item>
            </flux:menu>
        </flux:dropdown>
    </flux:header>

    {{-- Mobile Sidebar --}}
    <flux:sidebar stashable sticky class="lg:hidden border-r border-zinc-800/60 bg-zinc-950">
        <flux:sidebar.toggle class="lg:hidden" icon="x-mark" />
        <flux:navlist variant="outline">
            <flux:navlist.item icon="chart-bar-square" :href="route('dashboard')" :current="request()->routeIs('dashboard')">Dashboard</flux:navlist.item>
            <flux:navlist.item icon="server-stack" :href="route('services')" :current="request()->routeIs('services')">Services</flux:navlist.item>
            <flux:navlist.item icon="signal" :href="route('traffic')" :current="request()->routeIs('traffic')">Traffic</flux:navlist.item>
            <flux:navlist.item icon="folder-open" :href="route('nameserver')" :current="request()->routeIs('nameserver')">Nameserver</flux:navlist.item>
            <flux:navlist.item icon="cog-6-tooth" :href="route('settings.services')" :current="request()->routeIs('settings.*')">Service Manager</flux:navlist.item>
        </flux:navlist>
    </flux:sidebar>

    {{-- Main Content --}}
    <flux:main container class="py-6">
        {{ $slot }}
    </flux:main>

    @fluxScripts
    @livewireScripts

    <script>
        // Echo / Reverb connection for real-time updates
        window.addEventListener('DOMContentLoaded', () => {
            if (typeof Echo !== 'undefined') {
                Echo.channel('corba-traffic')
                    .listen('.traffic.received', (e) => {
                        Livewire.dispatch('echo:corba-traffic,.traffic.received', e);
                    });

                Echo.channel('corba-services')
                    .listen('.service.discovered', (e) => {
                        Livewire.dispatch('echo:corba-services,.service.discovered', e);
                    });
            }
        });
    </script>

    @stack('scripts')
</body>
</html>
