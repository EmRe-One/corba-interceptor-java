<div wire:poll.5s="refreshStats" class="space-y-6">

    {{-- Header --}}
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-zinc-100">Dashboard</h1>
            <p class="text-sm text-zinc-500 mt-1">Real-time CORBA traffic monitoring</p>
        </div>
        <div class="flex items-center gap-3">
            <flux:button wire:click="togglePause" variant="ghost" size="sm"
                         :icon="$isPaused ? 'play' : 'pause'">
                {{ $isPaused ? 'Resume' : 'Pause' }}
            </flux:button>
            <flux:button wire:click="refreshStats" icon="arrow-path" variant="ghost" size="sm">
                Refresh
            </flux:button>
        </div>
    </div>

    {{-- Stats Grid --}}
    <div class="grid grid-cols-2 lg:grid-cols-6 gap-4">
        {{-- Services Online --}}
        <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-4">
            <div class="flex items-center gap-2 text-zinc-500 text-xs font-medium uppercase tracking-wider">
                <flux:icon.server-stack class="size-4" />
                Services
            </div>
            <div class="mt-2 flex items-baseline gap-2">
                <span class="text-2xl font-bold text-zinc-100">{{ $onlineServices }}</span>
                <span class="text-sm text-zinc-500">/ {{ $totalServices }}</span>
            </div>
            <div class="mt-1 text-xs text-emerald-400">Online</div>
        </div>

        {{-- Requests (5min) --}}
        <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-4">
            <div class="flex items-center gap-2 text-zinc-500 text-xs font-medium uppercase tracking-wider">
                <flux:icon.signal class="size-4" />
                Requests
            </div>
            <div class="mt-2">
                <span class="text-2xl font-bold text-zinc-100">{{ number_format($totalRequests) }}</span>
            </div>
            <div class="mt-1 text-xs text-zinc-500">Last 5 min</div>
        </div>

        {{-- Errors --}}
        <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-4">
            <div class="flex items-center gap-2 text-zinc-500 text-xs font-medium uppercase tracking-wider">
                <flux:icon.exclamation-triangle class="size-4" />
                Errors
            </div>
            <div class="mt-2">
                <span class="text-2xl font-bold {{ $errorCount > 0 ? 'text-red-400' : 'text-zinc-100' }}">
                    {{ number_format($errorCount) }}
                </span>
            </div>
            <div class="mt-1 text-xs {{ $errorCount > 0 ? 'text-red-400' : 'text-zinc-500' }}">
                @if($totalRequests > 0)
                    {{ round(($errorCount / $totalRequests) * 100, 1) }}% error rate
                @else
                    No traffic
                @endif
            </div>
        </div>

        {{-- Avg Latency --}}
        <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-4">
            <div class="flex items-center gap-2 text-zinc-500 text-xs font-medium uppercase tracking-wider">
                <flux:icon.clock class="size-4" />
                Latency
            </div>
            <div class="mt-2">
                <span class="text-2xl font-bold text-zinc-100">{{ $avgLatency }}</span>
                <span class="text-sm text-zinc-500">ms</span>
            </div>
            <div class="mt-1 text-xs text-zinc-500">Average</div>
        </div>

        {{-- Active Connections --}}
        <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-4">
            <div class="flex items-center gap-2 text-zinc-500 text-xs font-medium uppercase tracking-wider">
                <flux:icon.arrows-right-left class="size-4" />
                Connections
            </div>
            <div class="mt-2">
                <span class="text-2xl font-bold text-zinc-100">{{ $activeConnections }}</span>
            </div>
            <div class="mt-1 text-xs text-cyan-400">Active</div>
        </div>

        {{-- Status Breakdown --}}
        <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-4">
            <div class="flex items-center gap-2 text-zinc-500 text-xs font-medium uppercase tracking-wider">
                <flux:icon.chart-pie class="size-4" />
                Status
            </div>
            <div class="mt-2 flex gap-3 text-xs">
                @foreach($statusBreakdown as $status => $count)
                    <div class="flex items-center gap-1">
                        <span class="size-2 rounded-full {{ match($status) {
                            'success' => 'bg-emerald-500',
                            'error' => 'bg-red-500',
                            'timeout' => 'bg-yellow-500',
                            'exception' => 'bg-orange-500',
                            default => 'bg-zinc-500',
                        } }}"></span>
                        <span class="text-zinc-400">{{ $count }}</span>
                    </div>
                @endforeach
                @if(empty($statusBreakdown))
                    <span class="text-zinc-600">No data</span>
                @endif
            </div>
        </div>
    </div>

    {{-- Main Content Grid --}}
    <div class="grid lg:grid-cols-3 gap-6">

        {{-- Live Traffic Feed (2 cols) --}}
        <div class="lg:col-span-2 rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
            <div class="flex items-center justify-between px-5 py-3 border-b border-zinc-800/60">
                <div class="flex items-center gap-3">
                    <h2 class="font-semibold text-zinc-200">Live Traffic</h2>
                    @unless($isPaused)
                        <span class="flex items-center gap-1.5 text-xs text-emerald-400 font-mono">
                            <span class="size-1.5 rounded-full bg-emerald-500 pulse-live"></span>
                            Streaming
                        </span>
                    @else
                        <flux:badge color="yellow" size="sm">Paused</flux:badge>
                    @endunless
                </div>
                <span class="text-xs text-zinc-500 font-mono">{{ count($recentTraffic) }} entries</span>
            </div>

            <div class="overflow-x-auto max-h-[520px] overflow-y-auto">
                <table class="w-full text-sm">
                    <thead class="sticky top-0 bg-zinc-900/95 backdrop-blur-sm">
                        <tr class="text-zinc-500 text-xs uppercase tracking-wider border-b border-zinc-800/40">
                            <th class="text-left py-2.5 px-4 font-medium">Time</th>
                            <th class="text-left py-2.5 px-4 font-medium">Operation</th>
                            <th class="text-left py-2.5 px-4 font-medium">Source → Target</th>
                            <th class="text-left py-2.5 px-4 font-medium">Status</th>
                            <th class="text-right py-2.5 px-4 font-medium">Latency</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($recentTraffic as $entry)
                            <tr class="border-b border-zinc-800/20 hover:bg-zinc-800/30 transition-colors traffic-row-enter cursor-pointer"
                                onclick="window.location='{{ route('traffic.inspect', '') }}/{{ $entry['id'] }}'">
                                <td class="py-2 px-4 font-mono text-xs text-zinc-500">{{ $entry['timestamp'] }}</td>
                                <td class="py-2 px-4">
                                    <div class="flex items-center gap-2">
                                        <span class="size-1.5 rounded-full {{ $entry['direction'] === 'request' ? 'bg-cyan-500' : 'bg-violet-500' }}"></span>
                                        <span class="font-mono text-xs text-zinc-200">{{ $entry['operation'] }}</span>
                                        @if($entry['interface'])
                                            <span class="text-xs text-zinc-600">{{ $entry['interface'] }}</span>
                                        @endif
                                    </div>
                                </td>
                                <td class="py-2 px-4 text-xs">
                                    <span class="text-zinc-400">{{ $entry['source'] }}</span>
                                    <span class="text-zinc-600 mx-1">→</span>
                                    <span class="text-zinc-400">{{ $entry['target'] }}</span>
                                </td>
                                <td class="py-2 px-4">
                                    <span class="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-medium {{ match($entry['status']) {
                                        'success' => 'bg-emerald-500/10 text-emerald-400',
                                        'error' => 'bg-red-500/10 text-red-400',
                                        'timeout' => 'bg-yellow-500/10 text-yellow-400',
                                        'exception' => 'bg-orange-500/10 text-orange-400',
                                        default => 'bg-zinc-500/10 text-zinc-400',
                                    } }}">
                                        {{ $entry['status'] }}
                                    </span>
                                </td>
                                <td class="py-2 px-4 text-right font-mono text-xs {{ ($entry['latency'] !== '—' && (float)$entry['latency'] > 200) ? 'text-yellow-400' : 'text-zinc-400' }}">
                                    {{ $entry['latency'] }}
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="py-12 text-center text-zinc-600">
                                    <flux:icon.signal class="size-8 mx-auto mb-3 opacity-50" />
                                    <p>No traffic recorded yet</p>
                                    <p class="text-xs mt-1">Traffic will appear here as interceptors report data</p>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        {{-- Right Sidebar --}}
        <div class="space-y-6">

            {{-- Top Operations --}}
            <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
                <div class="px-5 py-3 border-b border-zinc-800/60">
                    <h2 class="font-semibold text-zinc-200">Top Operations</h2>
                </div>
                <div class="p-4 space-y-3">
                    @forelse($topOperations as $op)
                        @php
                            $maxCount = max(array_column($topOperations, 'count'));
                            $percentage = $maxCount > 0 ? ($op['count'] / $maxCount) * 100 : 0;
                        @endphp
                        <div>
                            <div class="flex items-center justify-between mb-1">
                                <span class="font-mono text-xs text-zinc-300">{{ $op['operation'] }}</span>
                                <span class="text-xs text-zinc-500">{{ $op['count'] }}×</span>
                            </div>
                            <div class="h-1.5 rounded-full bg-zinc-800 overflow-hidden">
                                <div class="h-full rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500 transition-all duration-500"
                                     style="width: {{ $percentage }}%"></div>
                            </div>
                            <div class="flex items-center justify-between mt-0.5">
                                <span class="text-xs text-zinc-600">{{ $op['interface_name'] }}</span>
                                <span class="text-xs text-zinc-600">{{ round($op['avg_latency'], 1) }}ms avg</span>
                            </div>
                        </div>
                    @empty
                        <p class="text-sm text-zinc-600 text-center py-4">No operations recorded</p>
                    @endforelse
                </div>
            </div>

            {{-- Quick Links --}}
            <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-4 space-y-2">
                <h3 class="font-semibold text-zinc-200 text-sm mb-3">Quick Actions</h3>
                <a href="{{ route('services') }}" class="flex items-center gap-3 p-2.5 rounded-lg hover:bg-zinc-800/50 transition-colors group">
                    <div class="size-8 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                        <flux:icon.server-stack class="size-4 text-cyan-400" />
                    </div>
                    <div>
                        <div class="text-sm text-zinc-300 group-hover:text-zinc-100">Service Topology</div>
                        <div class="text-xs text-zinc-600">View all connections</div>
                    </div>
                </a>
                <a href="{{ route('traffic') }}" class="flex items-center gap-3 p-2.5 rounded-lg hover:bg-zinc-800/50 transition-colors group">
                    <div class="size-8 rounded-lg bg-violet-500/10 flex items-center justify-center">
                        <flux:icon.magnifying-glass class="size-4 text-violet-400" />
                    </div>
                    <div>
                        <div class="text-sm text-zinc-300 group-hover:text-zinc-100">Search Traffic</div>
                        <div class="text-xs text-zinc-600">Full-text search with Meilisearch</div>
                    </div>
                </a>
                <a href="{{ route('nameserver') }}" class="flex items-center gap-3 p-2.5 rounded-lg hover:bg-zinc-800/50 transition-colors group">
                    <div class="size-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                        <flux:icon.folder-open class="size-4 text-amber-400" />
                    </div>
                    <div>
                        <div class="text-sm text-zinc-300 group-hover:text-zinc-100">Nameserver</div>
                        <div class="text-xs text-zinc-600">Browse naming tree</div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>
