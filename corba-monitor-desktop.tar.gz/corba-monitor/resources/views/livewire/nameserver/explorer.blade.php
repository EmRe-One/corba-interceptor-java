<div class="space-y-6">

    {{-- Header --}}
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-zinc-100">Nameserver</h1>
            <p class="text-sm text-zinc-500 mt-1">Browse CORBA Naming Service entries</p>
        </div>
        <div class="flex items-center gap-3">
            {{-- Bridge Status --}}
            <div class="flex items-center gap-2 text-xs font-mono {{ $bridgeAvailable ? 'text-emerald-400' : 'text-red-400' }}">
                <span class="size-2 rounded-full {{ $bridgeAvailable ? 'bg-emerald-500' : 'bg-red-500' }}"></span>
                Bridge {{ $bridgeAvailable ? 'Connected' : 'Offline' }}
            </div>
            <flux:button wire:click="scanNameserver" icon="arrow-path" size="sm"
                         :disabled="!$bridgeAvailable || $isScanning"
                         wire:loading.attr="disabled">
                {{ $isScanning ? 'Scanning...' : 'Scan Nameserver' }}
            </flux:button>
        </div>
    </div>

    {{-- Flash Messages --}}
    @if(session('scan-success'))
        <div class="rounded-lg bg-emerald-500/10 border border-emerald-500/20 p-3 text-sm text-emerald-400">
            {{ session('scan-success') }}
        </div>
    @endif
    @if(session('scan-error'))
        <div class="rounded-lg bg-red-500/10 border border-red-500/20 p-3 text-sm text-red-400">
            {{ session('scan-error') }}
        </div>
    @endif

    {{-- Bridge Info (if offline) --}}
    @unless($bridgeAvailable)
        <div class="rounded-xl border border-amber-500/20 bg-amber-500/5 p-5">
            <div class="flex items-start gap-3">
                <flux:icon.exclamation-triangle class="size-5 text-amber-400 mt-0.5 shrink-0" />
                <div>
                    <h3 class="font-semibold text-amber-300 text-sm">Nameserver Bridge Not Available</h3>
                    <p class="text-sm text-amber-400/80 mt-1">
                        The CORBA Nameserver bridge at <code class="font-mono bg-amber-500/10 px-1.5 py-0.5 rounded text-xs">{{ $bridgeUrl }}</code> is not reachable.
                    </p>
                    <p class="text-xs text-amber-500/60 mt-2">
                        Start the Java/Python bridge service to enable nameserver discovery.
                        Existing cached entries are still displayed below.
                    </p>
                </div>
            </div>
        </div>
    @endunless

    {{-- Search --}}
    <div class="relative">
        <flux:icon.magnifying-glass class="size-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
        <input wire:model.live.debounce.300ms="searchQuery"
               type="text"
               placeholder="Search entries by name, path, type ID, or host..."
               class="w-full bg-zinc-900/50 border border-zinc-800/60 rounded-xl pl-10 pr-4 py-2.5 text-sm text-zinc-200 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500/50 font-mono" />
    </div>

    <div class="grid lg:grid-cols-3 gap-6">

        {{-- Naming Tree / Entry List --}}
        <div class="lg:col-span-2 rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
            <div class="px-5 py-3 border-b border-zinc-800/60 flex items-center justify-between">
                <h2 class="font-semibold text-zinc-200">Naming Tree</h2>
                <span class="text-xs text-zinc-500 font-mono">{{ count($entries) }} entries</span>
            </div>

            <div class="divide-y divide-zinc-800/40 max-h-[600px] overflow-y-auto">
                @forelse($entries as $entry)
                    <button wire:click="selectEntry({{ $entry['id'] }})"
                            class="w-full text-left px-5 py-3 hover:bg-zinc-800/30 transition-colors {{ $selectedEntryId == $entry['id'] ? 'bg-zinc-800/50 border-l-2 border-emerald-500' : '' }}">
                        <div class="flex items-center gap-3">
                            {{-- Icon based on binding kind --}}
                            @if($entry['binding_kind'] === 'ncontext')
                                <div class="size-8 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0">
                                    <flux:icon.folder class="size-4 text-amber-400" />
                                </div>
                            @else
                                <div class="size-8 rounded-lg bg-cyan-500/10 flex items-center justify-center shrink-0">
                                    <flux:icon.cube class="size-4 text-cyan-400" />
                                </div>
                            @endif

                            <div class="min-w-0 flex-1">
                                <div class="flex items-center gap-2">
                                    <span class="font-mono text-sm text-zinc-200 truncate">{{ $entry['binding_name'] }}</span>
                                    @if($entry['is_alive'])
                                        <span class="size-2 rounded-full bg-emerald-500 glow-green shrink-0"></span>
                                    @else
                                        <span class="size-2 rounded-full bg-red-500 shrink-0"></span>
                                    @endif
                                </div>
                                <div class="flex items-center gap-3 mt-0.5 text-xs text-zinc-600">
                                    <span class="font-mono">{{ $entry['context_path'] }}</span>
                                    @if($entry['host'])
                                        <span class="font-mono">{{ $entry['host'] }}:{{ $entry['port'] }}</span>
                                    @endif
                                    @if($entry['type_id'])
                                        <span class="truncate max-w-48">{{ $entry['type_id'] }}</span>
                                    @endif
                                </div>
                            </div>

                            {{-- Service link --}}
                            @if($entry['service_name'])
                                <span class="text-xs px-2 py-0.5 rounded-full bg-violet-500/10 text-violet-400 shrink-0">
                                    {{ $entry['service_name'] }}
                                </span>
                            @endif
                        </div>
                    </button>
                @empty
                    <div class="py-12 text-center text-zinc-600">
                        <flux:icon.folder-open class="size-8 mx-auto mb-3 opacity-50" />
                        <p class="text-sm">No nameserver entries found</p>
                        <p class="text-xs mt-1">
                            @if($bridgeAvailable)
                                Click "Scan Nameserver" to discover services
                            @else
                                Start the bridge service and scan to discover entries
                            @endif
                        </p>
                    </div>
                @endforelse
            </div>
        </div>

        {{-- Detail Panel --}}
        <div>
            @if($selectedEntryId && !empty($selectedEntryDetails))
                <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden sticky top-20">
                    <div class="px-5 py-3 border-b border-zinc-800/60 flex items-center justify-between">
                        <h2 class="font-semibold text-zinc-200">Entry Details</h2>
                        <flux:button wire:click="clearSelection" icon="x-mark" variant="ghost" size="xs" />
                    </div>
                    <div class="p-4 space-y-4 max-h-[600px] overflow-y-auto">

                        {{-- Basic Info --}}
                        <div class="space-y-2 text-xs">
                            <div>
                                <span class="text-zinc-500 block">Full Path</span>
                                <span class="font-mono text-zinc-200 bg-zinc-800/50 px-2 py-1 rounded block mt-0.5">{{ $selectedEntryDetails['full_path'] }}</span>
                            </div>
                            <div class="grid grid-cols-2 gap-2">
                                <div>
                                    <span class="text-zinc-500">Binding Kind</span>
                                    <div class="mt-0.5 capitalize text-zinc-300">{{ $selectedEntryDetails['binding_kind'] }}</div>
                                </div>
                                <div>
                                    <span class="text-zinc-500">Alive</span>
                                    <div class="mt-0.5">
                                        @if($selectedEntryDetails['is_alive'])
                                            <span class="text-emerald-400">● Online</span>
                                        @else
                                            <span class="text-red-400">● Offline</span>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            @if($selectedEntryDetails['host'])
                                <div>
                                    <span class="text-zinc-500">Endpoint</span>
                                    <div class="font-mono text-zinc-300 mt-0.5">{{ $selectedEntryDetails['host'] }}:{{ $selectedEntryDetails['port'] }}</div>
                                </div>
                            @endif
                            @if($selectedEntryDetails['type_id'])
                                <div>
                                    <span class="text-zinc-500">Type ID / Repository ID</span>
                                    <div class="font-mono text-zinc-300 mt-0.5 break-all bg-zinc-800/50 px-2 py-1 rounded">{{ $selectedEntryDetails['type_id'] }}</div>
                                </div>
                            @endif
                            @if($selectedEntryDetails['last_checked'])
                                <div>
                                    <span class="text-zinc-500">Last Checked</span>
                                    <div class="text-zinc-300 mt-0.5">{{ \Carbon\Carbon::parse($selectedEntryDetails['last_checked'])->diffForHumans() }}</div>
                                </div>
                            @endif
                        </div>

                        {{-- IOR --}}
                        @if($selectedEntryDetails['ior'])
                            <div>
                                <div class="text-zinc-500 text-[10px] uppercase tracking-wider mb-1">Interoperable Object Reference (IOR)</div>
                                <pre class="bg-zinc-800/50 rounded-lg p-3 text-[10px] font-mono text-zinc-400 overflow-x-auto max-h-32 break-all whitespace-pre-wrap">{{ $selectedEntryDetails['ior'] }}</pre>
                            </div>
                        @endif

                        {{-- Raw IOR Data --}}
                        @if($selectedEntryDetails['raw_ior_data'])
                            <div>
                                <div class="text-zinc-500 text-[10px] uppercase tracking-wider mb-1">Parsed IOR Data</div>
                                <pre class="bg-zinc-800/50 rounded-lg p-3 text-xs font-mono text-zinc-300 overflow-x-auto max-h-48">{{ json_encode($selectedEntryDetails['raw_ior_data'], JSON_PRETTY_PRINT) }}</pre>
                            </div>
                        @endif

                        {{-- Linked Service --}}
                        @if(!empty($selectedEntryDetails['service']))
                            <div class="bg-violet-500/5 border border-violet-500/20 rounded-lg p-3">
                                <div class="text-violet-400 text-[10px] uppercase tracking-wider mb-2">Linked Service</div>
                                <div class="flex items-center gap-2">
                                    <span class="size-2 rounded-full {{ $selectedEntryDetails['service']['status'] === 'online' ? 'bg-emerald-500' : 'bg-red-500' }}"></span>
                                    <span class="font-mono text-sm text-zinc-200">{{ $selectedEntryDetails['service']['name'] }}</span>
                                </div>
                                <div class="text-xs text-zinc-500 mt-1">
                                    Type: {{ $selectedEntryDetails['service']['type'] }} · Status: {{ $selectedEntryDetails['service']['status'] }}
                                </div>
                                <a href="{{ route('services') }}" class="text-xs text-violet-400 hover:text-violet-300 mt-2 inline-block">
                                    View in Topology →
                                </a>
                            </div>
                        @endif
                    </div>
                </div>
            @else
                <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-8 text-center">
                    <flux:icon.folder-open class="size-10 mx-auto mb-3 text-zinc-700" />
                    <p class="text-sm text-zinc-500">Select an entry to view details</p>
                    <p class="text-xs text-zinc-600 mt-1">Includes IOR parsing, endpoint info & linked services</p>
                </div>
            @endif
        </div>
    </div>
</div>
