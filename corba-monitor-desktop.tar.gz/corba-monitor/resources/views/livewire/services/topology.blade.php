<div class="space-y-6">

    {{-- Header --}}
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-zinc-100">Services</h1>
            <p class="text-sm text-zinc-500 mt-1">Consumer/Supplier topology & connections</p>
        </div>
        <div class="flex items-center gap-3">
            <flux:select wire:model.live="filterType" size="sm" class="w-36">
                <flux:select.option value="all">All Types</flux:select.option>
                <flux:select.option value="consumer">Consumers</flux:select.option>
                <flux:select.option value="supplier">Suppliers</flux:select.option>
                <flux:select.option value="both">Both</flux:select.option>
            </flux:select>
            <flux:select wire:model.live="filterStatus" size="sm" class="w-36">
                <flux:select.option value="all">All Status</flux:select.option>
                <flux:select.option value="online">Online</flux:select.option>
                <flux:select.option value="offline">Offline</flux:select.option>
            </flux:select>
            <flux:button wire:click="loadTopology" icon="arrow-path" variant="ghost" size="sm">Refresh</flux:button>
        </div>
    </div>

    <div class="grid lg:grid-cols-3 gap-6">

        {{-- Topology Visualization (D3 Force Graph) --}}
        <div class="lg:col-span-2 rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
            <div class="px-5 py-3 border-b border-zinc-800/60 flex items-center justify-between">
                <h2 class="font-semibold text-zinc-200">Topology Map</h2>
                <span class="text-xs text-zinc-500 font-mono">{{ count($services) }} services · {{ count($connections) }} connections</span>
            </div>

            <div class="relative" wire:ignore>
                <div
                    id="topology-graph"
                    class="w-full"
                    style="height: 560px; cursor: grab;"
                    x-data="topologyGraph(@js($services), @js($connections))"
                ></div>

                {{-- Zoom Controls --}}
                <div class="absolute bottom-3 right-3 flex flex-col gap-1">
                    <button onclick="window.__topoZoomIn && window.__topoZoomIn()"
                            class="size-8 flex items-center justify-center rounded-lg bg-zinc-800/80 border border-zinc-700/50 text-zinc-300 hover:bg-zinc-700/80 hover:text-zinc-100 transition-colors backdrop-blur-sm text-sm font-mono">
                        +
                    </button>
                    <button onclick="window.__topoZoomOut && window.__topoZoomOut()"
                            class="size-8 flex items-center justify-center rounded-lg bg-zinc-800/80 border border-zinc-700/50 text-zinc-300 hover:bg-zinc-700/80 hover:text-zinc-100 transition-colors backdrop-blur-sm text-sm font-mono">
                        −
                    </button>
                    <button onclick="window.__topoZoomFit && window.__topoZoomFit()"
                            class="size-8 flex items-center justify-center rounded-lg bg-zinc-800/80 border border-zinc-700/50 text-zinc-300 hover:bg-zinc-700/80 hover:text-zinc-100 transition-colors backdrop-blur-sm"
                            title="Fit to view">
                        <svg class="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" />
                        </svg>
                    </button>
                    <button onclick="window.__topoZoomReset && window.__topoZoomReset()"
                            class="size-8 flex items-center justify-center rounded-lg bg-zinc-800/80 border border-zinc-700/50 text-zinc-300 hover:bg-zinc-700/80 hover:text-zinc-100 transition-colors backdrop-blur-sm"
                            title="Reset zoom">
                        <svg class="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.992 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182" />
                        </svg>
                    </button>
                </div>

                {{-- Zoom level indicator --}}
                <div class="absolute bottom-3 left-3 text-[10px] font-mono text-zinc-600" id="topology-zoom-level">100%</div>
            </div>
        </div>

        {{-- Service Details Panel --}}
        <div class="space-y-4">
            @if($selectedServiceId && !empty($selectedServiceDetails))
                @php $svc = $selectedServiceDetails['service']; @endphp
                <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
                    <div class="px-5 py-3 border-b border-zinc-800/60 flex items-center justify-between">
                        <h2 class="font-semibold text-zinc-200">{{ $svc['name'] }}</h2>
                        <flux:button wire:click="clearSelection" icon="x-mark" variant="ghost" size="xs" />
                    </div>
                    <div class="p-4 space-y-3">
                        <div class="grid grid-cols-2 gap-3 text-xs">
                            <div>
                                <span class="text-zinc-500">Type</span>
                                <div class="mt-0.5 flex items-center gap-1.5">
                                    <span class="size-2 rounded-full {{ match($svc['type']) {
                                        'consumer' => 'bg-cyan-500',
                                        'supplier' => 'bg-emerald-500',
                                        'both' => 'bg-violet-500',
                                        default => 'bg-zinc-500',
                                    } }}"></span>
                                    <span class="text-zinc-200 capitalize">{{ $svc['type'] }}</span>
                                </div>
                            </div>
                            <div>
                                <span class="text-zinc-500">Status</span>
                                <div class="mt-0.5">
                                    <span class="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full {{ match($svc['status']) {
                                        'online' => 'bg-emerald-500/10 text-emerald-400',
                                        'offline' => 'bg-red-500/10 text-red-400',
                                        'degraded' => 'bg-yellow-500/10 text-yellow-400',
                                        default => 'bg-zinc-500/10 text-zinc-400',
                                    } }}">
                                        {{ $svc['status'] }}
                                    </span>
                                </div>
                            </div>
                            <div>
                                <span class="text-zinc-500">Host</span>
                                <div class="mt-0.5 font-mono text-zinc-300">{{ $svc['host'] ?? '—' }}:{{ $svc['port'] ?? '—' }}</div>
                            </div>
                            <div>
                                <span class="text-zinc-500">Interface</span>
                                <div class="mt-0.5 font-mono text-zinc-300 truncate">{{ $svc['interface_name'] ?? '—' }}</div>
                            </div>
                        </div>

                        @if($svc['nameserver_path'])
                            <div class="text-xs">
                                <span class="text-zinc-500">Nameserver Path</span>
                                <div class="mt-0.5 font-mono text-zinc-300 bg-zinc-800/50 rounded px-2 py-1">{{ $svc['nameserver_path'] }}</div>
                            </div>
                        @endif

                        @if($svc['repository_id'])
                            <div class="text-xs">
                                <span class="text-zinc-500">Repository ID</span>
                                <div class="mt-0.5 font-mono text-zinc-300 bg-zinc-800/50 rounded px-2 py-1 break-all">{{ $svc['repository_id'] }}</div>
                            </div>
                        @endif
                    </div>
                </div>

                {{-- Outgoing Connections --}}
                @if(!empty($selectedServiceDetails['outgoing']))
                    <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
                        <div class="px-5 py-2.5 border-b border-zinc-800/60">
                            <h3 class="text-sm font-semibold text-cyan-400">Outgoing → {{ count($selectedServiceDetails['outgoing']) }}</h3>
                        </div>
                        <div class="divide-y divide-zinc-800/40">
                            @foreach($selectedServiceDetails['outgoing'] as $conn)
                                <div class="px-4 py-2.5 text-xs">
                                    <div class="flex items-center justify-between">
                                        <span class="font-mono text-zinc-300">{{ $conn['target'] }}</span>
                                        <span class="text-zinc-500">{{ $conn['requests'] }}×</span>
                                    </div>
                                    <div class="flex items-center justify-between mt-0.5 text-zinc-600">
                                        <span>{{ $conn['method'] }}</span>
                                        <span>{{ $conn['latency'] }}ms · {{ $conn['errors'] }} errors</span>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif

                {{-- Incoming Connections --}}
                @if(!empty($selectedServiceDetails['incoming']))
                    <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
                        <div class="px-5 py-2.5 border-b border-zinc-800/60">
                            <h3 class="text-sm font-semibold text-emerald-400">← Incoming {{ count($selectedServiceDetails['incoming']) }}</h3>
                        </div>
                        <div class="divide-y divide-zinc-800/40">
                            @foreach($selectedServiceDetails['incoming'] as $conn)
                                <div class="px-4 py-2.5 text-xs">
                                    <div class="flex items-center justify-between">
                                        <span class="font-mono text-zinc-300">{{ $conn['source'] }}</span>
                                        <span class="text-zinc-500">{{ $conn['requests'] }}×</span>
                                    </div>
                                    <div class="flex items-center justify-between mt-0.5 text-zinc-600">
                                        <span>{{ $conn['method'] }}</span>
                                        <span>{{ $conn['latency'] }}ms · {{ $conn['errors'] }} errors</span>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif
            @else
                {{-- Service List --}}
                <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
                    <div class="px-5 py-3 border-b border-zinc-800/60">
                        <h2 class="font-semibold text-zinc-200">All Services</h2>
                    </div>
                    <div class="divide-y divide-zinc-800/40 max-h-[600px] overflow-y-auto">
                        @forelse($services as $svc)
                            <button wire:click="selectService({{ $svc['id'] }})"
                                    class="w-full text-left px-4 py-3 hover:bg-zinc-800/30 transition-colors">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center gap-2">
                                        <span class="size-2.5 rounded-full {{ match($svc['status']) {
                                            'online' => 'bg-emerald-500 glow-green',
                                            'offline' => 'bg-red-500',
                                            'degraded' => 'bg-yellow-500',
                                            default => 'bg-zinc-500',
                                        } }}"></span>
                                        <span class="font-mono text-sm text-zinc-200">{{ $svc['name'] }}</span>
                                    </div>
                                    <span class="inline-flex items-center text-xs px-2 py-0.5 rounded-full {{ match($svc['type']) {
                                        'consumer' => 'bg-cyan-500/10 text-cyan-400',
                                        'supplier' => 'bg-emerald-500/10 text-emerald-400',
                                        'both' => 'bg-violet-500/10 text-violet-400',
                                        default => 'bg-zinc-500/10 text-zinc-400',
                                    } }}">
                                        {{ $svc['type'] }}
                                    </span>
                                </div>
                                <div class="mt-1 flex items-center gap-3 text-xs text-zinc-600">
                                    <span class="font-mono">{{ $svc['host'] }}:{{ $svc['port'] }}</span>
                                    <span>{{ $svc['last_seen'] }}</span>
                                </div>
                            </button>
                        @empty
                            <div class="py-8 text-center text-zinc-600">
                                <flux:icon.server-stack class="size-8 mx-auto mb-3 opacity-50" />
                                <p class="text-sm">No services discovered</p>
                                <p class="text-xs mt-1">Services appear as traffic is intercepted</p>
                            </div>
                        @endforelse
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>

{{-- D3.js Topology Visualization --}}
@assets
<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.8.5/d3.min.js"></script>
@endassets

@script
<script>
Alpine.data('topologyGraph', (initialServices, initialConnections) => ({
    services: initialServices,
    connections: initialConnections,
    simulation: null,

    init() {
        const wire = this.$wire;

        // Listen for Livewire dispatched updates
        wire.on('topologyUpdated', (data) => {
            this.services = data[0].services;
            this.connections = data[0].connections;
            this.render();
        });

        this.$nextTick(() => this.render());
    },

    render() {
        const container = this.$el;
        if (!container || typeof d3 === 'undefined') return;

        // Stop previous simulation
        if (this.simulation) this.simulation.stop();

        container.innerHTML = '';
        const width = container.clientWidth || 800;
        const height = 560;

        const svg = d3.select(container)
            .append('svg')
            .attr('width', width)
            .attr('height', height)
            .attr('viewBox', [0, 0, width, height])
            .style('cursor', 'grab');

        // Defs (outside zoom group so markers/filters aren't scaled weirdly)
        const defs = svg.append('defs');

        defs.append('marker')
            .attr('id', 'arrowhead')
            .attr('viewBox', '0 -5 10 10')
            .attr('refX', 30)
            .attr('refY', 0)
            .attr('markerWidth', 6)
            .attr('markerHeight', 6)
            .attr('orient', 'auto')
            .append('path')
            .attr('d', 'M0,-5L10,0L0,5')
            .attr('fill', '#475569');

        const filter = defs.append('filter')
            .attr('id', 'glow')
            .attr('x', '-50%').attr('y', '-50%')
            .attr('width', '200%').attr('height', '200%');
        filter.append('feGaussianBlur')
            .attr('stdDeviation', '3')
            .attr('result', 'blur');
        const feMerge = filter.append('feMerge');
        feMerge.append('feMergeNode').attr('in', 'blur');
        feMerge.append('feMergeNode').attr('in', 'SourceGraphic');

        // ── Zoom group: all visual content goes here ──
        const g = svg.append('g').attr('class', 'zoom-group');

        // ── Zoom behavior ──
        const zoomBehavior = d3.zoom()
            .scaleExtent([0.15, 5])
            .on('zoom', (event) => {
                g.attr('transform', event.transform);
                // Update cursor
                svg.style('cursor', event.sourceEvent ? 'grabbing' : 'grab');
                // Update zoom level indicator
                const pct = Math.round(event.transform.k * 100);
                const el = document.getElementById('topology-zoom-level');
                if (el) el.textContent = pct + '%';
            });

        svg.call(zoomBehavior);

        // Reset cursor when zoom ends
        svg.on('mouseup.cursor', () => svg.style('cursor', 'grab'));

        // ── Expose zoom controls globally ──
        const svgNode = svg;
        const duration = 300;

        window.__topoZoomIn = () => {
            svgNode.transition().duration(duration).call(zoomBehavior.scaleBy, 1.4);
        };
        window.__topoZoomOut = () => {
            svgNode.transition().duration(duration).call(zoomBehavior.scaleBy, 0.7);
        };
        window.__topoZoomReset = () => {
            svgNode.transition().duration(duration).call(
                zoomBehavior.transform,
                d3.zoomIdentity
            );
        };
        window.__topoZoomFit = () => {
            this.fitToView(svgNode, g, zoomBehavior, width, height, duration);
        };

        // Empty state
        if (this.services.length === 0) {
            g.append('text')
                .attr('x', width / 2).attr('y', height / 2 - 10)
                .attr('text-anchor', 'middle')
                .attr('fill', '#52525b')
                .attr('font-size', '14px')
                .text('No services to display.');
            g.append('text')
                .attr('x', width / 2).attr('y', height / 2 + 14)
                .attr('text-anchor', 'middle')
                .attr('fill', '#3f3f46')
                .attr('font-size', '12px')
                .text('Run: php artisan corba:demo-traffic --count=50');
            return;
        }

        const nodes = this.services.map(s => ({...s}));
        const links = this.connections.map(c => ({
            source: c.source_id,
            target: c.target_id,
            ...c
        }));

        const typeColor = {
            consumer: '#06b6d4',
            supplier: '#10b981',
            both: '#8b5cf6',
        };

        // No bounds clamping — zoom/pan handles visibility
        this.simulation = d3.forceSimulation(nodes)
            .force('link', d3.forceLink(links).id(d => d.id).distance(140))
            .force('charge', d3.forceManyBody().strength(-400))
            .force('center', d3.forceCenter(width / 2, height / 2))
            .force('collision', d3.forceCollide().radius(45))
            .force('x', d3.forceX(width / 2).strength(0.03))
            .force('y', d3.forceY(height / 2).strength(0.03));

        // Links — inside zoom group
        const link = g.append('g')
            .attr('class', 'links')
            .selectAll('line')
            .data(links)
            .join('line')
            .attr('stroke', d => d.status === 'error' ? '#ef4444' : '#334155')
            .attr('stroke-width', d => Math.min(Math.max(d.requests / 10, 1.5), 4))
            .attr('stroke-opacity', 0.6)
            .attr('marker-end', 'url(#arrowhead)');

        // Link labels
        const linkLabel = g.append('g')
            .attr('class', 'link-labels')
            .selectAll('text')
            .data(links)
            .join('text')
            .attr('text-anchor', 'middle')
            .attr('fill', '#52525b')
            .attr('font-size', '8px')
            .attr('font-family', 'JetBrains Mono, monospace')
            .text(d => d.method);

        // Nodes — drag must coexist with zoom
        const sim = this.simulation;
        const node = g.append('g')
            .attr('class', 'nodes')
            .selectAll('g')
            .data(nodes)
            .join('g')
            .style('cursor', 'pointer')
            .call(d3.drag()
                .on('start', (event, d) => {
                    if (!event.active) sim.alphaTarget(0.3).restart();
                    d.fx = d.x; d.fy = d.y;
                })
                .on('drag', (event, d) => {
                    d.fx = event.x; d.fy = event.y;
                })
                .on('end', (event, d) => {
                    if (!event.active) sim.alphaTarget(0);
                    d.fx = null; d.fy = null;
                }));

        // Node: outer ring
        node.append('circle')
            .attr('r', 20)
            .attr('fill', d => typeColor[d.type] || '#71717a')
            .attr('fill-opacity', d => d.status === 'online' ? 0.15 : 0.05)
            .attr('stroke', d => typeColor[d.type] || '#71717a')
            .attr('stroke-width', 2)
            .attr('stroke-opacity', d => d.status === 'online' ? 0.8 : 0.25)
            .attr('filter', d => d.status === 'online' ? 'url(#glow)' : null);

        // Node: inner dot
        node.append('circle')
            .attr('r', 6)
            .attr('fill', d => typeColor[d.type] || '#71717a')
            .attr('fill-opacity', d => d.status === 'online' ? 0.9 : 0.3);

        // Status indicator
        node.append('circle')
            .attr('r', 4)
            .attr('cx', 15).attr('cy', -15)
            .attr('fill', d => d.status === 'online' ? '#10b981' : '#ef4444')
            .attr('stroke', '#09090b')
            .attr('stroke-width', 1.5);

        // Name label
        node.append('text')
            .text(d => d.name.length > 18 ? d.name.substring(0, 16) + '…' : d.name)
            .attr('text-anchor', 'middle')
            .attr('dy', 36)
            .attr('fill', '#a1a1aa')
            .attr('font-size', '10px')
            .attr('font-family', 'JetBrains Mono, monospace');

        // Type label
        node.append('text')
            .text(d => d.type)
            .attr('text-anchor', 'middle')
            .attr('dy', 48)
            .attr('fill', '#52525b')
            .attr('font-size', '8px')
            .attr('font-family', 'DM Sans, sans-serif');

        // Click → Livewire
        const wire = this.$wire;
        node.on('click', (event, d) => {
            event.stopPropagation();
            wire.call('selectService', d.id);
        });

        // Hover
        node.on('mouseenter', function() {
            d3.select(this).select('circle')
                .transition().duration(200)
                .attr('r', 24).attr('stroke-opacity', 1);
        }).on('mouseleave', function(event, d) {
            d3.select(this).select('circle')
                .transition().duration(200)
                .attr('r', 20)
                .attr('stroke-opacity', d.status === 'online' ? 0.8 : 0.25);
        });

        // Tick — no bounds clamping, free movement
        this.simulation.on('tick', () => {
            link
                .attr('x1', d => d.source.x).attr('y1', d => d.source.y)
                .attr('x2', d => d.target.x).attr('y2', d => d.target.y);

            linkLabel
                .attr('x', d => (d.source.x + d.target.x) / 2)
                .attr('y', d => (d.source.y + d.target.y) / 2 - 5);

            node.attr('transform', d => `translate(${d.x},${d.y})`);
        });

        // Auto fit-to-view once simulation settles
        this.simulation.on('end', () => {
            this.fitToView(svgNode, g, zoomBehavior, width, height, 500);
        });
    },

    /**
     * Fit all nodes into the visible viewport with padding
     */
    fitToView(svg, g, zoomBehavior, width, height, duration) {
        const bounds = g.node().getBBox();
        if (bounds.width === 0 || bounds.height === 0) return;

        const padding = 60;
        const fullWidth = bounds.width + padding * 2;
        const fullHeight = bounds.height + padding * 2;
        const scale = Math.min(
            width / fullWidth,
            height / fullHeight,
            2 // don't zoom in beyond 200%
        );
        const tx = (width - bounds.width * scale) / 2 - bounds.x * scale;
        const ty = (height - bounds.height * scale) / 2 - bounds.y * scale;

        svg.transition().duration(duration).call(
            zoomBehavior.transform,
            d3.zoomIdentity.translate(tx, ty).scale(scale)
        );
    },

    destroy() {
        if (this.simulation) this.simulation.stop();
    }
}));
</script>
@endscript
