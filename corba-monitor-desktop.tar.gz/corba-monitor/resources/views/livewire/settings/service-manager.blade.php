<div class="space-y-6" wire:poll.10s="refreshStatus">

    {{-- Header --}}
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-zinc-100">Service Manager</h1>
            <p class="text-sm text-zinc-500 mt-1">Background services & system health</p>
        </div>
        <div class="flex gap-2">
            <flux:button wire:click="refreshStatus" icon="arrow-path" variant="ghost" size="sm">
                Refresh
            </flux:button>
        </div>
    </div>

    {{-- Flash Messages --}}
    @if(session('success'))
        <div class="rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-4 py-3 text-sm text-emerald-400">
            {{ session('success') }}
        </div>
    @endif
    @if(session('error'))
        <div class="rounded-lg border border-red-500/20 bg-red-500/5 px-4 py-3 text-sm text-red-400">
            {{ session('error') }}
        </div>
    @endif

    {{-- Services Grid --}}
    <div class="grid md:grid-cols-2 xl:grid-cols-4 gap-4">
        @foreach($services as $key => $service)
            <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
                <div class="px-5 py-4">
                    <div class="flex items-center justify-between mb-3">
                        <div class="flex items-center gap-3">
                            <div class="flex items-center justify-center size-10 rounded-lg
                                {{ match($service['status']) {
                                    'running' => 'bg-emerald-500/10',
                                    'stopped', 'error' => 'bg-red-500/10',
                                    'available' => 'bg-yellow-500/10',
                                    default => 'bg-zinc-800',
                                } }}">
                                <flux:icon :name="$service['icon']" class="size-5 {{ match($service['status']) {
                                    'running' => 'text-emerald-400',
                                    'stopped', 'error' => 'text-red-400',
                                    'available' => 'text-yellow-400',
                                    default => 'text-zinc-500',
                                } }}" />
                            </div>
                            <div>
                                <h3 class="font-semibold text-zinc-200 text-sm">{{ $service['name'] }}</h3>
                                <p class="text-xs text-zinc-500">{{ $service['detail'] }}</p>
                            </div>
                        </div>

                        {{-- Status Badge --}}
                        <span class="inline-flex text-[10px] uppercase tracking-wider font-semibold px-2 py-1 rounded-full
                            {{ match($service['status']) {
                                'running' => 'bg-emerald-500/10 text-emerald-400',
                                'stopped' => 'bg-red-500/10 text-red-400',
                                'error' => 'bg-red-500/10 text-red-400',
                                'available' => 'bg-yellow-500/10 text-yellow-400',
                                'not_installed' => 'bg-zinc-800 text-zinc-500',
                                default => 'bg-zinc-800 text-zinc-500',
                            } }}">
                            {{ $service['status'] }}
                        </span>
                    </div>

                    {{-- Actions --}}
                    @if($service['status'] !== 'not_installed')
                        <div class="flex gap-2 pt-3 border-t border-zinc-800/60">
                            <flux:button wire:click="restartService('{{ $service['alias'] }}')"
                                         size="xs" variant="ghost" icon="arrow-path" class="flex-1">
                                Restart
                            </flux:button>
                            @if($service['status'] === 'running')
                                <flux:button wire:click="stopService('{{ $service['alias'] }}')"
                                             size="xs" variant="ghost" icon="stop" class="flex-1">
                                    Stop
                                </flux:button>
                            @endif
                        </div>
                    @endif
                </div>
            </div>
        @endforeach
    </div>

    {{-- System Info --}}
    <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
        <div class="px-5 py-3 border-b border-zinc-800/60">
            <h2 class="font-semibold text-zinc-200">System Configuration</h2>
        </div>
        <div class="p-5">
            <div class="grid md:grid-cols-2 gap-x-8 gap-y-2">
                @foreach($config as $key => $value)
                    <div class="flex items-center justify-between py-1.5">
                        <span class="text-sm text-zinc-500">{{ str_replace('_', ' ', ucfirst($key)) }}</span>
                        <span class="text-sm font-mono text-zinc-300">
                            @if(is_bool($value))
                                <span class="{{ $value ? 'text-emerald-400' : 'text-red-400' }}">
                                    {{ $value ? '✓ Yes' : '✗ No' }}
                                </span>
                            @else
                                {{ $value }}
                            @endif
                        </span>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    {{-- Quick Actions --}}
    <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
        <div class="px-5 py-3 border-b border-zinc-800/60">
            <h2 class="font-semibold text-zinc-200">Quick Actions</h2>
        </div>
        <div class="p-5 flex flex-wrap gap-3">
            <flux:button wire:click="runMigrations" icon="circle-stack" variant="ghost" size="sm">
                Run Migrations
            </flux:button>
            <flux:button wire:click="generateDemoData" icon="play" variant="ghost" size="sm">
                Generate Demo Data (100 entries)
            </flux:button>
        </div>
    </div>
</div>
