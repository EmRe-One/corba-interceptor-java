<div class="space-y-6">

    {{-- Breadcrumb & Header --}}
    <div class="flex items-center justify-between">
        <div>
            <div class="flex items-center gap-2 text-xs text-zinc-500 mb-2">
                <a href="{{ route('traffic') }}" class="hover:text-zinc-300 transition-colors">Traffic</a>
                <span>›</span>
                <span class="text-zinc-400">{{ $log->operation }}</span>
            </div>
            <div class="flex items-center gap-3">
                <h1 class="text-2xl font-bold tracking-tight text-zinc-100 font-mono">{{ $log->operation }}</h1>
                <span class="inline-flex text-xs px-2.5 py-1 rounded-full {{ match($log->status) {
                    'success' => 'bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/20',
                    'error' => 'bg-red-500/10 text-red-400 ring-1 ring-red-500/20',
                    'timeout' => 'bg-yellow-500/10 text-yellow-400 ring-1 ring-yellow-500/20',
                    'exception' => 'bg-orange-500/10 text-orange-400 ring-1 ring-orange-500/20',
                    default => 'bg-zinc-500/10 text-zinc-400',
                } }}">
                    {{ $log->status }}
                </span>
            </div>
            <p class="text-sm text-zinc-500 mt-1 font-mono">{{ $log->interface_name }} · {{ $log->repository_id }}</p>
        </div>
        <div class="flex items-center gap-2">
            <flux:button wire:click="toggleRaw" variant="ghost" size="sm" icon="code-bracket">
                {{ $rawMode ? 'Tree View' : 'Raw JSON' }}
            </flux:button>
            <a href="{{ route('traffic') }}">
                <flux:button variant="ghost" size="sm" icon="arrow-left">Back</flux:button>
            </a>
        </div>
    </div>

    {{-- Quick Stats Bar --}}
    <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        <div class="rounded-lg border border-zinc-800/60 bg-zinc-900/50 px-3 py-2">
            <div class="text-[10px] uppercase tracking-wider text-zinc-500">Direction</div>
            <div class="text-sm font-mono text-zinc-200 mt-0.5 capitalize">{{ $log->direction }}</div>
        </div>
        <div class="rounded-lg border border-zinc-800/60 bg-zinc-900/50 px-3 py-2">
            <div class="text-[10px] uppercase tracking-wider text-zinc-500">Latency</div>
            <div class="text-sm font-mono mt-0.5 {{ ($log->latency_ms ?? 0) > 200 ? 'text-yellow-400' : 'text-zinc-200' }}">
                {{ $log->latency_ms ? round($log->latency_ms, 2) . ' ms' : '—' }}
            </div>
        </div>
        <div class="rounded-lg border border-zinc-800/60 bg-zinc-900/50 px-3 py-2">
            <div class="text-[10px] uppercase tracking-wider text-zinc-500">GIOP</div>
            <div class="text-sm font-mono text-zinc-200 mt-0.5">{{ $log->giop_version ?? '—' }}</div>
        </div>
        <div class="rounded-lg border border-zinc-800/60 bg-zinc-900/50 px-3 py-2">
            <div class="text-[10px] uppercase tracking-wider text-zinc-500">Interceptor</div>
            <div class="text-sm font-mono text-zinc-200 mt-0.5">{{ $log->interceptor_point ?? '—' }}</div>
        </div>
        <div class="rounded-lg border border-zinc-800/60 bg-zinc-900/50 px-3 py-2">
            <div class="text-[10px] uppercase tracking-wider text-zinc-500">Req Size</div>
            <div class="text-sm font-mono text-zinc-200 mt-0.5">{{ $log->request_size_bytes ? number_format($log->request_size_bytes) . ' B' : '—' }}</div>
        </div>
        <div class="rounded-lg border border-zinc-800/60 bg-zinc-900/50 px-3 py-2">
            <div class="text-[10px] uppercase tracking-wider text-zinc-500">Res Size</div>
            <div class="text-sm font-mono text-zinc-200 mt-0.5">{{ $log->response_size_bytes ? number_format($log->response_size_bytes) . ' B' : '—' }}</div>
        </div>
        <div class="rounded-lg border border-zinc-800/60 bg-zinc-900/50 px-3 py-2">
            <div class="text-[10px] uppercase tracking-wider text-zinc-500">Timestamp</div>
            <div class="text-sm font-mono text-zinc-200 mt-0.5">{{ $log->timestamp->format('H:i:s.v') }}</div>
        </div>
    </div>

    {{-- Flow Visualization --}}
    <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 px-6 py-4">
        <div class="flex items-center justify-center gap-4">
            {{-- Source --}}
            <div class="text-center min-w-[140px]">
                <div class="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-500/20 rounded-lg px-4 py-2.5">
                    <span class="size-2 rounded-full bg-cyan-500"></span>
                    <span class="font-mono text-sm text-cyan-300">{{ $log->sourceService?->name ?? $log->source_host ?? '?' }}</span>
                </div>
                <div class="text-[10px] text-zinc-600 mt-1 font-mono">{{ $log->source_host }}:{{ $log->source_port }}</div>
            </div>

            {{-- Arrow --}}
            <div class="flex flex-col items-center gap-0.5 min-w-[180px]">
                <div class="text-[10px] font-mono text-zinc-400">{{ $log->operation }}()</div>
                <div class="flex items-center gap-1 w-full">
                    <div class="h-px flex-1 bg-gradient-to-r from-cyan-500/50 to-emerald-500/50"></div>
                    <svg class="size-4 text-emerald-500/70" fill="currentColor" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd" />
                    </svg>
                </div>
                <div class="text-[10px] text-zinc-600">{{ $log->latency_ms ? round($log->latency_ms, 1) . 'ms' : '' }}</div>
            </div>

            {{-- Target --}}
            <div class="text-center min-w-[140px]">
                <div class="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-4 py-2.5">
                    <span class="size-2 rounded-full bg-emerald-500"></span>
                    <span class="font-mono text-sm text-emerald-300">{{ $log->targetService?->name ?? $log->target_host ?? '?' }}</span>
                </div>
                <div class="text-[10px] text-zinc-600 mt-1 font-mono">{{ $log->target_host }}:{{ $log->target_port }}</div>
            </div>
        </div>
    </div>

    {{-- Tabs --}}
    <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
        <div class="flex border-b border-zinc-800/60">
            @foreach([
                'overview' => ['Overview', 'information-circle'],
                'request' => ['Request Payload', 'arrow-up-tray'],
                'response' => ['Response Payload', 'arrow-down-tray'],
                'context' => ['Context & Metadata', 'cog-6-tooth'],
                'related' => ['Related (' . count($relatedLogs) . ')', 'link'],
            ] as $tab => [$label, $icon])
                <button wire:click="setTab('{{ $tab }}')"
                        class="flex items-center gap-2 px-5 py-3 text-sm transition-colors border-b-2 -mb-px
                            {{ $activeTab === $tab
                                ? 'text-emerald-400 border-emerald-500'
                                : 'text-zinc-500 border-transparent hover:text-zinc-300 hover:border-zinc-700' }}">
                    <flux:icon :name="$icon" class="size-4" />
                    {{ $label }}
                </button>
            @endforeach
        </div>

        <div class="p-5">

            {{-- OVERVIEW TAB --}}
            @if($activeTab === 'overview')
                <div class="grid md:grid-cols-2 gap-6">
                    <div class="space-y-3">
                        <h3 class="text-xs uppercase tracking-wider text-zinc-500 font-semibold">Request Identity</h3>
                        <dl class="space-y-2">
                            @foreach([
                                'Request ID' => $log->request_id,
                                'Operation' => $log->operation,
                                'Interface' => $log->interface_name,
                                'Repository ID' => $log->repository_id,
                                'Message Type' => $log->message_type,
                                'GIOP Version' => $log->giop_version,
                            ] as $label => $value)
                                <div class="flex items-start gap-3 text-sm">
                                    <dt class="text-zinc-500 min-w-[110px] shrink-0">{{ $label }}</dt>
                                    <dd class="font-mono text-zinc-300 break-all">{{ $value ?? '—' }}</dd>
                                </div>
                            @endforeach
                        </dl>
                    </div>

                    <div class="space-y-3">
                        <h3 class="text-xs uppercase tracking-wider text-zinc-500 font-semibold">Execution</h3>
                        <dl class="space-y-2">
                            @foreach([
                                'Status' => $log->status,
                                'Direction' => $log->direction,
                                'Latency' => $log->latency_ms ? round($log->latency_ms, 2) . ' ms' : null,
                                'Interceptor Point' => $log->interceptor_point,
                                'Request Size' => $log->request_size_bytes ? number_format($log->request_size_bytes) . ' bytes' : null,
                                'Response Size' => $log->response_size_bytes ? number_format($log->response_size_bytes) . ' bytes' : null,
                                'Timestamp' => $log->timestamp->format('Y-m-d H:i:s.v'),
                            ] as $label => $value)
                                <div class="flex items-start gap-3 text-sm">
                                    <dt class="text-zinc-500 min-w-[110px] shrink-0">{{ $label }}</dt>
                                    <dd class="font-mono text-zinc-300">{{ $value ?? '—' }}</dd>
                                </div>
                            @endforeach
                        </dl>
                    </div>
                </div>

                @if($log->error_message)
                    <div class="mt-6 bg-red-500/5 border border-red-500/20 rounded-lg p-4">
                        <h3 class="text-xs uppercase tracking-wider text-red-400 font-semibold mb-2">Error</h3>
                        <div class="font-mono text-sm text-red-300">{{ $log->error_message }}</div>
                        @if($log->exception_type)
                            <div class="font-mono text-xs text-red-500 mt-1">Type: {{ $log->exception_type }}</div>
                        @endif
                    </div>
                @endif

            {{-- REQUEST TAB --}}
            @elseif($activeTab === 'request')
                @if($log->request_data)
                    @if($rawMode)
                        <div class="relative">
                            <pre class="bg-zinc-950/50 rounded-lg p-4 text-xs font-mono text-zinc-300 overflow-auto max-h-[600px] leading-relaxed border border-zinc-800/40">{{ json_encode($log->request_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) }}</pre>
                        </div>
                    @else
                        @include('livewire.traffic.partials.idl-tree', ['data' => $log->request_data, 'label' => 'Request', 'depth' => 0])
                    @endif
                @else
                    <div class="py-12 text-center text-zinc-600">
                        <flux:icon.document class="size-10 mx-auto mb-3 opacity-50" />
                        <p class="text-sm">No request payload captured</p>
                    </div>
                @endif

            {{-- RESPONSE TAB --}}
            @elseif($activeTab === 'response')
                @if($log->response_data)
                    @if($rawMode)
                        <div class="relative">
                            <pre class="bg-zinc-950/50 rounded-lg p-4 text-xs font-mono text-zinc-300 overflow-auto max-h-[600px] leading-relaxed border border-zinc-800/40">{{ json_encode($log->response_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) }}</pre>
                        </div>
                    @else
                        @include('livewire.traffic.partials.idl-tree', ['data' => $log->response_data, 'label' => 'Response', 'depth' => 0])
                    @endif
                @else
                    <div class="py-12 text-center text-zinc-600">
                        <flux:icon.document class="size-10 mx-auto mb-3 opacity-50" />
                        <p class="text-sm">No response payload captured</p>
                        @if($log->status !== 'success')
                            <p class="text-xs text-red-400 mt-1">Request ended with status: {{ $log->status }}</p>
                        @endif
                    </div>
                @endif

            {{-- CONTEXT TAB --}}
            @elseif($activeTab === 'context')
                @if($log->context_data)
                    @if($rawMode)
                        <pre class="bg-zinc-950/50 rounded-lg p-4 text-xs font-mono text-zinc-300 overflow-auto max-h-[600px] leading-relaxed border border-zinc-800/40">{{ json_encode($log->context_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) }}</pre>
                    @else
                        @include('livewire.traffic.partials.idl-tree', ['data' => $log->context_data, 'label' => 'Service Context', 'depth' => 0])
                    @endif
                @else
                    <div class="py-12 text-center text-zinc-600">
                        <flux:icon.document class="size-10 mx-auto mb-3 opacity-50" />
                        <p class="text-sm">No context data captured</p>
                    </div>
                @endif

            {{-- RELATED TAB --}}
            @elseif($activeTab === 'related')
                @if(count($relatedLogs) > 0)
                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead>
                                <tr class="text-zinc-500 text-xs uppercase tracking-wider border-b border-zinc-800/40">
                                    <th class="text-left py-2 px-3 font-medium">Time</th>
                                    <th class="text-left py-2 px-3 font-medium">Direction</th>
                                    <th class="text-left py-2 px-3 font-medium">Interceptor</th>
                                    <th class="text-left py-2 px-3 font-medium">Source → Target</th>
                                    <th class="text-left py-2 px-3 font-medium">Status</th>
                                    <th class="text-right py-2 px-3 font-medium">Latency</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($relatedLogs as $related)
                                    <tr class="border-b border-zinc-800/20 hover:bg-zinc-800/30">
                                        <td class="py-2 px-3 font-mono text-xs text-zinc-400">{{ $related['timestamp'] }}</td>
                                        <td class="py-2 px-3 text-xs text-zinc-400 capitalize">{{ $related['direction'] }}</td>
                                        <td class="py-2 px-3 font-mono text-xs text-zinc-500">{{ $related['interceptor_point'] ?? '—' }}</td>
                                        <td class="py-2 px-3 text-xs">
                                            <span class="text-zinc-400">{{ $related['source'] ?? '?' }}</span>
                                            <span class="text-zinc-600 mx-1">→</span>
                                            <span class="text-zinc-400">{{ $related['target'] ?? '?' }}</span>
                                        </td>
                                        <td class="py-2 px-3">
                                            <span class="inline-flex text-xs px-2 py-0.5 rounded-full {{ match($related['status']) {
                                                'success' => 'bg-emerald-500/10 text-emerald-400',
                                                'error' => 'bg-red-500/10 text-red-400',
                                                'timeout' => 'bg-yellow-500/10 text-yellow-400',
                                                default => 'bg-zinc-500/10 text-zinc-400',
                                            } }}">{{ $related['status'] }}</span>
                                        </td>
                                        <td class="py-2 px-3 text-right font-mono text-xs text-zinc-400">
                                            {{ $related['latency_ms'] ? round($related['latency_ms'], 1) . 'ms' : '—' }}
                                        </td>
                                        <td class="py-2 px-3">
                                            <a href="{{ route('traffic.inspect', $related['id']) }}"
                                               class="text-xs text-emerald-500 hover:text-emerald-400">View →</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                @else
                    <div class="py-12 text-center text-zinc-600">
                        <flux:icon.link class="size-10 mx-auto mb-3 opacity-50" />
                        <p class="text-sm">No related traffic found</p>
                        <p class="text-xs mt-1 text-zinc-700">Matching on request_id or same operation within ±5s</p>
                    </div>
                @endif
            @endif
        </div>
    </div>
</div>
