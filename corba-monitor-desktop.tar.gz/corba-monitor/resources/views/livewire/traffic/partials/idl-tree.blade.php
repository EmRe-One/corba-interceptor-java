{{-- Recursive IDL Tree View --}}
{{-- @param array $data  - The data to render --}}
{{-- @param string $label - Label for this node --}}
{{-- @param int $depth    - Current nesting depth --}}

@php
    $depth = $depth ?? 0;
    $indent = $depth * 1; // rem units
    $maxDepth = 12;

    // Detect IDL-annotated structure
    $idlType = $data['_idl_type'] ?? $data['_type'] ?? null;
    $hasValue = array_key_exists('value', $data ?? []);
@endphp

@if($depth === 0)
    <div class="space-y-1 text-sm" x-data="{ collapsed: {} }">
        {{-- Top-level IDL type badge --}}
        @if($idlType)
            <div class="flex items-center gap-2 mb-3 pb-3 border-b border-zinc-800/40">
                <span class="text-[10px] uppercase tracking-wider text-zinc-500">IDL Type</span>
                <code class="text-xs font-mono text-violet-400 bg-violet-500/10 px-2 py-0.5 rounded">{{ $idlType }}</code>
            </div>
        @endif
@endif

@if(is_array($data) && $depth < $maxDepth)
    @foreach($data as $key => $value)
        @if(str_starts_with((string) $key, '_'))
            {{-- Skip meta keys at non-root level (already shown as type badge) --}}
            @continue
        @endif

        @php
            $nodeId = $label . '_' . $key . '_' . $depth;
            $isArray = is_array($value);
            $isIdlTyped = $isArray && isset($value['_type']);
            $isStruct = $isArray && !$isIdlTyped && !array_is_list($value);
            $isList = $isArray && array_is_list($value);
            $hasNestedValue = $isIdlTyped && isset($value['value']);
            $displayType = $isIdlTyped ? $value['_type'] : null;
            $displayValue = $isIdlTyped ? ($value['value'] ?? null) : $value;
            $isExpandable = is_array($displayValue) && !empty($displayValue);
        @endphp

        <div class="group" style="padding-left: {{ $indent }}rem">
            @if($isExpandable)
                {{-- Expandable node (struct or sequence) --}}
                <button
                    @click="collapsed['{{ $nodeId }}'] = !collapsed['{{ $nodeId }}']"
                    class="flex items-center gap-1.5 w-full text-left py-1 hover:bg-zinc-800/30 rounded px-2 -mx-2 transition-colors"
                >
                    <svg
                        class="size-3 text-zinc-600 transition-transform duration-150"
                        :class="collapsed['{{ $nodeId }}'] ? '' : 'rotate-90'"
                        fill="currentColor" viewBox="0 0 20 20"
                    >
                        <path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd" />
                    </svg>

                    {{-- Key name --}}
                    <span class="font-mono text-cyan-400 text-xs">{{ $key }}</span>

                    {{-- Type badge --}}
                    @if($displayType)
                        <span class="text-[10px] font-mono text-violet-400/70 bg-violet-500/5 px-1.5 py-0.5 rounded ml-1">{{ $displayType }}</span>
                    @endif

                    {{-- Summary for collapsed state --}}
                    @if($isList || (is_array($displayValue) && array_is_list($displayValue)))
                        <span class="text-[10px] text-zinc-600 ml-auto">[{{ count(is_array($displayValue) ? $displayValue : []) }} items]</span>
                    @elseif(is_array($displayValue))
                        <span class="text-[10px] text-zinc-600 ml-auto">{ {{ count($displayValue) }} fields }</span>
                    @endif
                </button>

                {{-- Children --}}
                <div x-show="!collapsed['{{ $nodeId }}']" x-transition.opacity class="border-l border-zinc-800/40 ml-1.5">
                    @if(is_array($displayValue) && array_is_list($displayValue))
                        {{-- Sequence/List --}}
                        @foreach($displayValue as $idx => $item)
                            @if(is_array($item))
                                @include('livewire.traffic.partials.idl-tree', ['data' => $item, 'label' => $label . '_' . $key, 'depth' => $depth + 1])
                            @else
                                <div class="py-0.5 pl-3" style="padding-left: {{ ($indent + 1) }}rem">
                                    <span class="font-mono text-zinc-600 text-xs">[{{ $idx }}]</span>
                                    <span class="font-mono text-xs ml-2 {{ is_numeric($item) ? 'text-amber-400' : 'text-emerald-400' }}">
                                        @if(is_bool($item))
                                            <span class="text-orange-400">{{ $item ? 'true' : 'false' }}</span>
                                        @elseif(is_null($item))
                                            <span class="text-zinc-600 italic">null</span>
                                        @elseif(is_string($item))
                                            <span class="text-emerald-400">"{{ $item }}"</span>
                                        @else
                                            <span class="text-amber-400">{{ $item }}</span>
                                        @endif
                                    </span>
                                </div>
                            @endif
                        @endforeach
                    @else
                        @include('livewire.traffic.partials.idl-tree', ['data' => $displayValue, 'label' => $label . '_' . $key, 'depth' => $depth + 1])
                    @endif
                </div>
            @else
                {{-- Leaf node (scalar value) --}}
                <div class="flex items-center gap-1.5 py-0.5 px-2 -mx-2 rounded hover:bg-zinc-800/20 transition-colors">
                    <span class="size-3 flex items-center justify-center">
                        <span class="size-1 rounded-full bg-zinc-700"></span>
                    </span>

                    {{-- Key --}}
                    <span class="font-mono text-cyan-400 text-xs">{{ $key }}</span>

                    {{-- Type --}}
                    @if($displayType)
                        <span class="text-[10px] font-mono text-violet-400/70 bg-violet-500/5 px-1.5 py-0.5 rounded">{{ $displayType }}</span>
                    @endif

                    <span class="text-zinc-700 mx-1">=</span>

                    {{-- Value --}}
                    <span class="font-mono text-xs">
                        @php $val = $displayValue; @endphp
                        @if(is_bool($val))
                            <span class="text-orange-400">{{ $val ? 'true' : 'false' }}</span>
                        @elseif(is_null($val))
                            <span class="text-zinc-600 italic">null</span>
                        @elseif(is_numeric($val))
                            <span class="text-amber-400">{{ $val }}</span>
                        @elseif(is_string($val) && (str_starts_with($val, '20') && str_contains($val, 'T')))
                            {{-- ISO datetime --}}
                            <span class="text-sky-400">"{{ $val }}"</span>
                        @elseif(is_string($val) && strlen($val) > 60)
                            <span class="text-emerald-400 break-all">"{{ $val }}"</span>
                        @elseif(is_string($val))
                            <span class="text-emerald-400">"{{ $val }}"</span>
                        @elseif(is_array($val))
                            <span class="text-zinc-500">{{ json_encode($val) }}</span>
                        @else
                            <span class="text-zinc-300">{{ $val }}</span>
                        @endif
                    </span>
                </div>
            @endif
        </div>
    @endforeach
@endif

@if($depth === 0)
    </div>
@endif
