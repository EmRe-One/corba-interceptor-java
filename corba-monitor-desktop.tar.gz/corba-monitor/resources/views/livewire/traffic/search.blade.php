<div class="space-y-6">

    {{-- Header --}}
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-2xl font-bold tracking-tight text-zinc-100">Traffic Logs</h1>
            <p class="text-sm text-zinc-500 mt-1">Full-text search powered by Meilisearch</p>
        </div>
    </div>

    {{-- Search Bar --}}
    <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-4">
        <div class="flex items-center gap-3">
            <div class="relative flex-1">
                <flux:icon.magnifying-glass class="size-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input wire:model.live.debounce.300ms="query"
                       type="text"
                       placeholder="Search operations, interfaces, errors, request data..."
                       class="w-full bg-zinc-800/50 border border-zinc-700/50 rounded-lg pl-10 pr-4 py-2.5 text-sm text-zinc-200 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500/50 font-mono" />
            </div>
            <flux:button wire:click="toggleFilters" variant="ghost" size="sm" icon="funnel">
                Filters
            </flux:button>
            <flux:button wire:click="clearFilters" variant="ghost" size="sm" icon="x-mark">
                Clear
            </flux:button>
        </div>

        {{-- Expandable Filters --}}
        @if($showFilters)
            <div class="mt-4 pt-4 border-t border-zinc-800/60 grid grid-cols-2 md:grid-cols-5 gap-3">
                <flux:select wire:model.live="filterStatus" size="sm" placeholder="Status">
                    <flux:select.option value="">All Status</flux:select.option>
                    <flux:select.option value="success">Success</flux:select.option>
                    <flux:select.option value="error">Error</flux:select.option>
                    <flux:select.option value="timeout">Timeout</flux:select.option>
                    <flux:select.option value="exception">Exception</flux:select.option>
                </flux:select>

                <flux:select wire:model.live="filterDirection" size="sm" placeholder="Direction">
                    <flux:select.option value="">All Directions</flux:select.option>
                    <flux:select.option value="request">Request</flux:select.option>
                    <flux:select.option value="reply">Reply</flux:select.option>
                </flux:select>

                <flux:select wire:model.live="filterInterface" size="sm" placeholder="Interface">
                    <flux:select.option value="">All Interfaces</flux:select.option>
                    @foreach($availableInterfaces as $iface)
                        <flux:select.option value="{{ $iface }}">{{ $iface }}</flux:select.option>
                    @endforeach
                </flux:select>

                <input wire:model.live.debounce.500ms="filterFrom"
                       type="datetime-local"
                       class="bg-zinc-800/50 border border-zinc-700/50 rounded-lg px-3 py-1.5 text-xs text-zinc-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" />

                <input wire:model.live.debounce.500ms="filterMinLatency"
                       type="number"
                       placeholder="Min latency (ms)"
                       class="bg-zinc-800/50 border border-zinc-700/50 rounded-lg px-3 py-1.5 text-xs text-zinc-300 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/30" />
            </div>
        @endif

        {{-- Results count --}}
        <div class="mt-3 flex items-center justify-between text-xs text-zinc-500">
            <span>{{ number_format($searchTotal) }} results found</span>
            <span>Page {{ $currentPage }} · {{ $perPage }} per page</span>
        </div>
    </div>

    <div class="grid lg:grid-cols-3 gap-6">

        {{-- Results List --}}
        <div class="lg:col-span-2 rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden">
            <div class="overflow-x-auto max-h-[650px] overflow-y-auto">
                <table class="w-full text-sm">
                    <thead class="sticky top-0 bg-zinc-900/95 backdrop-blur-sm">
                        <tr class="text-zinc-500 text-xs uppercase tracking-wider border-b border-zinc-800/40">
                            <th class="text-left py-2.5 px-4 font-medium">Timestamp</th>
                            <th class="text-left py-2.5 px-4 font-medium">Operation</th>
                            <th class="text-left py-2.5 px-4 font-medium">Source → Target</th>
                            <th class="text-left py-2.5 px-4 font-medium">Status</th>
                            <th class="text-right py-2.5 px-4 font-medium">Latency</th>
                            <th class="text-right py-2.5 px-4 font-medium">Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($searchResults as $result)
                            @php $hit = $result['source']; @endphp
                            <tr wire:click="selectLog({{ $result['id'] }})"
                                class="border-b border-zinc-800/20 hover:bg-zinc-800/30 transition-colors cursor-pointer {{ $selectedLogId == $result['id'] ? 'bg-zinc-800/50' : '' }}">
                                <td class="py-2 px-4 font-mono text-xs text-zinc-500">
                                    {{ \Carbon\Carbon::parse($hit['timestamp'])->format('m-d H:i:s') }}
                                </td>
                                <td class="py-2 px-4">
                                    <div class="font-mono text-xs text-zinc-200">
                                        @if(!empty($result['highlight']['operation']))
                                            {!! $result['highlight']['operation'][0] !!}
                                        @else
                                            {{ $hit['operation'] ?? '—' }}
                                        @endif
                                    </div>
                                    <div class="text-xs text-zinc-600">{{ $hit['interface_name'] ?? '' }}</div>
                                </td>
                                <td class="py-2 px-4 text-xs">
                                    <span class="text-zinc-400">{{ $hit['source_service_name'] ?? $hit['source_host'] ?? '?' }}</span>
                                    <span class="text-zinc-600 mx-1">→</span>
                                    <span class="text-zinc-400">{{ $hit['target_service_name'] ?? $hit['target_host'] ?? '?' }}</span>
                                </td>
                                <td class="py-2 px-4">
                                    <span class="inline-flex text-xs px-2 py-0.5 rounded-full {{ match($hit['status'] ?? '') {
                                        'success' => 'bg-emerald-500/10 text-emerald-400',
                                        'error' => 'bg-red-500/10 text-red-400',
                                        'timeout' => 'bg-yellow-500/10 text-yellow-400',
                                        'exception' => 'bg-orange-500/10 text-orange-400',
                                        default => 'bg-zinc-500/10 text-zinc-400',
                                    } }}">
                                        {{ $hit['status'] ?? '?' }}
                                    </span>
                                </td>
                                <td class="py-2 px-4 text-right font-mono text-xs text-zinc-400">
                                    {{ isset($hit['latency_ms']) ? round($hit['latency_ms'], 1) . 'ms' : '—' }}
                                </td>
                                <td class="py-2 px-4 text-right text-xs text-zinc-600">
                                    {{ $result['score'] ? round($result['score'], 2) : '—' }}
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="py-12 text-center text-zinc-600">
                                    <flux:icon.magnifying-glass class="size-8 mx-auto mb-3 opacity-50" />
                                    <p>No results found</p>
                                    <p class="text-xs mt-1">Try adjusting your search query or filters</p>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            {{-- Pagination --}}
            @if($searchTotal > $perPage)
                <div class="flex items-center justify-between px-4 py-3 border-t border-zinc-800/60">
                    <flux:button wire:click="prevPage" size="sm" variant="ghost" :disabled="$currentPage <= 1">
                        ← Previous
                    </flux:button>
                    <span class="text-xs text-zinc-500">
                        {{ ($currentPage - 1) * $perPage + 1 }}–{{ min($currentPage * $perPage, $searchTotal) }}
                        of {{ number_format($searchTotal) }}
                    </span>
                    <flux:button wire:click="nextPage" size="sm" variant="ghost" :disabled="$currentPage * $perPage >= $searchTotal">
                        Next →
                    </flux:button>
                </div>
            @endif
        </div>

        {{-- Detail Panel --}}
        <div>
            @if($selectedLogId && !empty($selectedLogDetails))
                <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 overflow-hidden sticky top-20">
                    <div class="px-5 py-3 border-b border-zinc-800/60 flex items-center justify-between">
                        <h2 class="font-semibold text-zinc-200">Request Detail</h2>
                        <div class="flex items-center gap-1">
                            <a href="{{ route('traffic.inspect', $selectedLogId) }}">
                                <flux:button icon="arrow-top-right-on-square" variant="ghost" size="xs" title="Open Inspector" />
                            </a>
                            <flux:button wire:click="clearSelection" icon="x-mark" variant="ghost" size="xs" />
                        </div>
                    </div>
                    <div class="p-4 space-y-4 max-h-[600px] overflow-y-auto">

                        {{-- Basic Info --}}
                        <div class="space-y-2 text-xs">
                            <div class="flex justify-between">
                                <span class="text-zinc-500">Request ID</span>
                                <span class="font-mono text-zinc-300">{{ substr($selectedLogDetails['request_id'], 0, 12) }}…</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-zinc-500">Operation</span>
                                <span class="font-mono text-zinc-200">{{ $selectedLogDetails['operation'] }}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-zinc-500">Interface</span>
                                <span class="font-mono text-zinc-300">{{ $selectedLogDetails['interface_name'] ?? '—' }}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-zinc-500">Direction</span>
                                <span class="text-zinc-300 capitalize">{{ $selectedLogDetails['direction'] }}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-zinc-500">GIOP</span>
                                <span class="font-mono text-zinc-300">{{ $selectedLogDetails['giop_version'] ?? '—' }}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-zinc-500">Interceptor</span>
                                <span class="font-mono text-zinc-300">{{ $selectedLogDetails['interceptor_point'] ?? '—' }}</span>
                            </div>
                        </div>

                        <hr class="border-zinc-800/60" />

                        {{-- Source & Target --}}
                        <div class="grid grid-cols-2 gap-3 text-xs">
                            <div class="bg-zinc-800/30 rounded-lg p-3">
                                <div class="text-cyan-400 text-[10px] uppercase tracking-wider mb-1">Source</div>
                                <div class="font-mono text-zinc-300">{{ $selectedLogDetails['source']['service'] ?? '—' }}</div>
                                <div class="font-mono text-zinc-500 mt-0.5">{{ $selectedLogDetails['source']['host'] }}:{{ $selectedLogDetails['source']['port'] }}</div>
                            </div>
                            <div class="bg-zinc-800/30 rounded-lg p-3">
                                <div class="text-emerald-400 text-[10px] uppercase tracking-wider mb-1">Target</div>
                                <div class="font-mono text-zinc-300">{{ $selectedLogDetails['target']['service'] ?? '—' }}</div>
                                <div class="font-mono text-zinc-500 mt-0.5">{{ $selectedLogDetails['target']['host'] }}:{{ $selectedLogDetails['target']['port'] }}</div>
                            </div>
                        </div>

                        {{-- Performance --}}
                        <div class="grid grid-cols-3 gap-2 text-xs">
                            <div class="bg-zinc-800/30 rounded-lg p-2 text-center">
                                <div class="text-zinc-500 text-[10px]">Latency</div>
                                <div class="font-mono text-zinc-200 mt-0.5">{{ $selectedLogDetails['latency_ms'] ? round($selectedLogDetails['latency_ms'], 1) . 'ms' : '—' }}</div>
                            </div>
                            <div class="bg-zinc-800/30 rounded-lg p-2 text-center">
                                <div class="text-zinc-500 text-[10px]">Req Size</div>
                                <div class="font-mono text-zinc-200 mt-0.5">{{ $selectedLogDetails['request_size_bytes'] ? number_format($selectedLogDetails['request_size_bytes']) . 'B' : '—' }}</div>
                            </div>
                            <div class="bg-zinc-800/30 rounded-lg p-2 text-center">
                                <div class="text-zinc-500 text-[10px]">Res Size</div>
                                <div class="font-mono text-zinc-200 mt-0.5">{{ $selectedLogDetails['response_size_bytes'] ? number_format($selectedLogDetails['response_size_bytes']) . 'B' : '—' }}</div>
                            </div>
                        </div>

                        {{-- Error Info --}}
                        @if($selectedLogDetails['error_message'])
                            <div class="bg-red-500/5 border border-red-500/20 rounded-lg p-3">
                                <div class="text-red-400 text-[10px] uppercase tracking-wider mb-1">Error</div>
                                <div class="font-mono text-xs text-red-300">{{ $selectedLogDetails['error_message'] }}</div>
                                @if($selectedLogDetails['exception_type'])
                                    <div class="font-mono text-xs text-red-500 mt-1">{{ $selectedLogDetails['exception_type'] }}</div>
                                @endif
                            </div>
                        @endif

                        {{-- Request Data --}}
                        @if($selectedLogDetails['request_data'])
                            <div>
                                <div class="text-zinc-500 text-[10px] uppercase tracking-wider mb-1">Request Data</div>
                                <pre class="bg-zinc-800/50 rounded-lg p-3 text-xs font-mono text-zinc-300 overflow-x-auto max-h-32">{{ json_encode($selectedLogDetails['request_data'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) }}</pre>
                            </div>
                        @endif

                        {{-- Response Data --}}
                        @if($selectedLogDetails['response_data'])
                            <div>
                                <div class="text-zinc-500 text-[10px] uppercase tracking-wider mb-1">Response Data</div>
                                <pre class="bg-zinc-800/50 rounded-lg p-3 text-xs font-mono text-zinc-300 overflow-x-auto max-h-32">{{ json_encode($selectedLogDetails['response_data'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) }}</pre>
                            </div>
                        @endif

                        {{-- Full Inspector Link --}}
                        <a href="{{ route('traffic.inspect', $selectedLogId) }}"
                           class="block w-full text-center py-2.5 rounded-lg text-sm font-medium
                                  bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/20
                                  transition-colors mt-2">
                            Open Message Inspector →
                        </a>
                    </div>
                </div>
            @else
                <div class="rounded-xl border border-zinc-800/60 bg-zinc-900/50 p-8 text-center">
                    <flux:icon.document-magnifying-glass class="size-10 mx-auto mb-3 text-zinc-700" />
                    <p class="text-sm text-zinc-500">Select a traffic entry to view details</p>
                    <p class="text-xs text-zinc-600 mt-1">Click any row in the results table</p>
                </div>
            @endif
        </div>
    </div>
</div>

<style>
    mark, em { background: rgba(16, 185, 129, 0.2); color: #6ee7b7; font-style: normal; padding: 0 2px; border-radius: 2px; }
</style>
