<x-layouts.app title="Dashboard — CORBA Monitor">
    <livewire:dashboard.overview />
</x-layouts.app>
