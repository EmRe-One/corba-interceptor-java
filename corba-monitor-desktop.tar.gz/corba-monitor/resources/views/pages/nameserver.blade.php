<x-layouts.app title="Nameserver — CORBA Monitor">
    <livewire:nameserver.explorer />
</x-layouts.app>
