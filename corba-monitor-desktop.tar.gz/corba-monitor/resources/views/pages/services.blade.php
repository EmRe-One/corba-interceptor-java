<x-layouts.app title="Services — CORBA Monitor">
    <livewire:services.topology />
</x-layouts.app>
