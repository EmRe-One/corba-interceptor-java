<x-layouts.app title="Service Manager — CORBA Monitor">
    <livewire:settings.service-manager />
</x-layouts.app>
