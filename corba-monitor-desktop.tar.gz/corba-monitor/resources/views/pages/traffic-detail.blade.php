<x-layouts.app title="Message Inspector — CORBA Monitor">
    <livewire:traffic.inspector :id="$id" />
</x-layouts.app>
