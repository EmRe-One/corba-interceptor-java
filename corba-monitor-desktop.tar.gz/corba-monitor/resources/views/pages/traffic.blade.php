<x-layouts.app title="Traffic — CORBA Monitor">
    <livewire:traffic.search />
</x-layouts.app>
