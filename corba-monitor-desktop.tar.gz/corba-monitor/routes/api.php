<?php

use App\Http\Controllers\TrafficApiController;
use Illuminate\Support\Facades\Route;

Route::prefix('api')->group(function () {
    // Health check
    Route::get('/health', [TrafficApiController::class, 'health']);

    // Traffic ingestion (from Portable Interceptors)
    Route::post('/traffic', [TrafficApiController::class, 'ingest']);
    Route::post('/traffic/batch', [TrafficApiController::class, 'ingestBatch']);

    // Search & statistics
    Route::get('/search', [TrafficApiController::class, 'search']);
    Route::get('/stats', [TrafficApiController::class, 'stats']);

    // Nameserver operations
    Route::post('/nameserver/scan', [TrafficApiController::class, 'scanNameserver']);
    Route::post('/nameserver/report', [TrafficApiController::class, 'receiveScanReport']);
});
