<?php

use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('dashboard'));

Route::get('/dashboard', fn () => view('pages.dashboard'))->name('dashboard');
Route::get('/services', fn () => view('pages.services'))->name('services');
Route::get('/traffic', fn () => view('pages.traffic'))->name('traffic');
Route::get('/traffic/{id}', fn (int $id) => view('pages.traffic-detail', ['id' => $id]))->name('traffic.inspect');
Route::get('/nameserver', fn () => view('pages.nameserver'))->name('nameserver');
Route::get('/settings/services', fn () => view('pages.settings-services'))->name('settings.services');
