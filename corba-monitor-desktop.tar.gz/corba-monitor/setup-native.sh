#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  CORBA Monitor — NativePHP Desktop Setup
# ═══════════════════════════════════════════════════════════════
set -e

echo ""
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║   CORBA Monitor — Desktop Setup                  ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo ""

# ── 1. Check prerequisites ──────────────────────────────────
echo "[1/6] Checking prerequisites..."

if ! command -v php &>/dev/null; then
    echo "  ✗ PHP not found. Install PHP 8.2+ or use Laravel Herd."
    exit 1
fi
PHP_VERSION=$(php -r "echo PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION;")
echo "  ✓ PHP $PHP_VERSION"

if ! command -v node &>/dev/null; then
    echo "  ✗ Node.js not found. Install Node.js 18+."
    exit 1
fi
NODE_VERSION=$(node --version)
echo "  ✓ Node $NODE_VERSION"

if ! command -v composer &>/dev/null; then
    echo "  ✗ Composer not found."
    exit 1
fi
echo "  ✓ Composer $(composer --version 2>/dev/null | head -1 | awk '{print $3}')"

if command -v java &>/dev/null; then
    JAVA_VERSION=$(java -version 2>&1 | head -1)
    echo "  ✓ Java: $JAVA_VERSION"
else
    echo "  ⚠ Java not found (CORBA Agent will not start, but app works fine)"
fi

# ── 2. Install PHP dependencies ──────────────────────────────
echo ""
echo "[2/6] Installing PHP dependencies..."
composer install --no-interaction --prefer-dist --optimize-autoloader

# ── 3. Install Node dependencies ─────────────────────────────
echo ""
echo "[3/6] Installing Node dependencies..."
npm install

# ── 4. Configure environment ────────────────────────────────
echo ""
echo "[4/6] Configuring environment..."

if [ ! -f .env ]; then
    cp .env.native .env
    php artisan key:generate --ansi
    echo "  ✓ Created .env from .env.native"
else
    echo "  ✓ .env already exists"
fi

# Ensure SQLite database exists
DB_PATH="database/database.sqlite"
if [ ! -f "$DB_PATH" ]; then
    touch "$DB_PATH"
    echo "  ✓ Created SQLite database"
fi

# Run migrations
php artisan migrate --force
echo "  ✓ Migrations complete"

# ── 5. Download Meilisearch binary ──────────────────────────
echo ""
echo "[5/6] Setting up Meilisearch..."

PLATFORM=$(uname -s)
ARCH=$(uname -m)

case "$PLATFORM-$ARCH" in
    Darwin-arm64)  MS_BIN="meilisearch-macos-arm64" ;;
    Darwin-x86_64) MS_BIN="meilisearch-macos-amd64" ;;
    Linux-x86_64)  MS_BIN="meilisearch-linux-amd64" ;;
    Linux-aarch64) MS_BIN="meilisearch-linux-arm64" ;;
    MINGW*|MSYS*)  MS_BIN="meilisearch-windows-amd64.exe" ;;
    *)
        echo "  ⚠ Unsupported platform: $PLATFORM-$ARCH"
        echo "    Download Meilisearch manually: https://github.com/meilisearch/meilisearch/releases"
        MS_BIN=""
        ;;
esac

if [ -n "$MS_BIN" ]; then
    MS_PATH="extras/meilisearch/$MS_BIN"
    if [ -f "$MS_PATH" ]; then
        echo "  ✓ Meilisearch binary already exists: $MS_BIN"
    else
        echo "  Downloading $MS_BIN..."
        MS_URL="https://github.com/meilisearch/meilisearch/releases/latest/download/$MS_BIN"
        if curl -fSL "$MS_URL" -o "$MS_PATH" 2>/dev/null; then
            chmod +x "$MS_PATH"
            echo "  ✓ Downloaded and made executable"
        else
            echo "  ⚠ Download failed. You can download manually:"
            echo "    $MS_URL"
            echo "    Place it at: $MS_PATH"
        fi
    fi
fi

# ── 6. Build frontend assets ────────────────────────────────
echo ""
echo "[6/6] Building frontend assets..."
npm run build
echo "  ✓ Vite build complete"

# ── Done ────────────────────────────────────────────────────
echo ""
echo "  ════════════════════════════════════════════════════"
echo "  ✓ Setup complete!"
echo ""
echo "  To start the desktop app:"
echo "    php artisan native:serve"
echo ""
echo "  To start in browser (development):"
echo "    php artisan serve"
echo "    # (Start Meilisearch separately)"
echo ""
echo "  To build for distribution:"
echo "    php artisan native:build"
echo "  ════════════════════════════════════════════════════"
echo ""
