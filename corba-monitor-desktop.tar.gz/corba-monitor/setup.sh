#!/bin/bash
set -e

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║          CORBA Monitor — Setup & Installation               ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Check prerequisites
command -v docker >/dev/null 2>&1 || { echo "❌ Docker is required but not installed."; exit 1; }
command -v docker-compose >/dev/null 2>&1 || command -v docker compose >/dev/null 2>&1 || { echo "❌ Docker Compose is required."; exit 1; }

# Determine docker compose command
if command -v docker-compose >/dev/null 2>&1; then
    DC="docker-compose"
else
    DC="docker compose"
fi

echo "1/7  Creating .env from template..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "     ✅ .env created"
else
    echo "     ⏭  .env already exists"
fi

echo ""
echo "2/7  Building Docker images..."
$DC build --no-cache

echo ""
echo "3/7  Starting services..."
$DC up -d

echo ""
echo "4/7  Waiting for MySQL to be ready..."
until $DC exec -T mysql mysqladmin ping -h localhost --silent 2>/dev/null; do
    echo "     ⏳ Waiting..."
    sleep 3
done
echo "     ✅ MySQL is ready"

echo ""
echo "5/7  Installing dependencies & setting up Laravel..."
$DC exec -T app composer install --no-interaction --optimize-autoloader
$DC exec -T app php artisan key:generate --force
$DC exec -T app php artisan migrate --force
$DC exec -T app php artisan storage:link

echo ""
echo "6/7  Setting up Meilisearch indexes..."
sleep 3  # Give Meilisearch a moment to fully start
$DC exec -T app php artisan corba:setup-meilisearch

echo ""
echo "7/7  Building frontend assets..."
$DC exec -T app npm install
$DC exec -T app npm run build

echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                   🎉 Setup Complete!                        ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║                                                             ║"
echo "║  Dashboard:      http://localhost:8080                      ║"
echo "║  API Health:     http://localhost:8080/api/health           ║"
echo "║  WebSocket:      ws://localhost:8085                        ║"
echo "║  Meilisearch:    http://localhost:7700                      ║"
echo "║                                                             ║"
echo "║  Generate demo data:                                        ║"
echo "║    docker compose exec app php artisan corba:demo-traffic   ║"
echo "║                                                             ║"
echo "║  Live demo mode:                                            ║"
echo "║    docker compose exec app php artisan corba:demo-traffic   ║"
echo "║      --live --interval=200                                  ║"
echo "║                                                             ║"
echo "║  Scan a nameserver:                                         ║"
echo "║    docker compose exec app php artisan corba:scan-nameserver║"
echo "║                                                             ║"
echo "╚══════════════════════════════════════════════════════════════╝"
